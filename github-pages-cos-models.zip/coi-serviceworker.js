self.addEventListener('install',event=>{self.skipWaiting();});
self.addEventListener('activate',event=>{
  event.waitUntil((async()=>{
    try{await self.registration.unregister();}catch(e){}
    try{
      const list=await self.clients.matchAll({type:'window',includeUncontrolled:true});
      for(const c of list){
        try{
          const u=new URL(c.url);
          u.searchParams.set('v','11.1');
          await c.navigate(u.toString());
        }catch(e){}
      }
    }catch(e){}
  })());
});
