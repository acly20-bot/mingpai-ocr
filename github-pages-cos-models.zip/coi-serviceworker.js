self.addEventListener('install',event=>{self.skipWaiting();});
self.addEventListener('activate',event=>{event.waitUntil(self.clients.claim());});
self.addEventListener('fetch',event=>{
  const req=event.request;
  let url; try{url=new URL(req.url);}catch{return;}
  if(url.origin!==self.location.origin) return;
  event.respondWith((async()=>{
    try{
      const init=req.mode==='navigate'?{cache:'no-store'}:undefined;
      const res=await fetch(req,init);
      if(!res || res.type==='opaque') return res;
      const headers=new Headers(res.headers);
      headers.set('Cross-Origin-Opener-Policy','same-origin');
      headers.set('Cross-Origin-Embedder-Policy','require-corp');
      if(req.mode==='navigate') headers.set('Cache-Control','no-store, max-age=0');
      return new Response(res.body,{status:res.status,statusText:res.statusText,headers});
    }catch(err){return fetch(req);}
  })());
});
