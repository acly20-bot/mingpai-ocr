self.addEventListener('install',event=>{self.skipWaiting();});
self.addEventListener('activate',event=>{event.waitUntil(self.clients.claim());});
self.addEventListener('fetch',event=>{
  const req=event.request;
  if(req.cache==='only-if-cached' && req.mode!=='same-origin') return;
  event.respondWith(fetch(req).then(resp=>{
    if(!resp || resp.type==='opaque') return resp;
    const h=new Headers(resp.headers);
    h.set('Cross-Origin-Opener-Policy','same-origin');
    h.set('Cross-Origin-Embedder-Policy','credentialless');
    return new Response(resp.body,{status:resp.status,statusText:resp.statusText,headers:h});
  }).catch(()=>fetch(req)));
});
