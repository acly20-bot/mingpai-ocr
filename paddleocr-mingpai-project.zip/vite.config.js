import { defineConfig } from 'vite';

// GitHub Pages serves this project from /<repository-name>/.
export default defineConfig({
  base: '/mingpai-ocr/',
  build: {
    outDir: 'dist',
    emptyOutDir: true,
  },
});
