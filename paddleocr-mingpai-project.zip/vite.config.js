import { defineConfig } from 'vite';

// GitHub Pages project site: https://<owner>.github.io/mingpai-ocr/
export default defineConfig({
  base: '/mingpai-ocr/',
  build: {
    outDir: 'dist',
    emptyOutDir: true,
    assetsInlineLimit: 0,
    sourcemap: false,
  },
});
