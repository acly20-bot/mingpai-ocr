import { defineConfig } from 'vite';

// This project is published at https://<owner>.github.io/mingpai-ocr/
export default defineConfig({
  base: '/mingpai-ocr/',
  build: {
    outDir: 'dist',
    emptyOutDir: true,
    assetsInlineLimit: 0,
  },
});
