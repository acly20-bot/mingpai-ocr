# 设备铭牌 OCR 双引擎 + 腾讯文档自动同步

## 功能
- 默认优先 OCR.space；额度/限流或云端请求异常时可切换 PaddleOCR.js + PP-OCRv6 本地备用；保留之前已验证的默认 Paddle 初始化方式。
- 手机拍照/相册多选、逐张识别、字段人工审核、IndexedDB 本地缓存、JSON 备份、CSV/TSV 导出。
- 新增“录入人员姓名”字段。
- 审核确认后可自动同步到同一份腾讯文档智能表格；失败记录保留在本地，可点击重试或批量重试。
- 腾讯文档 Token 只保存在 Cloudflare Worker Secret，不会放入 GitHub Pages 前端。

## 腾讯文档同步方式
这份前端项目需要搭配 `cloudflare-worker/worker.js` 部署为单独的 Cloudflare Worker。详细步骤见 `cloudflare-worker/README.md`。

目标腾讯文档来自用户提供的 URL：
- `DOC_ID=DTW9nTUROa2RkeUVx`
- `SHEET_ID=t00i2h`（作为 URL `tab` 参数的候选值，必须点击网页的“验证腾讯文档并初始化字段”让 MCP `smartsheet.list_tables` 验证；如果不匹配，根据错误中列出的 sheet_id 修改 Cloudflare 变量）

首次初始化会检查现有列：`科室`、`日期`、`铭牌文本`、`设备名称`、`生产厂家`、`型号`、`编号`。只有这两个辅助字段缺失时才自动新增：`录入人员`、`本地记录ID`。不会改动或删除现有设备数据。

## 部署前端（现有 GitHub 仓库）
1. 上传本项目为仓库根目录 `paddleocr-mingpai-project.zip` 并替换同名旧文件。
2. 保留 `.github/workflows/deploy-paddleocr.yml`，该工作流会解压项目并运行 `npm install && npm run build`。
3. GitHub Actions 成功后打开 `https://acly20-bot.github.io/mingpai-ocr/`。

## 安全说明
- 不要把腾讯文档 Token 放进网页或 GitHub 仓库。
- 每位授权盘点人员需要在自己手机浏览器中输入 Worker URL 和管理员分发的共享访问密钥；个人姓名保存在当前浏览器，并随已确认记录提交。
- 本地 IndexedDB 仍然保留缓存；完成云端同步后，即使更换浏览器，云端腾讯文档仍有该条记录。建议仍定期下载 JSON 备份。
- 云端写入需 Tencent Docs MCP 账号具有对应权限；如果返回 `400007 VIP权限不足`，Worker 不会绕过腾讯文档权限限制。
