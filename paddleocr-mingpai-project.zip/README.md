# 设备铭牌智能识别 v3.5

本版基于 v3.3 共享知识库版，重点优化医疗设备铭牌字段分类：

- 型号支持“型号、规格 / 型号规格 / 规格型号”等标签，支持值在下一行或特殊情况下上一行。
- 型号会剥离“、规格：”等中文残留，并过滤明显字段名。
- 出厂编号新增“机身码 / 生产编号 / 产品生产日期或序列号 / GS1 UDI (21)”规则。
- 生产厂家按“受托生产企业 > 生产企业 > 注册人/生产企业 > 制造商/生产厂家 > 备案人”优先级提取。
- 铭牌明确厂家和型号不会被共享知识库覆盖；共享知识库主要负责补缺与标准名称映射。
- 增加“彩色超声诊断设备 → 医用超声诊断仪（B超）超声源”标准名称映射。
- 增加产品名称误把系列/型号当设备名称时的纠偏逻辑。

已用 6 条实际 OCR 原文做回归测试，目标字段均达到预期结果。

部署方式保持不变：将整个项目 ZIP 上传到 GitHub 仓库并由现有 Actions 解压、Vite 构建、发布 GitHub Pages。


## v3.6.2
- 顶部“下载 CSV”恢复为导出全部已确认记录。
- “清理已同步”会清除本机全部已确认且已同步记录，不影响飞书。
- Paddle 备用模型恢复为此前已验证可用的 PP-OCRv6 默认 Small 配置；不使用自定义模型 TAR/WASM 路径。
- 重识别按钮明确区分 OCR.space 与 Paddle；两者均需重新选择原照片，因为浏览器仅长期保存缩略图而不保留完整原图。


## v3.6.2
- 恢复已验证的 PP-OCRv6 Small/default 初始化方式：不指定自定义 TAR/WASM，worker=false，ORT backend=auto；失败时再兼容回退 PP-OCRv5。
- 保留 v3.6.1 的 CSV、清理已同步、网络与界面优化。


## v3.7.0
- PaddleOCR SDK changed from runtime dynamic import to static bundle import to avoid stale hashed chunk errors after GitHub Pages deployments.
- Restored Paddle initialization timeout from 120s to 180s, matching the previously working v3.5 behavior.
- Keeps PP-OCRv6 Small/default model configuration and all v3.6.x workflow features.


## v3.7.0
- 新增拍照后可选裁剪铭牌区域。
- Paddle 推理失败后自动释放并重建模型状态，无需刷新网页。
- 增强 ZOLL M Series、欧姆龙 HEM 型号、牙科 X 射线设备分类。
- 出厂编号规则增加注册号/地址/邮编排除，明确编号标签为空时不再乱猜。
- 粘贴工具新增“取上一条值”。
- 备注框缩为两行；顶部“下载数据”保留全部已确认数据导出；高级工具移除重复 CSV 入口。


## v3.8.0
- 固定 33 类标准设备名称；明确别名或高置信共享知识库“厂家+型号”命中时标准化。
- 不属于 33 类或证据不足的设备，保留 OCR/铭牌原设备名称。
- 第 33 类固定为“医用电子加速器辐射源”。
- 高频电刀 POWER-42OFX 常见 O/0 混淆纠正为 POWER-420FX。
- 出厂编号新增“生产批号（出厂编号）”及标签上一行取值，排除 10s/30s 等工作制。
