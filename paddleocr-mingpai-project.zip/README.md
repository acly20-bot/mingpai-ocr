# 设备铭牌 OCR 双引擎版：OCR.space 优先 + PaddleOCR.js PP-OCRv6 备用

## 功能
- 选择“自动：优先 OCR.space，额度/服务异常时切到 PaddleOCR.js + PP-OCRv6”；也可以手动选择“仅 OCR.space”或“仅 PaddleOCR.js + PP-OCRv6”。
- OCR.space 的 Engine 2 是默认云端引擎；可以切换 Engine 3 做困难铭牌测试。API Key 仅保存在本机浏览器 localStorage，不写入仓库。
- 自动模式下，云端限额或请求失败时当前照片会尝试使用本地 PaddleOCR；识别到明确的额度/限流错误后，网页会把后续模式切换为 Paddle 本地，避免对已达上限的云端接口反复请求。
- 可提前预加载 Paddle 本地备用模型，强烈建议在额度用完之前、网络较好的时候点击一次。
- 保留手机拍照/相册多选、单张顺序识别、人工审核、IndexedDB 本地保存、TSV/CSV 导出和字段备份/恢复。
- 照片不会作为 GitHub 仓库内容提交。OCR.space 模式会把压缩后的图片上传给 OCR.space；Paddle 模式在浏览器内推理，但首次需要联网获取 SDK 模型资产。

## 部署到现有仓库
项目适用于当前 `acly20-bot/mingpai-ocr` 仓库的 GitHub Actions 工作流，该工作流监听根目录的 `paddleocr-mingpai-project.zip`。构建时会将 ONNX Runtime 的 `.wasm` 与动态导入的 `.mjs` 文件一起复制到 `dist/ort/`，避免运行时请求 `.mjs` 资源得到 404。

1. 在本项目 ZIP 中不要单独上传 `index.html`；保持整个 ZIP 文件名为 `paddleocr-mingpai-project.zip`。
2. 在 GitHub 仓库根目录用此 ZIP 替换原同名 ZIP 并 Commit。
3. 保留 `.github/workflows/deploy-paddleocr.yml` 不动。它会触发 Vite 构建、运行 `prepare-assets.mjs` 复制 ORT WASM，然后发布 `dist/` 到 Pages。
4. 在 Actions 确认最新 `Deploy PaddleOCR Mingpai to GitHub Pages` 成功。
5. 用 `https://acly20-bot.github.io/mingpai-ocr/?v=dual1` 打开网页。

## 初次设置
1. 申请 OCR.space Key：<https://ocr.space/ocrapi/freekey>
2. 在网页选择“自动优先 OCR.space”，粘贴 Key 并保存。默认为 Engine 2。
3. 点击“提前加载 Paddle 备用模型”测试备用引擎能否在当前手机上加载。首次可能需要较长时间，请保持网页前台并使用稳定网络。
4. 测试 5–10 张铭牌，再正式批量盘点。

## 限额和费用提醒
OCR.space 官方免费计划目前列出的上限为每月 25,000 次，且每个 IP 每日 500 次；Engine 3 另有 1,000 次/月额度，单张文件上限 1 MB。额度、接口政策可能变化，以官方页面为准。自动模式检测到限制后会自动切换 Paddle；Paddle 本地识别不按 API 调用次数收费，但需要手机算力和首次模型下载，不能保证每台手机都能顺利初始化。

## 隐私与 API Key
- API Key 存储在当前手机浏览器 localStorage，不放入公开 GitHub 仓库；清除网站数据会清除 Key。
- OCR.space 模式会将图片传输至 OCR.space 服务；如单位不允许上传铭牌照片至第三方，不要使用云端模式，改选 Paddle 本地模式。
- Paddle 模型资源由 SDK 在首次使用时联网获取，后续能否直接复用取决于浏览器缓存和服务端缓存头。建议先预加载和测试，不要等云端限额耗尽时才第一次尝试。
- 记录保存在当前手机浏览器 IndexedDB，不会跨设备同步；定期导出 JSON 备份。

## 重要说明
- 这份源码提供了双引擎流程和构建配置；由于此会话无法在目标手机直接完成实机验收，实际页面构建与 Paddle 模型下载仍应以 GitHub Actions 和手机测试结果为准。
- GitHub Pages 只是静态托管，没有后台私密代理。因此前端 OCR.space API Key 虽不会提交到代码仓库，但它在本机浏览器中可见；请只在自己的设备/可信使用者设备上输入 Key。
- 腾讯文档写入尚未通过官方接口自动化。审核完成后仍可复制 TSV 或下载 CSV，导入现有智能表格。


## 本次修复说明
- 修复 `no available backend found` / `Failed to fetch dynamically imported module: ...ort-wasm-simd-threaded.jsep.mjs`：原构建脚本只复制 `.wasm` 二进制，没有复制 ONNX Runtime 动态加载的 `.mjs` 模块。
- `scripts/prepare-assets.mjs` 现在复制同一 ONNX Runtime 版本的 `.wasm`、`.mjs`、`.js` 和 `.data` 运行时文件，并在构建阶段检查 `.mjs` 是否存在；缺失时构建直接失败，不再发布一个运行时必错的网页。


### 修复 GitHub Pages 上的 ORT 模块 404
当前部署出现 `Failed to fetch dynamically imported module: .../ort/ort-wasm-simd-threaded.jsep.mjs`，根因是先前 `prepare-assets.mjs` 只把 `.wasm` 二进制复制到了 `public/ort/`，没有把同版本 ONNX Runtime 的 `.mjs` 动态模块复制过去。修正版会一起复制 `.mjs`、`.wasm`、`.js`、`.data` 运行时文件，并强制检查 `ort-wasm-simd-threaded.jsep.mjs` 与对应 `.jsep.wasm`；任一缺失都会在 GitHub Actions 构建阶段明确失败，避免再次发布一个不完整的站点。
