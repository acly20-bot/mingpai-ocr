# 设备铭牌 OCR 双引擎版：OCR.space 优先 + PaddleOCR.js 备用（已回退到验证过的默认配置）

## 功能
- 默认优先 OCR.space；遇到明确额度/限流错误或云端请求失败时，可切到本地 PaddleOCR.js；也可手动选择仅使用其中一个引擎。
- OCR.space Engine 2 为默认云端引擎；API Key 保存在当前手机浏览器的 localStorage，不提交到仓库。
- Paddle 本地备用引擎使用 `@paddleocr/paddleocr-js@0.4.2` 的内置 PP-OCRv6 模型解析方式，并在初始化失败时回退 PP-OCRv5。
- 保留手机拍照/相册多选、逐张顺序识别、人工审核、IndexedDB 本地保存、TSV/CSV 导出和字段备份/恢复。

## 为什么这次改了 Paddle 初始化方式
之前双引擎版本把原来成功的初始化方式改成了自定义模型 TAR URL、手动 `wasmPaths` 和 `worker: true`。这些覆盖参数与之前单引擎版的成功配置不同，是双引擎版初始化超过 180 秒的主要可疑差异。

现在改回此前已在你的手机上成功识别的配置：

```js
await PaddleOCR.create({
  lang: 'ch',
  ocrVersion: 'PP-OCRv6',
  worker: false,
  ortOptions: { backend: 'auto' }
});
```

并在 PP-OCRv6 失败时尝试 PP-OCRv5。当前版本不再自建/下载模型 TAR 文件，也不覆盖 ORT WASM 路径；由固定版本的 SDK 按自身默认逻辑加载模型及运行时。官方 SDK 文档支持通过 `lang`、`ocrVersion` 与 `backend: 'auto'` 选择默认模型/运行时，且明确自定义模型包需要满足 TAR 格式、模型文件和 model_name 匹配等约束。参见 <https://github.com/PaddlePaddle/PaddleOCR/blob/main/paddleocr-js/packages/core/README.md>。

## 部署到现有仓库
适用于 `acly20-bot/mingpai-ocr` 的现有 GitHub Actions 工作流，它监听仓库根目录的 `paddleocr-mingpai-project.zip`。

1. 将本项目 ZIP 命名为 `paddleocr-mingpai-project.zip`（下载文件已是此名称）。
2. 在 GitHub 仓库根目录上传并替换同名 ZIP，然后 Commit。
3. 保留 `.github/workflows/deploy-paddleocr.yml` 不动。它执行 `npm install && npm run build`，然后发布 `dist/` 到 Pages。
4. 在 Actions 中确认最新 `Deploy PaddleOCR Mingpai to GitHub Pages` 成功。
5. 打开 `https://acly20-bot.github.io/mingpai-ocr/?v=dual5`，测试 OCR.space 和 Paddle 两种模式。

## 初次设置
1. 申请 OCR.space Key：<https://ocr.space/ocrapi/freekey>
2. 网页选择“自动优先 OCR.space”，输入 Key 并保存。
3. 在网络稳定时点击“提前加载 Paddle 备用模型”，等到明确显示模型加载完成，再测试一张照片。
4. 测试 5–10 张真实铭牌，再进行正式批量盘点。

## 免费额度、隐私与限制
- OCR.space 免费额度与限流规则以服务商当前页面为准；云端模式会上传照片到 OCR.space。
- Paddle 本地识别不按调用次数收费，但首次加载默认模型仍需要网络，模型服务器不可达时可能失败。
- API Key 保存在当前手机浏览器，不写入公开仓库。GitHub Pages 是静态网站，没有后台私密代理，因此仅建议在可信设备使用 Key。
- 识别记录保存于当前手机浏览器 IndexedDB，不会跨设备同步；请定期导出 JSON 备份。
- 腾讯文档写入尚未自动连接；审核完成后可复制 TSV 或下载 CSV，再导入/粘贴到现有智能表格。
- 本版本源代码已检查，但需以 GitHub Actions 构建结果和手机实测作为最终验收。
