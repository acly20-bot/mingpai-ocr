# 铭牌 OCR 双引擎 + 飞书多维表格同步

本项目保留当前已验证的双引擎识别流程：

- 默认优先 OCR.space 云端 OCR。
- OCR.space 限额、网络或服务异常时，可自动切换到 PaddleOCR.js + PP-OCRv6 本地备用。
- 支持手动选择仅 OCR.space 或仅 PaddleOCR。
- 保留拍照、相册批量上传、重新识别、Paddle 本地重识别、人工审核、本地 IndexedDB 缓存、JSON 备份、CSV/TSV 导出。

## 当前业务字段

飞书多维表格共 10 列：

1. 单位名称
2. 科室
3. 检定日期
4. 检定员
5. 铭牌文本
6. 设备名称
7. 生产厂家
8. 型号
9. 出厂编号
10. 备注

单位名称、科室、检定日期、检定员不参与 OCR。备注默认留空，由检定员按需手工填写。

科室逻辑：第一台设备可手动填写；修改某条记录的科室后，页面顶部“当前科室”同步更新，之后新增设备自动继承该科室。

## 云端同步

前端通过 Cloudflare Worker 调用飞书多维表格 REST API。Worker 需要：

- `FEISHU_APP_ID`
- `FEISHU_APP_SECRET`
- `MINGPAI_SHARED_KEY`
- KV binding：`SYNC_IDS`

默认飞书多维表格：

- app_token: `Oe3ubge2XaLKYfsbU3Icbauynfh`
- table_id: `tblY23a6dtc9oOao`

`FEISHU_APP_SECRET` 只保存在 Cloudflare Worker Secret，不放进网页或 GitHub。
