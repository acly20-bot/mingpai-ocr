# 设备铭牌识别网页（Tesseract.js 本地版）

目标：在手机浏览器中直接拍照/上传设备铭牌，使用开源 OCR 在本机识别中文和英文；记录先保存至当前浏览器 IndexedDB，由用户校对确认，再复制 TSV 或下载 CSV 导入腾讯文档智能表格。

## 部署方式

此项目专为现有仓库 `acly20-bot/mingpai-ocr` 的 GitHub Actions 流程打包。仓库工作流会把该 zip 解压到 `app/`，执行 `npm install && npm run build`，再发布 `app/dist`。

- `tesseract.js` 固定为 7.0.0。
- `vite` 固定为 7.3.7。
- 构建时 `scripts/prepare-assets.mjs` 会从 npm 依赖中复制 Worker 和全部 Tesseract WASM core 变体，并从 `tessdata.projectnaptha.com/4.0.0` 下载 `chi_sim` 和 `eng` 的压缩语言模型。
- 运行时 Worker、WASM 与模型从本网站的 `/mingpai-ocr/` 路径加载；不依赖浏览器额外访问 jsDelivr 来下载运行时或模型。
- 识别图片不上传到第三方 OCR API。首次加载模型仍需要联网；Tesseract.js 将语言数据缓存到浏览器 IndexedDB。

## 重要限制

- 网页本身静态托管免费，但 GitHub Pages 的可用性和免费政策由 GitHub 决定。
- 手机需要在首次加载时联网下载约数十 MB 的程序/语言资源。浏览器清理网站数据后需要再次下载。
- 每次只用一个 Worker 串行识别，避免多个 Worker 并行占用过多内存。
- 单张图片在识别前会统一处理尺寸：超大图最长边限制为 3200 px，小图片最长边在需要时放大到 1400 px，保留 RGB 色彩并使用高质量 JPEG 编码；不进行强烈二值化，以免破坏金属铭牌字符。
- 每张图片会先创建待审核记录，再开始识别。失败时保留记录并可点击“重新识别（选择照片）”。为了避免长期累积占满手机空间，失败重试需要重新选择原照片；本地保存的缩略图用于审核预览。
- 数据仅保存在当前手机浏览器，不会自动同步。清理浏览器数据前先下载 JSON 字段备份。
- 当前版本不自动写入腾讯文档。审核确认后使用 TSV 复制或 CSV 导入原智能表格。

## 构建本地资源

`npm run build` 会先执行 `prebuild` 脚本自动准备运行时和语言文件，然后运行 Vite 构建。GitHub Actions 所用 Node.js 22 支持内置 `fetch` 和 `AbortSignal.timeout`。
