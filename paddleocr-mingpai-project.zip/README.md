# 设备铭牌 OCR：PaddleOCR PP-OCRv6 免费浏览器版

本项目使用官方 PaddleOCR.js 在手机浏览器本地识别。优先初始化 PP-OCRv6；为规避部分手机浏览器在 Worker 通信期间出现的 `Detection model timed out after 60s`，当前改为主线程运行，并使用 SDK 文档中的 `backend: "auto"`，不再指定单独的 Worker 或外部 ONNX Runtime CDN 路径。若 PP-OCRv6 初始化失败，会自动尝试 PP-OCRv5 兼容模型。首次使用仍需联网下载模型，速度取决于网络与手机性能。照片在本机浏览器中处理，不通过 OCR API 上传。

项目仍保留原有功能：手机拍照/相册多选、人工审核、IndexedDB 本地保存、TSV/CSV 导出。腾讯文档写入仍使用复制 TSV 或 CSV 导入，不直接调用腾讯文档 API。

## 部署到现有 GitHub 仓库

此项目通过 GitHub Actions 运行 Vite 构建，适合部署到 `acly20-bot/mingpai-ocr`。不要把 ZIP 解压后的内容直接当作 `index.html` 使用：必须先构建，GitHub Actions 会自动完成。

### A. 上传项目 ZIP

把 `paddleocr-mingpai-project.zip` 上传到仓库 `acly20-bot/mingpai-ocr` 根目录。这个 ZIP 里有 `index.html`、`package.json`、`vite.config.js` 和 `src/main.js`。

### B. 先切换 Pages 部署来源

在仓库 **Settings → Pages → Build and deployment → Source** 改成 **GitHub Actions**。如果页面提示选择工作流，先跳过或返回，不要选旧的 branch 部署。

在仓库主页点击 **Add file → Create new file**。
文件名填写：

`.github/workflows/deploy-paddleocr.yml`

把下面内容完整粘贴进去，再点击 **Commit changes**：

```yaml
name: Deploy PaddleOCR Mingpai to GitHub Pages

on:
  push:
    branches: [main]
    paths:
      - 'paddleocr-mingpai-project.zip'
      - '.github/workflows/deploy-paddleocr.yml'
  workflow_dispatch:

permissions:
  contents: read
  pages: write
  id-token: write

concurrency:
  group: pages
  cancel-in-progress: true

jobs:
  deploy:
    environment:
      name: github-pages
      url: ${{ steps.deployment.outputs.page_url }}
    runs-on: ubuntu-latest
    steps:
      - name: Checkout repository
        uses: actions/checkout@v4
      - name: Configure Pages
        uses: actions/configure-pages@v5
      - name: Set up Node.js
        uses: actions/setup-node@v4
        with:
          node-version: 22
      - name: Extract application project
        run: unzip -oq paddleocr-mingpai-project.zip -d app
      - name: Install dependencies and build
        working-directory: app
        run: npm install && npm run build
      - name: Upload Pages artifact
        uses: actions/upload-pages-artifact@v3
        with:
          path: app/dist
      - name: Deploy to GitHub Pages
        id: deployment
        uses: actions/deploy-pages@v4
```

### C. 等待自动构建发布

提交工作流后，打开 **Actions** 标签页，等 `Deploy PaddleOCR Mingpai to GitHub Pages` 运行成功。

成功后的网页地址：`https://acly20-bot.github.io/mingpai-ocr/`

## 说明

- OCR SDK: `@paddleocr/paddleocr-js` 0.4.2；优先使用 PP-OCRv6 (`lang: ch`)，初始化失败时自动回退 PP-OCRv5。
- 当前采用主线程和 `backend: "auto"`，目的是避开个别移动浏览器中 Worker 初始化超时；OCR 运行期间界面响应可能会短暂变慢。
- 不承诺所有铭牌都能正确识别；拍摄质量、字体、反光、倾斜和手机性能都会影响结果。必须人工核对，尤其是出厂编号。
- 大量照片建议一批 10–20 张，并保持网页在前台；手机内存不足时分批处理。
- 浏览器本地记录和旧版本使用相同 IndexedDB 名称，因此旧记录原则上会保留。更新网页前请先导出字段备份。
- GitHub Pages 的代码仓库是公开的。网页代码公开不等于手机 IndexedDB 数据公开；不要把设备照片、台账数据或密钥提交到仓库。
