# 设备铭牌 OCR：OCR.space 云端识别版（免费计划）

此版本不在手机本地加载 PaddleOCR 模型，而是将压缩后的铭牌图像发送到 OCR.space OCR API 识别，以避免手机模型下载/Worker 初始化卡死。

## 免费额度与限制

根据 OCR.space 官方说明，免费 API 计划包含：
- Engine 2：每月 25,000 次请求；每个 IP 每天最多 500 次；单个图片文件限制 1 MB。
- Engine 3：额外每月 1,000 次，官方称其对复杂文字/版面更准确，但处理较慢。
- Engine 2 支持简体/繁体中文与英文混排，并自动检测语言。

实际可用性、免费限额和服务政策以 OCR.space 官方网站当前说明为准。10,000 次/月平均约 333 次/天，符合每日 500 次上限，但如果集中在同一天批量调用超过 500 次就会触发日限制。

## 先申请免费 API Key

1. 打开 https://ocr.space/ocrapi/freekey
2. 填写邮箱申请免费 API Key。
3. 打开本项目网页，在“OCR.space 免费 API Key”框粘贴 Key，选择 Engine 2，点“保存识别设置”。Key 仅存储在当前浏览器 localStorage 中，不会被写入 GitHub 仓库代码。
4. 上传或拍摄铭牌。网页会先将照片转换/压缩到 1 MB 以下，再上传到 OCR.space。
5. 检查每条识别结果并手动确认，最后复制 TSV 或下载 CSV 导入腾讯文档。

## Engine 2 / Engine 3 怎么选

- 日常默认 Engine 2，适合多数中英文铭牌，免费计划 25,000 次/月。
- 仅对复杂、倾斜或小字照片，重新选择 Engine 3 识别；Engine 3 仅有 1,000 次/月额度。

注意当前页面每次上传都会按所选引擎发起 OCR 请求。若从 Engine 2 换 Engine 3，需要重新上传该照片才能重新识别。

## 数据和密钥说明

- 与原来本地 PaddleOCR 版本不同，照片会传输给第三方 OCR.space 服务器进行识别。OCR.space 隐私政策说明，上传文档处理后删除，但会记录请求 IP 约一个月。不要上传病人信息、身份证件或其他不应外传的敏感数据；单位有数据外传限制时，先取得许可。
- API Key 不写入公开仓库，但保存在浏览器本地，并在每次 API 请求中使用。不要把同一网页和已保存的 Key 交给不可信人员；如果怀疑 Key 泄露，可联系服务方更换。
- 该项目仍通过 IndexedDB 将盘点字段保存在当前手机浏览器；不跨设备同步。
- 腾讯文档写入暂未自动化，仍然是人工确认后复制 TSV/下载 CSV 导入。

## 部署到现有 GitHub 仓库

用此项目中的 `paddleocr-mingpai-project.zip` 替换 GitHub 仓库根目录同名 ZIP 并 Commit。现有 `.github/workflows/deploy-paddleocr.yml` 会自动运行 Vite 构建并部署到 GitHub Pages；无需更改工作流。

ZIP 内含 `index.html`、`src/main.js`、`package.json` 和 `vite.config.js`。不要把 ZIP 解压后的文件只当作普通 HTML 单独上传；保持原来的 GitHub Actions 构建流程。
