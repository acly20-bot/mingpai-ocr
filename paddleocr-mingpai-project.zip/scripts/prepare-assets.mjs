import { mkdir, readdir, copyFile, stat } from 'node:fs/promises';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { createRequire } from 'node:module';

const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const publicDir = path.join(root, 'public');
const ortOut = path.join(publicDir, 'ort');
await mkdir(ortOut, { recursive: true });

const appRequire = createRequire(import.meta.url);
let resolvedEntry = '';
const resolveAttempts = [
  () => appRequire.resolve('onnxruntime-web'),
  () => createRequire(path.join(root, 'node_modules/@paddleocr/paddleocr-js/package.json')).resolve('onnxruntime-web')
];
for (const attempt of resolveAttempts) {
  try { resolvedEntry = attempt(); break; } catch {}
}
if (!resolvedEntry) throw new Error('无法定位 PaddleOCR.js 依赖的 onnxruntime-web。请确认 npm install 成功。');

// Usually the package entry is in node_modules/onnxruntime-web/dist/.
// Walk upwards until locating the dist folder containing ORT runtime assets.
let dir = path.dirname(resolvedEntry);
let distDir = null;
for (let i = 0; i < 5; i++) {
  try {
    const files = await readdir(dir);
    if (files.some(name => /^ort-wasm.*\.wasm$/i.test(name))) {
      distDir = dir;
      break;
    }
  } catch {}
  dir = path.dirname(dir);
}
if (!distDir) {
  // Package entry may be outside the dist directory. Check the adjacent dist folder.
  const candidates = [
    path.join(path.dirname(resolvedEntry), 'dist'),
    path.resolve(path.dirname(resolvedEntry), '../dist'),
    path.resolve(root, 'node_modules/onnxruntime-web/dist'),
  ];
  for (const candidate of candidates) {
    try {
      const files = await readdir(candidate);
      if (files.some(name => /^ort-wasm.*\.wasm$/i.test(name))) { distDir = candidate; break; }
    } catch {}
  }
}
if (!distDir) {
  throw new Error(`在 onnxruntime-web 中找不到 ORT WASM 文件，解析入口：${resolvedEntry}`);
}

// ORT's WASM backend dynamically imports an .mjs factory module in addition to
// downloading the .wasm binary. Copying only .wasm files causes errors such as
// `Failed to fetch dynamically imported module: ...ort-wasm-simd-threaded.jsep.mjs`.
// Keep the entire runtime asset family from the exact installed ORT version together.
const runtimeAssets = (await readdir(distDir)).filter(name =>
  /^ort-(?:wasm|training-wasm).*\.(?:wasm|mjs|js|data)$/i.test(name)
);
if (!runtimeAssets.some(name => /\.wasm$/i.test(name))) {
  throw new Error(`ORT WASM 二进制文件不存在：${distDir}`);
}
if (!runtimeAssets.some(name => /^ort-wasm-simd-threaded\.jsep\.mjs$/i.test(name))) {
  throw new Error(`缺少 ort-wasm-simd-threaded.jsep.mjs：${distDir}。ONNX Runtime 在手机端请求的动态模块必须与当前版本一起发布。`);
}
if (!runtimeAssets.some(name => /^ort-wasm-simd-threaded\.jsep\.wasm$/i.test(name))) {
  throw new Error(`缺少 ort-wasm-simd-threaded.jsep.wasm：${distDir}。请检查 onnxruntime-web 包版本。`);
}
for (const name of runtimeAssets) {
  const from = path.join(distDir, name);
  const to = path.join(ortOut, name);
  await copyFile(from, to);
  const info = await stat(to);
  console.log(`Hosted ORT ${name}: ${(info.size / 1024 / 1024).toFixed(2)} MB`);
}
console.log(`Copied ${runtimeAssets.length} ONNX Runtime assets to public/ort, including dynamically imported .mjs files.`);
console.log('PaddleOCR model archives are loaded lazily by the SDK when local OCR is first selected.');
