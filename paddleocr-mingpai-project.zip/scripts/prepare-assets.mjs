import { mkdir, readdir, copyFile, writeFile, stat } from 'node:fs/promises';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const publicDir = path.join(root, 'public');
const runtimeDir = path.join(publicDir, 'tesseract');
const coreOut = path.join(runtimeDir, 'core');
const tessdataOut = path.join(publicDir, 'tessdata');
await mkdir(runtimeDir, { recursive: true });
await mkdir(coreOut, { recursive: true });
await mkdir(tessdataOut, { recursive: true });

async function findFiles(dir, predicate) {
  const out = [];
  for (const entry of await readdir(dir, { withFileTypes: true })) {
    const full = path.join(dir, entry.name);
    if (entry.isDirectory()) out.push(...await findFiles(full, predicate));
    else if (predicate(entry.name)) out.push(full);
  }
  return out;
}

const tesseractRoot = path.join(root, 'node_modules', 'tesseract.js');
const coreRoot = path.join(root, 'node_modules', 'tesseract.js-core');
const workerCandidates = await findFiles(tesseractRoot, name => name === 'worker.min.js');
if (!workerCandidates.length) throw new Error('未找到 tesseract.js 的 worker.min.js；请检查依赖安装是否成功。');
await copyFile(workerCandidates[0], path.join(runtimeDir, 'worker.min.js'));

const coreCandidates = await findFiles(coreRoot, name => /^tesseract-core.*\.(?:js|wasm)$/.test(name));
const needed = [
  'tesseract-core.wasm.js',
  'tesseract-core-simd.wasm.js',
  'tesseract-core-lstm.wasm.js',
  'tesseract-core-simd-lstm.wasm.js',
];
const coreNames = new Set(coreCandidates.map(file => path.basename(file)));
const missing = needed.filter(name => !coreNames.has(name));
if (missing.length) throw new Error(`tesseract.js-core 缺少运行文件：${missing.join(', ')}`);
for (const file of coreCandidates) {
  await copyFile(file, path.join(coreOut, path.basename(file)));
}

// Self-host the language files so the browser does not depend on a separate CDN.
// Tesseract.js v7 supports the 4.0.0 traineddata endpoint and gzip=true.
const modelBase = 'https://tessdata.projectnaptha.com/4.0.0';
for (const lang of ['chi_sim', 'eng']) {
  const filename = `${lang}.traineddata.gz`;
  const destination = path.join(tessdataOut, filename);
  const url = `${modelBase}/${filename}`;
  console.log(`Downloading ${filename} from ${url}`);
  const response = await fetch(url, { signal: AbortSignal.timeout(240_000) });
  if (!response.ok) throw new Error(`下载模型失败：${url} HTTP ${response.status}`);
  const arrayBuffer = await response.arrayBuffer();
  if (arrayBuffer.byteLength < 100_000) throw new Error(`模型文件异常或不完整：${filename} (${arrayBuffer.byteLength} bytes)`);
  await writeFile(destination, new Uint8Array(arrayBuffer));
  const info = await stat(destination);
  console.log(`Saved ${filename}: ${(info.size / 1024 / 1024).toFixed(1)} MB`);
}

console.log('Tesseract.js runtime and Chinese/English models are ready for Vite build.');
