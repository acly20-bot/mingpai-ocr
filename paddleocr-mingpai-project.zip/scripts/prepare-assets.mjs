import { mkdir, readdir, copyFile, stat } from 'node:fs/promises';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { createRequire } from 'node:module';

const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const publicDir = path.join(root, 'public');
const ortOut = path.join(publicDir, 'ort');
await mkdir(ortOut, { recursive: true });

const appRequire = createRequire(import.meta.url);
let resolvedEntry = '';
const resolveAttempts = [
  () => appRequire.resolve('onnxruntime-web'),
  () => createRequire(path.join(root, 'node_modules/@paddleocr/paddleocr-js/package.json')).resolve('onnxruntime-web')
];
for (const attempt of resolveAttempts) {
  try { resolvedEntry = attempt(); break; } catch {}
}
if (!resolvedEntry) throw new Error('无法定位 PaddleOCR.js 依赖的 onnxruntime-web。请确认 npm install 成功。');

// Usually the package entry is in node_modules/onnxruntime-web/dist/.
// Walk upwards until locating the dist folder containing ORT runtime assets.
let dir = path.dirname(resolvedEntry);
let distDir = null;
for (let i = 0; i < 5; i++) {
  try {
    const files = await readdir(dir);
    if (files.some(name => /^ort-wasm.*\.wasm$/i.test(name))) {
      distDir = dir;
      break;
    }
  } catch {}
  dir = path.dirname(dir);
}
if (!distDir) {
  // Package entry may be outside the dist directory. Check the adjacent dist folder.
  const candidates = [
    path.join(path.dirname(resolvedEntry), 'dist'),
    path.resolve(path.dirname(resolvedEntry), '../dist'),
    path.resolve(root, 'node_modules/onnxruntime-web/dist'),
  ];
  for (const candidate of candidates) {
    try {
      const files = await readdir(candidate);
      if (files.some(name => /^ort-wasm.*\.wasm$/i.test(name))) { distDir = candidate; break; }
    } catch {}
  }
}
if (!distDir) {
  throw new Error(`在 onnxruntime-web 中找不到 ORT WASM 文件，解析入口：${resolvedEntry}`);
}

const wasmFiles = (await readdir(distDir)).filter(name => /^ort-wasm.*\.wasm$/i.test(name));
if (!wasmFiles.length) throw new Error(`ORT WASM 文件不存在：${distDir}`);
for (const name of wasmFiles) {
  const from = path.join(distDir, name);
  const to = path.join(ortOut, name);
  await copyFile(from, to);
  const info = await stat(to);
  console.log(`Hosted ORT ${name}: ${(info.size / 1024 / 1024).toFixed(2)} MB`);
}
console.log('ONNX Runtime WASM assets copied to public/ort. PaddleOCR model archives are loaded lazily by the SDK when local OCR is first selected.');
