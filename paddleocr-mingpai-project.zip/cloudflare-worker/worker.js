/**
 * Cloudflare Worker: safe Tencent Docs SmartSheet sync for Mingpai OCR.
 * Secrets (Cloudflare Worker Settings -> Variables and Secrets):
 *   TENCENT_DOCS_TOKEN  - raw personal token from docs.qq.com/open/auth/mcp.html
 *   MINGPAI_SHARED_KEY  - random shared key given only to authorized inventory users
 * KV binding:
 *   SYNC_IDS -> a Cloudflare KV namespace, used for idempotency mappings
 * Plain vars (optional): DOC_ID, SHEET_ID
 */
const MCP_URL = 'https://docs.qq.com/openapi/mcp';
const DEFAULT_DOC_ID = 'DTW9nTUROa2RkeUVx';
const DEFAULT_SHEET_ID = 't00i2h';
const ALLOWED_ORIGIN = 'https://acly20-bot.github.io';
const REQUIRED_FIELDS = ['科室', '日期', '铭牌文本', '设备名称', '生产厂家', '型号', '编号'];
const EXTRA_FIELDS = ['录入人员', '本地记录ID'];

function json(data, status = 200, origin = ALLOWED_ORIGIN) {
  return new Response(JSON.stringify(data), {
    status,
    headers: {
      'Content-Type': 'application/json; charset=utf-8',
      'Cache-Control': 'no-store',
      'Access-Control-Allow-Origin': origin,
      'Access-Control-Allow-Methods': 'GET, POST, OPTIONS',
      'Access-Control-Allow-Headers': 'Content-Type, X-Mingpai-Key',
      'Access-Control-Max-Age': '86400',
      'Vary': 'Origin'
    }
  });
}
function text(value) { return String(value ?? '').trim(); }
function docId(env) { return text(env.DOC_ID) || DEFAULT_DOC_ID; }
function sheetId(env) { return text(env.SHEET_ID) || DEFAULT_SHEET_ID; }
function getOrigin(request) { return request.headers.get('Origin') || ''; }
function requireConfig(env) {
  if (!env.TENCENT_DOCS_TOKEN) throw new Error('Cloudflare 尚未设置 TENCENT_DOCS_TOKEN 密钥。');
  if (!env.MINGPAI_SHARED_KEY) throw new Error('Cloudflare 尚未设置 MINGPAI_SHARED_KEY 密钥。');
  if (!env.SYNC_IDS) throw new Error('Cloudflare 尚未绑定名为 SYNC_IDS 的 KV 命名空间。');
}
function getRpcObject(raw, requestId) {
  if (!raw || !raw.trim()) return null;
  try { return JSON.parse(raw); } catch {}
  const candidates = [];
  // Streamable HTTP may return JSON-RPC messages over Server-Sent Events.
  for (const block of raw.split(/\r?\n\r?\n/)) {
    const data = block.split(/\r?\n/).filter(line => line.startsWith('data:')).map(line => line.slice(5).trim()).join('\n');
    if (!data || data === '[DONE]') continue;
    try { candidates.push(JSON.parse(data)); } catch {}
  }
  return candidates.find(item => item && (item.id === requestId || item.error)) || candidates.at(-1) || null;
}
async function mcpPost(env, body, sessionId = '', protocolVersion = '2025-03-26') {
  const headers = new Headers({
    'Authorization': text(env.TENCENT_DOCS_TOKEN),
    'Content-Type': 'application/json',
    'Accept': 'application/json, text/event-stream'
  });
  if (sessionId) headers.set('Mcp-Session-Id', sessionId);
  if (body.method !== 'initialize') headers.set('MCP-Protocol-Version', protocolVersion);
  const response = await fetch(MCP_URL, { method: 'POST', headers, body: JSON.stringify(body) });
  const newSessionId = response.headers.get('Mcp-Session-Id') || sessionId;
  const raw = await response.text();
  if (!response.ok) {
    const extra = raw.slice(0, 1200);
    if (/400007|VIP权限不足|VIP/i.test(extra)) throw new Error('腾讯文档返回 VIP 权限不足（400007）。当前账号的 MCP 写入能力可能需要 VIP。');
    if (/400006|鉴权失败|token/i.test(extra) && response.status === 401) throw new Error('腾讯文档 Token 鉴权失败，请在 Cloudflare 密钥中重新设置 Token。');
    throw new Error(`腾讯文档 MCP HTTP ${response.status}：${extra || response.statusText}`);
  }
  const parsed = getRpcObject(raw, body.id);
  if (parsed?.error) {
    const err = typeof parsed.error === 'string' ? parsed.error : JSON.stringify(parsed.error);
    if (/400007|VIP权限不足|VIP/i.test(err)) throw new Error('腾讯文档返回 VIP 权限不足（400007）。当前账号的 MCP 写入能力可能需要 VIP。');
    if (/400006|鉴权失败/i.test(err)) throw new Error('腾讯文档 Token 鉴权失败，请在 Cloudflare 密钥中重新设置 Token。');
    throw new Error(`腾讯文档 MCP 错误：${err}`);
  }
  return { parsed, sessionId: newSessionId, status: response.status, raw };
}
async function mcpTool(env, toolName, args) {
  // Open a short-lived MCP session for each operation; the official endpoint uses
  // Authorization: <token> and tools/call with the tool's documented arguments.
  let init;
  let initResult;
  let protocolVersion = '2025-03-26';
  try {
    init = await mcpPost(env, {
      jsonrpc: '2.0', id: 1, method: 'initialize',
      params: {
        protocolVersion: '2025-03-26',
        capabilities: {},
        clientInfo: { name: 'mingpai-tencent-sync', version: '1.0.0' }
      }
    });
    initResult = init.parsed?.result;
  } catch (error) {
    // A server that only supports an earlier protocol may reject the first revision.
    if (!/protocol|version|HTTP 400|invalid request/i.test(error?.message || '')) throw error;
  }
  if (!initResult?.protocolVersion) {
    protocolVersion = '2024-11-05';
    init = await mcpPost(env, {
      jsonrpc: '2.0', id: 1, method: 'initialize',
      params: {
        protocolVersion: '2024-11-05',
        capabilities: {},
        clientInfo: { name: 'mingpai-tencent-sync', version: '1.0.0' }
      }
    }, '', protocolVersion);
    initResult = init.parsed?.result;
  }
  const sid = init.sessionId || '';
  if (!initResult) throw new Error('腾讯文档 MCP 初始化未返回协议结果。请检查 Token 是否有效以及官方 MCP 服务是否可用。');
  try {
    await mcpPost(env, { jsonrpc: '2.0', method: 'notifications/initialized' }, sid, protocolVersion);
  } catch (e) {
    // A stateless MCP endpoint may not require a notification response; continue to tools/call.
    if (!/HTTP 400|HTTP 404|HTTP 405/i.test(e.message || '')) throw e;
  }
  const call = await mcpPost(env, {
    jsonrpc: '2.0', id: 2, method: 'tools/call', params: { name: toolName, arguments: args }
  }, sid, protocolVersion);
  if (!call.parsed?.result) throw new Error(`腾讯文档 MCP 没有返回 ${toolName} 的工具结果。`);
  const toolResult = call.parsed.result;
  if (toolResult.isError) {
    const message = (toolResult.content || []).map(part => part.text || '').join('\n') || JSON.stringify(toolResult);
    if (/400007|VIP权限不足|VIP/i.test(message)) throw new Error('腾讯文档返回 VIP 权限不足（400007）。当前账号的 MCP 写入能力可能需要 VIP。');
    if (/400006|鉴权失败/i.test(message)) throw new Error('腾讯文档 Token 鉴权失败，请重新获取并更新 Cloudflare 密钥。');
    throw new Error(`腾讯文档工具 ${toolName} 调用失败：${message}`);
  }
  if (toolResult.structuredContent && typeof toolResult.structuredContent === 'object') return toolResult.structuredContent;
  const contentText = (toolResult.content || []).filter(part => part.type === 'text').map(part => part.text || '').join('\n').trim();
  if (!contentText) return toolResult;
  try { return JSON.parse(contentText); } catch {}
  // Some MCP servers add a sentence/code fence around JSON; extract the outer object if possible.
  const first = contentText.indexOf('{');
  const last = contentText.lastIndexOf('}');
  if (first >= 0 && last > first) {
    try { return JSON.parse(contentText.slice(first, last + 1)); } catch {}
  }
  throw new Error(`无法解析腾讯文档 ${toolName} 的返回结果：${contentText.slice(0, 1000)}`);
}
function resultArray(payload, key) {
  if (Array.isArray(payload?.[key])) return payload[key];
  if (Array.isArray(payload?.data?.[key])) return payload.data[key];
  if (Array.isArray(payload?.result?.[key])) return payload.result[key];
  return null;
}
async function listFields(env) {
  const payload = await mcpTool(env, 'smartsheet.list_fields', { file_id: docId(env), sheet_id: sheetId(env) });
  const fields = resultArray(payload, 'fields');
  if (!fields) throw new Error('无法读取腾讯文档字段列表：' + JSON.stringify(payload).slice(0, 1200));
  return fields;
}
async function ensureSetup(env) {
  const tablesPayload = await mcpTool(env, 'smartsheet.list_tables', { file_id: docId(env) });
  const sheets = resultArray(tablesPayload, 'sheets');
  if (!sheets) throw new Error('无法获取工作表列表：' + JSON.stringify(tablesPayload).slice(0, 1200));
  const matched = sheets.find(sheet => String(sheet.sheet_id) === sheetId(env));
  if (!matched) {
    const available = sheets.map(sheet => `${sheet.title || sheet.name || '(未命名)'} (sheet_id=${sheet.sheet_id})`).join('；');
    throw new Error(`未找到 URL 中 tab=${sheetId(env)} 对应的 sheet_id。可用工作表：${available || '（接口未返回工作表）'}。请将 Cloudflare 变量 SHEET_ID 改成上面正确的 sheet_id 后重试。`);
  }
  let fields = await listFields(env);
  const titles = new Set(fields.map(field => field.field_title));
  const missingBase = REQUIRED_FIELDS.filter(title => !titles.has(title));
  if (missingBase.length) throw new Error(`目标工作表缺少必要列：${missingBase.join('、')}。请检查表头名称；后端不会自动改动这些原有列。`);
  const missingExtra = EXTRA_FIELDS.filter(title => !titles.has(title));
  if (missingExtra.length) {
    const newFields = missingExtra.map(field_title => ({ field_title, field_type: 1, property_text: {} }));
    await mcpTool(env, 'smartsheet.add_fields', { file_id: docId(env), sheet_id: sheetId(env), fields: newFields });
    fields = await listFields(env);
  }
  await env.SYNC_IDS.put(`meta:fields:${docId(env)}:${sheetId(env)}`, JSON.stringify(fields));
  await env.SYNC_IDS.put(`meta:ready:${docId(env)}:${sheetId(env)}`, JSON.stringify({ at: new Date().toISOString(), tableTitle: matched.title || matched.name || '' }));
  return { tableTitle: matched.title || matched.name || '', fields: fields.map(field => ({ title: field.field_title, type: field.field_type })) };
}
function toTextValue(value) { return [{ type: 'text', text: String(value ?? '') }]; }
function dateValue(dateString, fieldType) {
  const value = String(dateString || '').trim();
  if (!value) return fieldType === 4 ? '' : toTextValue('');
  if (fieldType === 4) {
    const ms = Date.parse(`${value}T00:00:00+08:00`);
    if (!Number.isFinite(ms)) throw new Error(`日期格式不正确：${value}`);
    return String(ms);
  }
  return toTextValue(value);
}
function makeFieldValues(record, fields) {
  const map = {
    '科室': text(record.dept),
    '日期': text(record.date),
    '铭牌文本': String(record.raw ?? ''),
    '设备名称': text(record.name),
    '生产厂家': text(record.manufacturer),
    '型号': text(record.model),
    '编号': text(record.code),
    '录入人员': text(record.operatorName),
    '本地记录ID': text(record.id)
  };
  const out = {};
  for (const field of fields) {
    const title = field.field_title;
    if (!(title in map)) continue;
    if (title === '日期') {
      if (!map[title]) continue;
      out[title] = dateValue(map[title], Number(field.field_type));
    } else {
      if (!String(map[title] ?? '').trim()) continue;
      out[title] = toTextValue(map[title]);
    }
  }
  return out;
}
function parseAddedRecordId(payload) {
  const records = resultArray(payload, 'records');
  const first = records?.[0];
  return first?.record_id || first?.recordId || first?.id || payload?.record_id || payload?.recordId || '';
}
async function syncOne(env, record) {
  if (!env.SYNC_IDS) throw new Error('未绑定 SYNC_IDS KV 命名空间。');
  const metaKey = `meta:fields:${docId(env)}:${sheetId(env)}`;
  let fieldsJson = await env.SYNC_IDS.get(metaKey);
  if (!fieldsJson) {
    await ensureSetup(env);
    fieldsJson = await env.SYNC_IDS.get(metaKey);
  }
  const fields = JSON.parse(fieldsJson || '[]');
  const fieldTitles = new Set(fields.map(field => field.field_title));
  const missing = [...REQUIRED_FIELDS, ...EXTRA_FIELDS].filter(title => !fieldTitles.has(title));
  if (missing.length) throw new Error(`腾讯文档缺少列：${missing.join('、')}。请先点击“验证腾讯文档并初始化字段”。`);

  const values = makeFieldValues(record, fields);
  const clientId = text(record.id);
  const key = `record:${docId(env)}:${sheetId(env)}:${clientId}`;
  const mappedRemoteId = await env.SYNC_IDS.get(key);
  if (mappedRemoteId) {
    const updatePayload = await mcpTool(env, 'smartsheet.update_records', {
      file_id: docId(env), sheet_id: sheetId(env),
      records: [{ record_id: mappedRemoteId, field_values: values }]
    });
    if (updatePayload?.error) throw new Error(String(updatePayload.error));
    return { action: 'updated', recordId: mappedRemoteId };
  }

  const addPayload = await mcpTool(env, 'smartsheet.add_records', {
    file_id: docId(env), sheet_id: sheetId(env),
    records: [{ field_values: values }]
  });
  if (addPayload?.error) throw new Error(String(addPayload.error));
  const remoteId = parseAddedRecordId(addPayload);
  if (!remoteId) {
    throw new Error('腾讯文档可能已收到新增请求，但响应中没有 record_id，无法安全重试。请先检查表格是否新增了这一行；如果已新增，请不要连续重试。');
  }
  await env.SYNC_IDS.put(key, String(remoteId));
  return { action: 'created', recordId: String(remoteId) };
}

export default {
  async fetch(request, env) {
    const origin = getOrigin(request);
    if (request.method === 'OPTIONS') {
      if (origin && origin !== ALLOWED_ORIGIN) return new Response(null, { status: 403 });
      return new Response(null, { status: 204, headers: {
        'Access-Control-Allow-Origin': ALLOWED_ORIGIN,
        'Access-Control-Allow-Methods': 'GET, POST, OPTIONS',
        'Access-Control-Allow-Headers': 'Content-Type, X-Mingpai-Key',
        'Access-Control-Max-Age': '86400', 'Vary': 'Origin'
      }});
    }
    if (origin && origin !== ALLOWED_ORIGIN) return json({ ok: false, error: '来源网页不在允许列表中。' }, 403);
    const url = new URL(request.url);
    if (request.method === 'GET' && url.pathname === '/health') {
      return json({ ok: true, service: 'mingpai-tencent-docs-sync', docId: DEFAULT_DOC_ID, configured: Boolean(env.TENCENT_DOCS_TOKEN && env.MINGPAI_SHARED_KEY && env.SYNC_IDS) });
    }
    if (request.method !== 'POST' || !['/setup', '/sync'].includes(url.pathname)) {
      return json({ ok: false, error: 'Not found. Use POST /setup or POST /sync.' }, 404);
    }
    try {
      requireConfig(env);
      if (!env.MINGPAI_SHARED_KEY || request.headers.get('X-Mingpai-Key') !== env.MINGPAI_SHARED_KEY) {
        return json({ ok: false, error: '共享访问密钥不正确。请检查手机网页同步设置。' }, 401);
      }
      if (url.pathname === '/setup') {
        const setup = await ensureSetup(env);
        return json({ ok: true, message: `腾讯文档验证成功：${setup.tableTitle || '目标智能表格'}。必要字段已检查；录入人员与本地记录ID已就绪。`, fields: setup.fields });
      }
      let body;
      try { body = await request.json(); } catch { return json({ ok: false, error: '请求体不是有效 JSON。' }, 400); }
      const record = body?.record;
      if (!record || !text(record.id)) return json({ ok: false, error: '缺少记录 ID。请刷新网页后重新确认记录。' }, 400);
      if (!text(record.operatorName)) return json({ ok: false, error: '缺少录入人员姓名。请在手机网页顶部填写姓名。' }, 400);
      const result = await syncOne(env, record);
      return json({ ok: true, action: result.action, recordId: result.recordId });
    } catch (error) {
      const message = error?.message || String(error);
      const status = /共享访问密钥/.test(message) ? 401 : /VIP权限不足/.test(message) ? 402 : /未找到 URL 中 tab=/.test(message) ? 422 : /缺少必要列/.test(message) ? 422 : 500;
      return json({ ok: false, error: message }, status);
    }
  }
};
