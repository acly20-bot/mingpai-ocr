# 铭牌识别：腾讯文档自动同步 Worker

本 Worker 将手机网页里已经人工确认的设备信息写入指定腾讯文档智能表格。腾讯文档 Token 只保存在 Cloudflare Worker Secret，不放在 GitHub Pages 前端。

## 目标文档

- DOC_ID：`DTW9nTUROa2RkeUVx`（来自你提供的腾讯文档 URL 路径）
- SHEET_ID：`t00i2h`（来自 URL 的 `tab` 参数，首次 `/setup` 会通过 `smartsheet.list_tables` 验证；若不匹配，响应会显示正确的 sheet_id）
- 初始化时仅在缺少的情况下添加两个文本列：`录入人员`、`本地记录ID`。原有列必须存在且表头名称准确：`科室`、`日期`、`铭牌文本`、`设备名称`、`生产厂家`、`型号`、`编号`。

## 在 Cloudflare 免费部署（建议用 Dashboard，不必装命令行）

1. 登录 Cloudflare Dashboard：Workers & Pages → Create → Create Worker，名称建议 `mingpai-tencent-sync`。
2. 创建并部署 Worker 后，打开 Edit code，将 `worker.js` 全部代码替换进去并 Deploy。
3. 打开 Worker → Settings → Variables and Secrets，添加两项 **Secret**：
   - `TENCENT_DOCS_TOKEN`：在 <https://docs.qq.com/open/auth/mcp.html> 获取的个人 Token 原文，不要加 `Bearer ` 前缀。不要分享给盘点员，也不要提交到 GitHub。
   - `MINGPAI_SHARED_KEY`：自己生成一串足够长的共享口令（建议 32 字符以上），只分发给授权盘点人员。
4. 创建 KV namespace：Storage & databases → KV → Create namespace，名称建议 `MINGPAI_SYNC_IDS`。
5. 回到 Worker → Settings → Bindings → Add binding → KV namespace：Variable name 填 `SYNC_IDS`，选择刚才的 namespace，然后 Deploy。
6. 在 Worker Settings → Variables 添加普通变量：
   - `DOC_ID` = `DTW9nTUROa2RkeUVx`
   - `SHEET_ID` = `t00i2h`
   如果首次 `/setup` 提示 `tab` 不是 sheet_id，请按报错列出的可用工作表 ID 更新 `SHEET_ID`。
7. 打开 Worker URL（例如 `https://mingpai-tencent-sync.<你的子域>.workers.dev/health`）。应返回 JSON，且 `configured` 为 `true`。

## 手机网页配置

1. 在 GitHub Pages 更新前端项目后，打开网页；在“录入人员姓名”填每位人员自己的名字。
2. 在“腾讯文档自动同步”中填写 Worker URL（不加 `/sync`）和 `MINGPAI_SHARED_KEY`，点击保存。
3. 点“验证腾讯文档并初始化字段”。成功后再用一条测试记录验证。
4. 每次在卡片里点击“确认这条记录”，记录会先保存本地，再尝试写入腾讯文档；成功标记“已同步”，失败保留本地并允许重试。
5. “同步已确认未同步记录”可批量重试。

## 安全与注意事项

- 前端存储的是共享访问口令，而非腾讯文档 Token。由于这是小团队共享入口，授权人员应保管好口令；如泄露，应在 Cloudflare 里轮换 `MINGPAI_SHARED_KEY` 并更新所有手机。
- Worker 仅允许来自 `https://acly20-bot.github.io` 的浏览器 CORS 请求，并固定目标文档/工作表，不接受客户端指定任意文档 ID。
- KV 记录本地 UUID 到腾讯文档 record_id 的映射。重试同一记录会更新同一云端记录，避免常见的重复追加情况。
- KV 并非事务锁：极少数“腾讯文档已成功新增、但 Worker 在保存 KV 映射前中断”的情况，重试前请先检查目标表，避免重复行。
- `/setup` 会通过 MCP 列出工作表和字段，并在缺少时添加 `录入人员`、`本地记录ID` 两个文本字段；不会自动添加或重命名原有字段。
- 腾讯文档 MCP 的权限仍以账号实际返回为准；如果返回 `400007 VIP权限不足`，不能通过本 Worker 绕过腾讯文档权限限制。
- 当前同步写入字段：科室、日期、铭牌文本、设备名称、生产厂家、型号、编号、录入人员、本地记录ID。日期列若为日期类型会转换为毫秒时间戳；若为文本列则写入 `YYYY-MM-DD`。
