# 飞书多维表格同步 Worker

`worker.js` 为铭牌 OCR 网页的飞书同步后端。

Cloudflare Secrets：
- `FEISHU_APP_ID`
- `FEISHU_APP_SECRET`
- `MINGPAI_SHARED_KEY`

KV binding：
- `SYNC_IDS`

接口：
- `GET /health`
- `POST /setup`
- `POST /test-write`
- `POST /sync`

飞书表字段：单位名称、科室、检定日期、检定员、铭牌文本、设备名称、生产厂家、型号、出厂编号、备注。
