(() => {
  'use strict';

  const DB_NAME = 'mingpai-free-v1'; // Keep existing DB name to preserve prior records.
  const STORE = 'records';
  const PAGE_SIZE = 10;
  const OCR_SPACE_ENDPOINT = 'https://api.ocr.space/parse/image';
  const CLOUD_TIMEOUT_MS = 90000;
  const PADDLE_INIT_TIMEOUT_MS = 180000;
  const PADDLE_IMAGE_TIMEOUT_MS = 120000;
  const CLOUD_MAX_BYTES = 950 * 1024;
  const SYNC_WORKER_URL = 'https://mingpai-tencent-sync.acly20.workers.dev';
  const SYNC_RETRY_DELAYS_MS = [0, 1200, 2500];
  const $ = id => document.getElementById(id);

  let db;
  let records = [];
  let page = 0;
  let busy = false;
  let objectUrls = [];
  let activeImageName = '';
  let retryRecordId = null;
  let retryEngineOverride = null;
  let paddleOcr = null;
  let paddlePromise = null;
  let paddleFailure = '';
  let paddleOcrVersion = '';
  let cloudQuotaReachedThisSession = false;
  const syncingIds = new Set();

  const today = new Date();
  const defaultToday = `${today.getFullYear()}-${String(today.getMonth() + 1).padStart(2, '0')}-${String(today.getDate()).padStart(2, '0')}`;

  function status(message) { $('progress').textContent = message; }
  function esc(value) {
    return String(value ?? '').replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
  }
  function csvEscape(value) { return '"' + String(value ?? '').replace(/"/g, '""') + '"'; }
  function localStorageGet(key, fallback = '') { try { return localStorage.getItem(key) ?? fallback; } catch { return fallback; } }
  function localStorageSet(key, value) { try { localStorage.setItem(key, value); } catch {} }

  function applySavedSettings() {
    $('ocrApiKey').value = localStorageGet('mingpai-ocrspace-key');
    $('ocrMode').value = localStorageGet('mingpai-ocr-mode', 'auto');
    $('ocrEngine').value = localStorageGet('mingpai-ocrspace-engine', '2');
    $('operatorName').value = localStorageGet('mingpai-operator-name');
    $('unitName').value = localStorageGet('mingpai-unit-name');
    $('dept').value = localStorageGet('mingpai-dept');
    $('workdate').value = localStorageGet('mingpai-workdate', defaultToday);
    $('syncSharedKey').value = localStorageGet('mingpai-feishu-sync-key', localStorageGet('mingpai-tencent-sync-key'));
  }
  function saveSettings(showMessage = true) {
    const key = $('ocrApiKey').value.trim();
    localStorageSet('mingpai-ocrspace-key', key);
    localStorageSet('mingpai-ocr-mode', $('ocrMode').value);
    localStorageSet('mingpai-ocrspace-engine', $('ocrEngine').value);
    if (showMessage) {
      const mode = $('ocrMode').value;
      status(mode === 'paddle'
        ? '设置已保存：仅使用 PaddleOCR.js + PP-OCRv6 本地识别。'
        : mode === 'space'
          ? (key ? '设置已保存：仅使用 OCR.space 云端识别。' : '设置已保存，但尚未填写 OCR.space API Key。')
          : (key ? '设置已保存：优先 OCR.space；检测到限额/服务异常时会切换本地 PaddleOCR。' : '设置已保存：未填写 API Key，自动模式会直接尝试本地 PaddleOCR。'));
    }
  }
  function updateMode(mode, persist = true) {
    $('ocrMode').value = mode;
    if (persist) localStorageSet('mingpai-ocr-mode', mode);
  }
  applySavedSettings();

  function getSyncConfig() {
    return {
      url: SYNC_WORKER_URL,
      key: ($('syncSharedKey')?.value || localStorageGet('mingpai-feishu-sync-key', localStorageGet('mingpai-tencent-sync-key'))).trim()
    };
  }
  function wait(ms) { return new Promise(resolve => setTimeout(resolve, ms)); }
  async function callSyncService(path, payload = {}) {
    const config = getSyncConfig();
    if (!config.key) throw new Error('尚未填写共享访问密钥。');

    let lastNetworkError = null;
    for (let attempt = 0; attempt < SYNC_RETRY_DELAYS_MS.length; attempt++) {
      const delay = SYNC_RETRY_DELAYS_MS[attempt];
      if (delay) await wait(delay);

      let response;
      try {
        response = await fetch(config.url + path, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json', 'X-Mingpai-Key': config.key },
          body: JSON.stringify(payload)
        });
      } catch (error) {
        lastNetworkError = error;
        if (attempt < SYNC_RETRY_DELAYS_MS.length - 1) continue;
        throw new Error(`无法连接同步服务，已自动重试 ${SYNC_RETRY_DELAYS_MS.length} 次：${error?.message || String(error)}`);
      }

      const text = await response.text();
      let data;
      try { data = text ? JSON.parse(text) : {}; } catch { data = { error: text || `HTTP ${response.status}` }; }

      // HTTP 返回说明已经连接到 Worker；业务错误不盲目重复提交。
      if (!response.ok || data.ok === false) throw new Error(data.error || data.message || `同步服务请求失败（HTTP ${response.status}）`);
      return data;
    }

    throw new Error('无法连接同步服务：' + (lastNetworkError?.message || '未知网络错误'));
  }
  async function syncRecordToFeishu(record, { silent = false } = {}) {
    if (!record || record.status !== 'confirmed') {
      if (!silent) status('请先确认记录，再同步到飞书。');
      return false;
    }
    if (syncingIds.has(record.id)) return false;
    const operator = String(record.operatorName || $('operatorName').value || '').trim();
    if (!operator) {
      if (!silent) alert('请先在页面顶部填写检定员姓名，然后再确认/同步记录。');
      return false;
    }
    record.operatorName = operator;
    const config = getSyncConfig();
    if (!config.key) {
      record.syncStatus = 'local-only';
      record.syncError = '尚未填写共享访问密钥；记录仍保存在本机。';
      await txPut(record); await refresh();
      if (!silent) status('记录已在本机确认，但尚未填写共享访问密钥。填写并保存密钥后，可点击“同步/重试飞书”。');
      return false;
    }
    syncingIds.add(record.id);
    record.syncStatus = 'syncing';
    record.syncError = '';
    await txPut(record); await refresh();
    try {
      const data = await callSyncService('/sync', { record: {
        id: record.id, unitName: record.unitName || record.batch || '', dept: record.dept || '', date: record.date || '', raw: record.raw || '',
        name: record.name || '', manufacturer: record.manufacturer || '', model: record.model || '',
        code: record.code || '', operatorName: record.operatorName || '', remark: record.remark || ''
      }});
      record.syncStatus = 'synced';
      record.syncError = '';
      record.remoteRecordId = data.recordId || record.remoteRecordId || '';
      record.syncedAt = Date.now();
      await txPut(record); await refresh();
      status(`已确认并同步飞书：${record.name || '未填写设备名称'}（检定员：${record.operatorName}）。${data.action === 'updated' ? '已更新已有云端记录。' : '已新增云端记录。'}`);
      return true;
    } catch (error) {
      record.syncStatus = 'error';
      record.syncError = error?.message || String(error);
      await txPut(record); await refresh();
      status(`本地记录已保留，但飞书同步失败：${record.syncError}
请检查同步设置或网络，然后点击该记录的“同步/重试飞书”。`);
      return false;
    } finally {
      syncingIds.delete(record.id);
    }
  }
  async function setupFeishuSync() {
    try {
      status('正在验证飞书同步服务、应用权限和多维表格 10 个字段……');
      const data = await callSyncService('/setup', {});
      status(data.message || '飞书多维表格连接验证成功，字段已就绪。现在确认记录后会自动同步。');
      alert(data.message || '飞书多维表格验证成功。');
    } catch (error) {
      status('飞书初始化失败：' + (error?.message || String(error)) + '\n请检查共享访问密钥、网络、飞书应用凭证，以及多维表格应用权限。');
    }
  }
  async function openDB() {
    return new Promise((resolve, reject) => {
      const request = indexedDB.open(DB_NAME, 1);
      request.onupgradeneeded = () => {
        const database = request.result;
        if (!database.objectStoreNames.contains(STORE)) database.createObjectStore(STORE, { keyPath: 'id' });
      };
      request.onsuccess = () => resolve(request.result);
      request.onerror = () => reject(request.error);
    });
  }
  function txPut(record) {
    return new Promise((resolve, reject) => {
      const tx = db.transaction(STORE, 'readwrite');
      tx.objectStore(STORE).put(record);
      tx.oncomplete = () => resolve();
      tx.onerror = () => reject(tx.error);
    });
  }
  function txDelete(id) {
    return new Promise((resolve, reject) => {
      const tx = db.transaction(STORE, 'readwrite');
      tx.objectStore(STORE).delete(id);
      tx.oncomplete = () => resolve();
      tx.onerror = () => reject(tx.error);
    });
  }
  function txAll() {
    return new Promise((resolve, reject) => {
      const request = db.transaction(STORE, 'readonly').objectStore(STORE).getAll();
      request.onsuccess = () => resolve(request.result || []);
      request.onerror = () => reject(request.error);
    });
  }
  function normalizeRecord(record) {
    if (record.unitName == null) record.unitName = record.batch || '';
    if (record.remark == null) record.remark = '';
    if (record.operatorName == null) record.operatorName = '';
    return record;
  }
  async function refresh() {
    records = (await txAll()).map(normalizeRecord).sort((a, b) => b.createdAt - a.createdAt);
    render();
  }
  function getFiltered() {
    const filter = $('statusFilter').value;
    const query = $('searchBox').value.trim().toLowerCase();
    return records.filter(record =>
      (filter === 'all' || (filter === 'pending' ? record.status !== 'confirmed' : record.status === 'confirmed')) &&
      (!query || [record.unitName, record.name, record.manufacturer, record.model, record.code, record.raw, record.dept, record.operatorName, record.remark].join(' ').toLowerCase().includes(query))
    );
  }
  function render() {
    objectUrls.forEach(url => URL.revokeObjectURL(url));
    objectUrls = [];
    const total = records.length;
    const pending = records.filter(r => r.status !== 'confirmed').length;
    $('countAll').textContent = `总记录：${total}`;
    $('countPending').textContent = `待审核：${pending}`;
    $('countOk').textContent = `已确认：${total - pending}`;
    const list = getFiltered();
    const pages = Math.max(1, Math.ceil(list.length / PAGE_SIZE));
    page = Math.min(page, pages - 1);
    const subset = list.slice(page * PAGE_SIZE, (page + 1) * PAGE_SIZE);
    $('pageText').textContent = `第 ${list.length ? page + 1 : 0} / ${list.length ? pages : 0} 页（筛选后 ${list.length} 条）`;
    $('recordList').innerHTML = '';
    if (!subset.length) {
      $('recordList').innerHTML = '<p class="hint">当前没有记录。先拍照或从相册选择铭牌照片。</p>';
      $('prevBtn').disabled = $('nextBtn').disabled = true;
      return;
    }
    subset.forEach(record => {
      const card = document.createElement('article');
      card.className = 'card';
      const thumbUrl = record.thumb ? URL.createObjectURL(record.thumb) : '';
      if (thumbUrl) objectUrls.push(thumbUrl);
      const engineText = record.sourceEngine ? `识别来源：${record.sourceEngine}` : '尚未成功识别';
      card.innerHTML = `
        <div class="cardhead">
          ${thumbUrl ? `<img class="thumb" data-open-image="${record.id}" alt="点击查看铭牌照片" title="点击查看照片" src="${thumbUrl}">` : '<div class="thumb" style="display:grid;place-items:center;font-size:11px;color:#78849a">无照片</div>'}
          <div class="cardtitle"><strong>${esc(record.name || '未识别设备名称')}</strong><small>${esc(record.unitName || record.batch || '未设置单位')} · ${esc(record.dept || '未设置科室')} · ${esc(record.createdAt ? new Date(record.createdAt).toLocaleString() : '')}<br>${esc(engineText)}<br>检定员：${esc(record.operatorName || '待填写')} · 飞书同步：${esc(syncStatusLabel(record))}</small></div>
          <span class="badge ${record.status === 'confirmed' ? 'ok' : ''}">${record.status === 'confirmed' ? '已确认' : '待审核'}</span>
        </div>
        ${record.error ? `<div class="errornote">${esc(record.error)}</div>` : ''}
        ${record.syncError ? `<div class="errornote">飞书同步失败：${esc(record.syncError)}</div>` : ''}
        <div class="grid">
          ${makeField(record, 'unitName', '单位名称', 'text')}${makeField(record, 'dept', '科室', 'text')}
          ${makeField(record, 'date', '检定日期', 'date')}${makeField(record, 'operatorName', '检定员', 'text')}
          ${makeField(record, 'name', '设备名称', 'text')}${makeField(record, 'manufacturer', '生产厂家', 'text')}
          ${makeField(record, 'model', '型号', 'text')}${makeField(record, 'code', '出厂编号', 'text')}
          <div class="full"><label>备注（可留空，由检定员手动填写）</label><textarea data-id="${record.id}" data-field="remark">${esc(record.remark || '')}</textarea></div>
          <div class="full"><label>铭牌文本（可修正 OCR 原文）</label><textarea data-id="${record.id}" data-field="raw">${esc(record.raw || '')}</textarea></div>
        </div>
        <div class="controls">
          <button class="btn ${record.status === 'confirmed' ? 'light' : 'secondary'}" data-action="toggle" data-id="${record.id}">${record.status === 'confirmed' ? '取消确认' : '确认这条记录'}</button>
          <button class="btn light" data-action="reparse" data-id="${record.id}">从原文重新提取字段</button>
          <button class="btn light" data-action="retry" data-id="${record.id}">重新识别（选择照片）</button>
          <button class="btn secondary" data-action="retry-paddle" data-id="${record.id}">用 Paddle 本地重识别</button>
          ${record.status === 'confirmed' ? `<button class="btn secondary" data-action="sync" data-id="${record.id}">${record.syncStatus === 'synced' ? '重新同步云端记录' : '同步/重试飞书'}</button>` : ''}
          <button class="btn danger" data-action="delete" data-id="${record.id}">删除</button>
        </div>`;
      $('recordList').appendChild(card);
    });
    $('prevBtn').disabled = page <= 0;
    $('nextBtn').disabled = page >= pages - 1;
  }
  function syncStatusLabel(record) {
    if (record.syncStatus === 'synced') return '已同步';
    if (record.syncStatus === 'syncing') return '同步中';
    if (record.syncStatus === 'error') return '失败待重试';
    if (record.syncStatus === 'pending') return '有修改待同步';
    if (record.syncStatus === 'local-only') return '仅本机保存';
    return record.status === 'confirmed' ? '尚未同步' : '待确认';
  }
  function makeField(record, field, label, type) {
    return `<div><label>${label}</label><input type="${type}" data-id="${record.id}" data-field="${field}" value="${esc(record[field] || '')}"></div>`;
  }

  function extract(text) {
    const lines = String(text || '').replace(/\r/g, '\n').split('\n').map(s => s.trim()).filter(Boolean);
    function find(labels) {
      for (let i = 0; i < lines.length; i++) {
        const line = lines[i];
        for (const label of labels) {
          const escaped = label.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
          const match = line.match(new RegExp('(?:^|[\\s：:]|^)' + escaped + '\\s*[：:]?\\s*(.*)$', 'i'));
          if (!match) continue;
          const value = (match[1] || '').trim().replace(/^[：:：\-—\s]+/, '').trim();
          if (value && !labels.some(s => new RegExp('^' + s + '$', 'i').test(value))) return value.slice(0, 120);
          if (i + 1 < lines.length && lines[i + 1].length < 100 && !/^(额定|电压|功率|地址|电话|网址)/.test(lines[i + 1])) return lines[i + 1].slice(0, 120);
        }
      }
      return '';
    }
    return {
      name: find(['设备名称', '产品名称', '仪器名称', '名称']),
      manufacturer: find(['生产厂家', '制造厂家', '制造商', '生产企业', '制造单位', '生产单位', '生产厂商']),
      model: find(['规格型号', '产品型号', '设备型号', '型号', '规格']),
      code: find(['出厂编号', '出厂序列号', '序列号', '序列 编号', '设备编号', 'S\\/?N', 'Serial\\s*No\\.?', 'SN', '编号'])
    };
  }
  function newRecord() {
    return {
      id: crypto.randomUUID ? crypto.randomUUID() : Date.now() + '-' + Math.random().toString(36).slice(2),
      createdAt: Date.now(), unitName: $('unitName').value.trim(), dept: $('dept').value.trim(), date: $('workdate').value || '',
      operatorName: $('operatorName').value.trim(), remark: '', syncStatus: 'local-only', syncError: '', remoteRecordId: '',
      raw: '', name: '', manufacturer: '', model: '', code: '', status: 'pending', error: '已保存，准备识别……', thumb: null, sourceEngine: ''
    };
  }
  function applyTextResult(record, text, sourceEngine) {
    const raw = String(text || '').trim();
    if (!raw) throw new Error('OCR 完成但没有识别到文字。请换一个角度、靠近铭牌拍摄，或裁剪铭牌区域后重试。');
    record.raw = raw;
    const fields = extract(raw);
    record.name = fields.name;
    record.manufacturer = fields.manufacturer;
    record.model = fields.model;
    record.code = fields.code;
    record.error = '';
    record.sourceEngine = sourceEngine;
    record.status = 'pending';
    if (record.remoteRecordId) record.syncStatus = 'pending';
  }

  class OcrSpaceError extends Error {
    constructor(message, { quota = false, requestFailure = false, emptyResult = false } = {}) {
      super(message);
      this.name = 'OcrSpaceError';
      this.quota = quota;
      this.requestFailure = requestFailure;
      this.emptyResult = emptyResult;
    }
  }
  function looksLikeQuota(message, httpStatus = 0) {
    if (httpStatus === 429) return true;
    return /quota|rate.?limit|too many requests|maximum number of requests|requests per day|daily limit|monthly limit|you have reached|exceeded.{0,30}limit|limit.{0,30}exceeded|500 requests|maximum request/i.test(String(message || ''));
  }
  function friendlyApiErrors(data) {
    const bits = [];
    if (data?.ErrorMessage) bits.push(Array.isArray(data.ErrorMessage) ? data.ErrorMessage.join('; ') : String(data.ErrorMessage));
    if (data?.ErrorDetails) bits.push(Array.isArray(data.ErrorDetails) ? data.ErrorDetails.join('; ') : String(data.ErrorDetails));
    for (const item of data?.ParsedResults || []) {
      if (item?.ErrorMessage) bits.push(String(item.ErrorMessage));
      if (item?.ErrorDetails) bits.push(String(item.ErrorDetails));
    }
    return [...new Set(bits.filter(Boolean))].join('；');
  }
  async function runOcrSpace(file, displayName) {
    const apiKey = $('ocrApiKey').value.trim() || localStorageGet('mingpai-ocrspace-key');
    if (!apiKey) throw new OcrSpaceError('尚未配置 OCR.space API Key。请在上方粘贴 Key 并点击“保存设置”，或选择 Paddle 本地模式。', { requestFailure: true });
    status(`正在压缩照片，准备上传 OCR.space：${displayName}\n免费 API 单张文件限制 1 MB。`);
    const uploadBlob = await prepareImage(file, 'cloud');
    if (uploadBlob.size > CLOUD_MAX_BYTES) throw new OcrSpaceError(`照片压缩后仍超过 1 MB（${(uploadBlob.size / 1024 / 1024).toFixed(2)} MB）。请裁剪铭牌区域后重新上传。`, { requestFailure: false });
    const form = new FormData();
    // OCR.space documents apikey in a multipart form body for its JavaScript example.
    form.append('apikey', apiKey);
    form.append('file', uploadBlob, safeJpegName(displayName));
    form.append('language', 'auto');
    form.append('OCREngine', $('ocrEngine').value || '2');
    form.append('isOverlayRequired', 'false');
    form.append('detectOrientation', 'true');
    form.append('scale', 'true');
    const controller = new AbortController();
    const timer = setTimeout(() => controller.abort(), CLOUD_TIMEOUT_MS);
    let response, data;
    try {
      status(`OCR.space 正在识别：${displayName}\n已上传压缩后的照片，请保持网页在前台。`);
      response = await fetch(OCR_SPACE_ENDPOINT, { method: 'POST', body: form, signal: controller.signal });
      const bodyText = await response.text();
      try { data = JSON.parse(bodyText); }
      catch { throw new OcrSpaceError(`OCR.space 返回了非 JSON 内容（HTTP ${response.status}）。可能是服务暂时不可用。`, { requestFailure: true, quota: looksLikeQuota(bodyText, response.status) }); }
    } catch (error) {
      if (error instanceof OcrSpaceError) throw error;
      const msg = error?.name === 'AbortError' ? `OCR.space 请求超过 ${Math.round(CLOUD_TIMEOUT_MS / 1000)} 秒，已停止等待。` : `OCR.space 网络请求失败：${error?.message || String(error)}。可能是网络、CORS 或服务暂时不可用。`;
      throw new OcrSpaceError(msg, { requestFailure: true, quota: looksLikeQuota(msg, response?.status || 0) });
    } finally {
      clearTimeout(timer);
    }
    const message = friendlyApiErrors(data) || `OCR.space 返回 HTTP ${response.status} / OCRExitCode ${data?.OCRExitCode ?? '未知'}`;
    if (!response.ok || data?.IsErroredOnProcessing) {
      throw new OcrSpaceError(message, {
        requestFailure: !response.ok || Boolean(data?.IsErroredOnProcessing) || /api.?key|invalid key|unauthori[sz]ed|authentication|not authorized|access denied/i.test(message),
        quota: looksLikeQuota(message, response.status)
      });
    }
    const parsedResults = Array.isArray(data?.ParsedResults) ? data.ParsedResults : [];
    const text = parsedResults
      .filter(result => result?.ParsedText && (result.FileParseExitCode == null || Number(result.FileParseExitCode) === 1 || Number(result.FileParseExitCode) === 2))
      .map(result => String(result.ParsedText).trim())
      .filter(Boolean)
      .join('\n');
    if (!text) {
      const noTextMessage = message || 'OCR.space 没有识别到文字。';
      throw new OcrSpaceError(noTextMessage, {
        quota: looksLikeQuota(noTextMessage, response.status),
        requestFailure: !response.ok || /api.?key|invalid key|unauthori[sz]ed|authentication|not authorized|access denied/i.test(noTextMessage),
        emptyResult: true
      });
    }
    return text;
  }
  function safeJpegName(name) {
    const base = String(name || 'mingpai').replace(/\.[^.]+$/, '').replace(/[^\w\u4e00-\u9fff-]+/g, '_').slice(0, 60) || 'mingpai';
    return base + '.jpg';
  }

  async function getPaddleOcr() {
    if (paddleOcr) return paddleOcr;
    if (paddleFailure) throw new Error(paddleFailure);
    if (paddlePromise) return paddlePromise;

    status('正在使用已验证过的 PaddleOCR 默认模型配置初始化本地备用引擎。首次需要联网下载模型，请保持网页在前台……');
    const createPromise = (async () => {
      const { PaddleOCR } = await import('@paddleocr/paddleocr-js');
      const errors = [];
      // IMPORTANT: Match the standalone PaddleOCR page that was confirmed to work.
      // Do not pass custom model asset URLs, custom WASM paths, or worker:true here.
      // Those overrides were introduced in the dual-engine build and correlated with
      // the 180-second initialization hang. Let the pinned SDK resolve its own model
      // assets and ORT runtime using backend:auto, exactly as in the working build.
      for (const ocrVersion of ['PP-OCRv6', 'PP-OCRv5']) {
        try {
          status(`正在初始化 ${ocrVersion} 本地备用模型（使用 PaddleOCR.js 默认模型和运行时路径）……`);
          const instance = await PaddleOCR.create({
            lang: 'ch',
            ocrVersion,
            worker: false,
            ortOptions: { backend: 'auto' }
          });
          paddleOcr = instance;
          paddleOcrVersion = ocrVersion;
          status(`${ocrVersion} 本地备用模型加载完成。`);
          return instance;
        } catch (error) {
          const message = error?.message || String(error);
          errors.push(`${ocrVersion}: ${message}`);
          status(`${ocrVersion} 初始化失败，正在按已验证配置尝试兼容模型……`);
        }
      }
      throw new Error('PaddleOCR 模型初始化失败。' + errors.join('；'));
    })();

    let timeoutHandle;
    const timeoutPromise = new Promise((_, reject) => {
      timeoutHandle = setTimeout(() => reject(new Error(
        `PaddleOCR 默认模型初始化超过 ${Math.round(PADDLE_INIT_TIMEOUT_MS / 1000)} 秒。此版本不再使用自定义模型 TAR 地址或自定义 WASM 路径；请检查手机能否访问 PaddleOCR SDK 默认模型资源，并查看网络是否中断。`
      )), PADDLE_INIT_TIMEOUT_MS);
    });
    paddlePromise = Promise.race([createPromise, timeoutPromise]);
    try {
      return await paddlePromise;
    } catch (error) {
      paddleFailure = error?.message || String(error);
      paddlePromise = null;
      throw error;
    } finally {
      clearTimeout(timeoutHandle);
    }
  }
  async function runPaddle(file, displayName) {
    status(`准备 PaddleOCR 本地识别：${displayName}……`);
    const inputBlob = await prepareImage(file, 'local');
    const ocr = await getPaddleOcr();
    status(`PaddleOCR.js + PP-OCRv6 正在本地识别：${displayName}\n图片不会上传给 OCR.space。`);
    let result;
    try {
      result = await withTimeout(ocr.predict(inputBlob), PADDLE_IMAGE_TIMEOUT_MS, `PaddleOCR 单张识别超过 ${Math.round(PADDLE_IMAGE_TIMEOUT_MS / 1000)} 秒。建议裁剪铭牌区域，或检查手机性能。`);
    } catch (error) {
      if (/超过 120 秒|worker|wasm|memory|memory access/i.test(error?.message || '')) {
        paddleFailure = error?.message || String(error);
        try { await paddleOcr?.dispose?.(); } catch {}
        paddleOcr = null;
      }
      throw error;
    }
    const first = Array.isArray(result) ? result[0] : result;
    const text = Array.isArray(first?.items) ? first.items.map(item => String(item?.text || '').trim()).filter(Boolean).join('\n') : '';
    if (!text.trim()) throw new Error('PaddleOCR 完成但没有识别到文字，请调整照片角度或裁剪铭牌区域后重试。');
    return text.trim();
  }
  function withTimeout(promise, milliseconds, message) {
    let timer;
    return Promise.race([promise, new Promise((_, reject) => { timer = setTimeout(() => reject(new Error(message)), milliseconds); })])
      .finally(() => clearTimeout(timer));
  }

  async function loadImageSource(file) {
    if ('createImageBitmap' in window) {
      try {
        const bitmap = await createImageBitmap(file);
        return { source: bitmap, width: bitmap.width, height: bitmap.height, close: () => bitmap.close() };
      } catch {}
    }
    return new Promise((resolve, reject) => {
      const url = URL.createObjectURL(file);
      const image = new Image();
      image.onload = () => {
        URL.revokeObjectURL(url);
        resolve({ source: image, width: image.naturalWidth, height: image.naturalHeight, close: () => {} });
      };
      image.onerror = () => { URL.revokeObjectURL(url); reject(new Error('无法读取图片。请换一张 JPG/PNG 照片。')); };
      image.src = url;
    });
  }
  function canvasBlob(canvas, quality) {
    return new Promise((resolve, reject) => canvas.toBlob(blob => blob ? resolve(blob) : reject(new Error('图片转换失败。')), 'image/jpeg', quality));
  }
  async function prepareImage(file, purpose) {
    const decoded = await loadImageSource(file);
    try {
      const width = decoded.width, height = decoded.height;
      if (!width || !height) throw new Error('图片尺寸无效。');
      let maxSide = purpose === 'cloud' ? 2400 : 2800;
      let quality = purpose === 'cloud' ? 0.9 : 0.92;
      let blob;
      for (let attempt = 0; attempt < (purpose === 'cloud' ? 8 : 1); attempt++) {
        let scale = Math.min(1, maxSide / Math.max(width, height));
        if (purpose === 'local' && Math.max(width, height) < 1400) scale = Math.min(1.35, 1400 / Math.max(width, height));
        const canvas = document.createElement('canvas');
        canvas.width = Math.max(1, Math.round(width * scale));
        canvas.height = Math.max(1, Math.round(height * scale));
        const context = canvas.getContext('2d');
        if (!context) throw new Error('此浏览器无法处理图片。');
        context.fillStyle = '#fff';
        context.fillRect(0, 0, canvas.width, canvas.height);
        context.imageSmoothingEnabled = true;
        context.imageSmoothingQuality = 'high';
        context.drawImage(decoded.source, 0, 0, canvas.width, canvas.height);
        blob = await canvasBlob(canvas, quality);
        if (purpose !== 'cloud' || blob.size <= CLOUD_MAX_BYTES) return blob;
        maxSide = Math.floor(maxSide * 0.88);
        quality = Math.max(0.72, quality - 0.035);
      }
      if (purpose === 'cloud' && blob?.size > CLOUD_MAX_BYTES) throw new Error('照片压缩后仍超过 OCR.space 的 1 MB 限制。请先裁剪铭牌区域后再上传。');
      return blob;
    } finally {
      decoded.close();
    }
  }
  function makeThumb(file) {
    return new Promise(resolve => {
      const image = new Image();
      const url = URL.createObjectURL(file);
      image.onload = () => {
        const max = 960;
        const scale = Math.min(1, max / Math.max(image.naturalWidth, image.naturalHeight));
        const canvas = document.createElement('canvas');
        canvas.width = Math.max(1, Math.round(image.naturalWidth * scale));
        canvas.height = Math.max(1, Math.round(image.naturalHeight * scale));
        const context = canvas.getContext('2d');
        context.fillStyle = '#fff'; context.fillRect(0, 0, canvas.width, canvas.height);
        context.drawImage(image, 0, 0, canvas.width, canvas.height);
        URL.revokeObjectURL(url);
        canvas.toBlob(blob => resolve(blob), 'image/jpeg', 0.72);
      };
      image.onerror = () => { URL.revokeObjectURL(url); resolve(null); };
      image.src = url;
    });
  }

  function setBusy(value) {
    busy = value;
    $('cameraBtn').disabled = value;
    $('galleryBtn').disabled = value;
    $('preloadPaddleBtn').disabled = value;
    $('saveOcrConfigBtn').disabled = value;
    $('ocrMode').disabled = value;
    $('ocrEngine').disabled = value;
    $('ocrApiKey').disabled = value;
  }
  async function recognizeFile(file, record, label, engineOverride = null) {
    activeImageName = label || file.name || '手机照片';
    const selectedMode = engineOverride || $('ocrMode').value;
    let cloudError = '';
    try {
      if (selectedMode === 'paddle') {
        const text = await runPaddle(file, activeImageName);
        applyTextResult(record, text, `PaddleOCR.js + ${paddleOcrVersion || 'PP-OCRv6'} 本地`);
        await txPut(record);
        return true;
      }
      if (selectedMode === 'space') {
        const text = await runOcrSpace(file, activeImageName);
        applyTextResult(record, text, `OCR.space Engine ${$('ocrEngine').value}`);
        await txPut(record);
        return true;
      }

      // Automatic mode: prefer OCR.space unless the cloud quota has already been detected.
      const apiKey = $('ocrApiKey').value.trim() || localStorageGet('mingpai-ocrspace-key');
      if (cloudQuotaReachedThisSession || $('ocrMode').value === 'paddle') {
        const text = await runPaddle(file, activeImageName);
        applyTextResult(record, text, `PaddleOCR.js + ${paddleOcrVersion || 'PP-OCRv6'} 本地（云端限额后切换）`);
        await txPut(record);
        return true;
      }
      if (!apiKey) {
        cloudError = '未配置 OCR.space API Key';
      } else {
        try {
          const text = await runOcrSpace(file, activeImageName);
          applyTextResult(record, text, `OCR.space Engine ${$('ocrEngine').value}`);
          await txPut(record);
          return true;
        } catch (error) {
          if (!(error instanceof OcrSpaceError)) throw error;
          cloudError = error.message;
          if (error.quota) {
            cloudQuotaReachedThisSession = true;
            updateMode('paddle', true);
            status(`检测到 OCR.space 的额度/限流错误：${cloudError}\n已自动把后续识别切换为 PaddleOCR.js + PP-OCRv6 本地备用模式，避免继续请求已受限的云端接口。正在处理当前照片……`);
          } else if (error.requestFailure) {
            // A network/HTTP problem is unlikely to be unique to one photo. Switch this session to local OCR
            // so a large batch will not repeatedly fail against the same cloud endpoint.
            updateMode('paddle', true);
            status(`OCR.space 请求失败：${cloudError}\n已切换到 PaddleOCR 本地备用模式，正在尝试识别当前照片……`);
          } else {
            status(`OCR.space 未识别到可用文字：${cloudError}\n正在尝试 PaddleOCR 本地备用模型……`);
          }
        }
      }
      if (!apiKey) status(`${cloudError}。自动模式将直接尝试 PaddleOCR 本地备用模型……`);
      try {
        const text = await runPaddle(file, activeImageName);
        applyTextResult(record, text, `PaddleOCR.js + ${paddleOcrVersion || 'PP-OCRv6'} 本地备用${cloudError ? '（云端未成功）' : ''}`);
        record.error = cloudError ? `云端未成功，已由本地备用识别。原因：${cloudError}` : '';
        await txPut(record);
        return true;
      } catch (localError) {
        throw new Error(`${cloudError ? `OCR.space 失败：${cloudError}\n` : ''}PaddleOCR 备用也未成功：${localError?.message || String(localError)}`);
      }
    } catch (error) {
      record.error = error?.message || String(error);
      record.status = 'pending';
      record.sourceEngine = selectedMode === 'paddle' ? 'PaddleOCR 本地（失败）' : '识别失败';
      await txPut(record);
      return false;
    }
  }
  async function handleFiles(fileList) {
    if (busy) { status('当前任务仍在处理，请等当前批次结束。'); return; }
    const files = Array.from(fileList || []).filter(file => file.type.startsWith('image/'));
    if (!files.length) return;
    if (!db) { status('本地记录正在初始化，请稍后重试。'); return; }
    setBusy(true);
    let failed = 0;
    try {
      for (let index = 0; index < files.length; index++) {
        const file = files[index];
        const record = newRecord();
        record.error = '已保存，准备识别……';
        await txPut(record);
        records.unshift(record);
        page = 0;
        status(`已保存待处理记录 ${index + 1}/${files.length}：${file.name || '手机照片'}\n开始生成照片预览。`);
        record.thumb = await makeThumb(file);
        await txPut(record);
        render();
        const success = await recognizeFile(file, record, `${index + 1}/${files.length} · ${file.name || '手机照片'}`);
        if (!success) failed++;
        await txPut(record);
        await refresh();
      }
      status(`本批完成：共 ${files.length} 张，已保存 ${files.length} 条记录；${failed} 张识别失败。失败记录仍在待审核列表，可用“重新识别”或“用 Paddle 本地重识别”再次尝试。`);
    } catch (error) {
      status('处理遇到问题：' + (error?.message || String(error)) + '\n已完成记录逐张保存，请在列表里检查。');
    } finally {
      activeImageName = '';
      setBusy(false);
      $('cameraInput').value = '';
      $('galleryInput').value = '';
    }
  }
  async function retryRecognition(record, file, engineOverride = null) {
    if (busy) return;
    if (engineOverride === 'paddle' && paddleFailure) {
      status(`PaddleOCR 本地模型此前加载失败：${paddleFailure}\n刷新网页后可再尝试加载，或先检查网络。`);
      return;
    }
    setBusy(true);
    record.error = '正在重新识别……';
    await txPut(record);
    await refresh();
    try {
      const success = await recognizeFile(file, record, file.name || '重新上传的照片', engineOverride);
      record.thumb = await makeThumb(file);
      await txPut(record);
      await refresh();
      status(success ? '重新识别完成，请核对字段后确认。' : '重新识别失败，请查看该条记录的错误原因。');
    } finally {
      activeImageName = '';
      setBusy(false);
      $('retryInput').value = '';
      retryRecordId = null;
      retryEngineOverride = null;
    }
  }

  $('saveOcrConfigBtn').addEventListener('click', () => saveSettings(true));
  $('operatorName').addEventListener('change', () => {
    localStorageSet('mingpai-operator-name', $('operatorName').value.trim());
    status('已保存当前浏览器的检定员姓名；新记录将自动带入该姓名。');
  });
  $('unitName').addEventListener('change', () => {
    localStorageSet('mingpai-unit-name', $('unitName').value.trim());
    status('已保存单位名称；后续新记录会自动带入。');
  });
  $('dept').addEventListener('change', () => {
    localStorageSet('mingpai-dept', $('dept').value.trim());
    status('已保存当前科室；后续新记录会自动继承。');
  });
  $('workdate').addEventListener('change', () => {
    localStorageSet('mingpai-workdate', $('workdate').value);
    status('已保存检定日期；后续新记录会自动带入。');
  });
  $('saveSyncConfigBtn').addEventListener('click', () => {
    const key = $('syncSharedKey').value.trim();
    localStorageSet('mingpai-feishu-sync-key', key);
    // 清理旧版本保存的网址，避免以后误用。Worker 地址已固定在程序中。
    try {
      localStorage.removeItem('mingpai-feishu-sync-url');
      localStorage.removeItem('mingpai-tencent-sync-url');
    } catch {}
    status(key ? '共享访问密钥已保存在当前浏览器。请点击“验证飞书多维表格”；以后确认记录会自动同步。' : '尚未填写共享访问密钥。');
  });
  $('setupTencentBtn').addEventListener('click', setupFeishuSync);
  $('syncAllBtn').addEventListener('click', async () => {
    const pendingSync = confirmedRecords().filter(record => record.syncStatus !== 'synced');
    if (!pendingSync.length) { status('没有需要同步的已确认记录。'); return; }
    if (!confirm(`即将依次同步 ${pendingSync.length} 条已确认记录到飞书多维表格，继续吗？`)) return;
    let success = 0, failed = 0;
    for (const record of pendingSync) {
      const ok = await syncRecordToFeishu(record, { silent: true });
      if (ok) success++; else failed++;
    }
    status(`批量同步完成：成功 ${success} 条，失败 ${failed} 条。失败记录会保留在本地，可逐条重试。`);
  });
  $('clearKeyBtn').addEventListener('click', () => {
    $('ocrApiKey').value = '';
    try { localStorage.removeItem('mingpai-ocrspace-key'); } catch {}
    status('已清除当前浏览器保存的 OCR.space API Key。若使用自动模式，将直接尝试本地 PaddleOCR。');
  });
  $('ocrMode').addEventListener('change', () => {
    localStorageSet('mingpai-ocr-mode', $('ocrMode').value);
    const mode = $('ocrMode').value;
    status(mode === 'auto' ? '已切换为自动模式：下一张照片优先 OCR.space，若云端限额/请求失败将切换到本地 PaddleOCR。' : mode === 'space' ? '已切换为仅 OCR.space 模式；云端失败时不会自动调用 Paddle。' : '已切换为仅 PaddleOCR.js 本地模式。首次需要联网下载 SDK 默认模型。');
  });
  $('ocrEngine').addEventListener('change', () => localStorageSet('mingpai-ocrspace-engine', $('ocrEngine').value));
  $('preloadPaddleBtn').addEventListener('click', async () => {
    if (busy) return;
    setBusy(true);
    try {
      await getPaddleOcr();
      status(`${paddleOcrVersion || 'PaddleOCR'} 备用模型已经初始化成功。本次打开网页期间可直接用于本地识别；请再上传一张测试照片验证推理。`);
    } catch (error) {
      status(`PaddleOCR 备用模型未能初始化：${error?.message || String(error)}\n可能是手机内存、模型下载地址或网络限制。刷新网页可清除本次错误状态后再试。`);
    } finally {
      setBusy(false);
    }
  });

  $('cameraBtn').addEventListener('click', () => $('cameraInput').click());
  $('galleryBtn').addEventListener('click', () => $('galleryInput').click());
  $('cameraInput').addEventListener('change', event => handleFiles(event.target.files));
  $('galleryInput').addEventListener('change', event => handleFiles(event.target.files));
  $('retryInput').addEventListener('change', async event => {
    const file = event.target.files && event.target.files[0];
    const record = records.find(item => item.id === retryRecordId);
    if (file && record) await retryRecognition(record, file, retryEngineOverride);
  });

  $('pasteOcrBtn').addEventListener('click', async () => {
    const raw = $('pasteOcrText').value.trim();
    if (!raw) { alert('请先粘贴 OCR 文字。'); return; }
    if (!db) { alert('本地记录正在初始化，请稍后重试。'); return; }
    const record = newRecord();
    applyTextResult(record, raw, '手动粘贴的 OCR 文字');
    record.thumb = null;
    await txPut(record);
    await refresh();
    $('pasteOcrText').value = '';
    status('已加入 1 条待审核记录。请检查字段，修正后点击“确认这条记录”。');
  });
  $('clearPasteBtn').addEventListener('click', () => $('pasteOcrText').value = '');

  $('recordList').addEventListener('change', async event => {
    const element = event.target;
    if (!element.dataset.id || !element.dataset.field) return;
    const record = records.find(item => item.id === element.dataset.id);
    if (!record) return;
    record[element.dataset.field] = element.value;
    if (element.dataset.field === 'operatorName') {
      record.operatorName = element.value.trim();
      $('operatorName').value = record.operatorName;
      localStorageSet('mingpai-operator-name', record.operatorName);
    }
    if (element.dataset.field === 'dept') {
      record.dept = element.value.trim();
      $('dept').value = record.dept;
      localStorageSet('mingpai-dept', record.dept);
    }
    if (element.dataset.field === 'unitName') {
      record.unitName = element.value.trim();
      $('unitName').value = record.unitName;
      localStorageSet('mingpai-unit-name', record.unitName);
    }
    if (element.dataset.field === 'date') {
      $('workdate').value = element.value;
      localStorageSet('mingpai-workdate', element.value);
    }
    if (['unitName', 'name', 'manufacturer', 'model', 'code', 'raw', 'dept', 'date', 'operatorName', 'remark'].includes(element.dataset.field) && record.status === 'confirmed') {
      record.status = 'pending';
      if (record.remoteRecordId) record.syncStatus = 'pending';
    }
    await txPut(record);
    await refresh();
  });
  $('recordList').addEventListener('click', async event => {
    const photo = event.target.closest('img[data-open-image]');
    if (photo) {
      const record = records.find(item => item.id === photo.dataset.openImage);
      if (record?.thumb) {
        const url = URL.createObjectURL(record.thumb);
        const opened = window.open(url, '_blank');
        if (!opened) alert('浏览器阻止了新窗口，请允许打开照片预览。');
        setTimeout(() => URL.revokeObjectURL(url), 60000);
      }
      return;
    }
    const button = event.target.closest('button[data-action]');
    if (!button) return;
    if (busy) { status('当前识别任务尚未完成，请稍候。'); return; }
    const record = records.find(item => item.id === button.dataset.id);
    if (!record) return;
    if (button.dataset.action === 'retry' || button.dataset.action === 'retry-paddle') {
      retryRecordId = record.id;
      retryEngineOverride = button.dataset.action === 'retry-paddle' ? 'paddle' : null;
      $('retryInput').value = '';
      $('retryInput').click();
      return;
    }
    if (button.dataset.action === 'toggle') {
      if (record.status === 'confirmed') {
        record.status = 'pending';
        if (record.remoteRecordId) record.syncStatus = 'pending';
        await txPut(record); await refresh();
        status('已取消本机的确认状态。注意：已写入飞书的云端记录不会因此自动删除。');
        return;
      }
      const operator = String(record.operatorName || $('operatorName').value || '').trim();
      if (!operator) { alert('请先在页面顶部填写检定员姓名。'); $('operatorName').focus(); return; }
      const unitName = String(record.unitName || $('unitName').value || '').trim();
      if (!unitName) { alert('请先填写单位名称。'); $('unitName').focus(); return; }
      record.operatorName = operator;
      record.unitName = unitName;
      record.status = 'confirmed';
      if (record.remoteRecordId) record.syncStatus = 'pending';
      await txPut(record); await refresh();
      await syncRecordToFeishu(record);
      return;
    } else if (button.dataset.action === 'sync') {
      await syncRecordToFeishu(record);
      return;
    } else if (button.dataset.action === 'delete') {
      if (!confirm('确定删除这条本地记录吗？')) return;
      await txDelete(record.id);
    } else if (button.dataset.action === 'reparse') {
      const fields = extract(record.raw);
      record.name = fields.name;
      record.manufacturer = fields.manufacturer;
      record.model = fields.model;
      record.code = fields.code;
      record.status = 'pending';
      await txPut(record);
    }
    await refresh();
  });

  $('statusFilter').addEventListener('change', () => { page = 0; render(); });
  $('searchBox').addEventListener('input', () => { page = 0; render(); });
  $('prevBtn').addEventListener('click', () => { page = Math.max(0, page - 1); render(); });
  $('nextBtn').addEventListener('click', () => { page++; render(); });

  function confirmedRecords() { return records.filter(record => record.status === 'confirmed').sort((a, b) => a.createdAt - b.createdAt); }
  const columnOrder = ['unitName', 'dept', 'date', 'operatorName', 'raw', 'name', 'manufacturer', 'model', 'code', 'remark'];
  function tsvValue(value) { return String(value ?? '').replace(/\r?\n/g, ' ').replace(/\t/g, ' '); }
  $('copyBtn').addEventListener('click', async () => {
    const rows = confirmedRecords();
    if (!rows.length) { alert('没有已确认的记录。请先审核并确认记录。'); return; }
    const text = rows.map(record => columnOrder.map(key => tsvValue(record[key])).join('\t')).join('\n');
    try {
      await navigator.clipboard.writeText(text);
      alert(`已复制 ${rows.length} 条已确认记录。列顺序与飞书多维表格一致。`);
    } catch {
      const opened = window.open('', '_blank');
      if (opened) {
        opened.document.write('<textarea style="width:98%;height:90vh;font-size:14px"></textarea>');
        opened.document.querySelector('textarea').value = text;
        opened.document.title = '复制已确认数据';
      }
      alert('浏览器未允许自动复制，已尝试打开可手动全选复制的页面。');
    }
  });
  $('csvBtn').addEventListener('click', () => {
    const rows = confirmedRecords();
    if (!rows.length) { alert('没有已确认的记录。'); return; }
    const headers = ['单位名称', '科室', '检定日期', '检定员', '铭牌文本', '设备名称', '生产厂家', '型号', '出厂编号', '备注'];
    const csv = '\ufeff' + [headers, ...rows.map(record => columnOrder.map(key => record[key] || ''))].map(row => row.map(csvEscape).join(',')).join('\r\n');
    download(new Blob([csv], { type: 'text/csv;charset=utf-8' }), '设备铭牌已确认数据.csv');
  });
  $('jsonBtn').addEventListener('click', () => {
    const backup = { app: 'mingpai-dual-ocr-feishu-v2', exportedAt: new Date().toISOString(), note: '字段备份不含原始照片缩略图；照片缩略图只保存在当前手机浏览器。', records: records.map(({ thumb, ...record }) => record) };
    download(new Blob([JSON.stringify(backup, null, 2)], { type: 'application/json;charset=utf-8' }), '设备铭牌字段备份.json');
  });
  $('restoreBtn').addEventListener('click', () => $('restoreInput').click());
  $('restoreInput').addEventListener('change', async event => {
    const file = event.target.files && event.target.files[0];
    if (!file) return;
    try {
      const backup = JSON.parse(await file.text());
      if (!Array.isArray(backup.records)) throw new Error('备份文件格式不正确');
      if (!confirm(`备份中有 ${backup.records.length} 条记录。选择“确定”后会合并到本地，重复 ID 会覆盖。继续吗？`)) return;
      for (const record of backup.records) {
        if (!record.id) record.id = 'restore-' + Date.now() + '-' + Math.random().toString(36).slice(2);
        normalizeRecord(record);
        await txPut({ ...record, thumb: null });
      }
      await refresh();
      alert('恢复完成。');
    } catch (error) {
      alert('恢复失败：' + (error?.message || String(error)));
    } finally {
      $('restoreInput').value = '';
    }
  });
  function download(blob, filename) {
    const url = URL.createObjectURL(blob);
    const anchor = document.createElement('a');
    anchor.href = url;
    anchor.download = filename;
    document.body.appendChild(anchor);
    anchor.click();
    anchor.remove();
    setTimeout(() => URL.revokeObjectURL(url), 1500);
  }

  openDB().then(async database => {
    db = database;
    await refresh();
    const mode = $('ocrMode').value;
    status(mode === 'paddle'
      ? '已就绪：仅使用本地 PaddleOCR。建议先点击“提前加载 Paddle 备用模型”，验证当前手机可以加载 PP-OCRv6。'
      : mode === 'space'
        ? '已就绪：仅使用 OCR.space。请保存 API Key 后拍照。'
        : '已就绪：优先 OCR.space；检测到限额/限流后自动切换 Paddle 本地备用。建议提前加载备用模型。');
  }).catch(error => status('本地数据库初始化失败：' + (error?.message || String(error)) + '。请换用最新版 Chrome/Safari，并确保网站使用 HTTPS。'));
})();
