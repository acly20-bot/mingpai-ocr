import { PaddleOCR } from '@paddleocr/paddleocr-js';

// If a GitHub Pages deployment replaces a hashed Vite chunk while an old page is still open,
// force one clean reload instead of leaving PaddleOCR permanently broken.
window.addEventListener('vite:preloadError', (event) => {
  try { event.preventDefault(); } catch {}
  const key = 'mingpai-vite-preload-reload';
  const last = Number(sessionStorage.getItem(key) || 0);
  if (Date.now() - last > 30000) {
    sessionStorage.setItem(key, String(Date.now()));
    location.reload();
  }
});
(() => {
  'use strict';

  const DB_NAME = 'mingpai-free-v1'; // Keep existing DB name to preserve prior records.
  const STORE = 'records';
  const META_STORE = 'meta';
  const PAGE_SIZE = 10;
  const OCR_SPACE_ENDPOINT = 'https://api.ocr.space/parse/image';
  const CLOUD_TIMEOUT_MS = 90000;
  const PADDLE_INIT_TIMEOUT_MS = 180000;
  const PADDLE_IMAGE_TIMEOUT_MS = 120000;
  const CLOUD_MAX_BYTES = 950 * 1024;
  const SYNC_SERVICE_URL = 'https://1387910526-0eai63d9rp.ap-guangzhou.tencentscf.com';
  const SYNC_RETRY_DELAYS_MS = [0, 1200, 2500];
  const $ = id => document.getElementById(id);

  let db;
  let records = [];
  let page = 0;
  let busy = false;
  let objectUrls = [];
  let activeImageName = '';
  let retryRecordId = null;
  let retryEngineOverride = null;
  let paddleOcr = null;
  let paddlePromise = null;
  let paddleFailure = '';
  let paddleOcrVersion = '';
  let cloudQuotaReachedThisSession = false;
  const syncingIds = new Set();
  let sharedKnowledge = [];
  let sharedKnowledgeMeta = null;
  let selectedIds = new Set();
  let autoRetryRunning = false;
  const KNOWLEDGE_CACHE_KEY = 'shared-knowledge-v1';
  const KNOWLEDGE_CACHE_MAX_AGE_MS = 6 * 60 * 60 * 1000;

  const today = new Date();
  const defaultToday = `${today.getFullYear()}-${String(today.getMonth() + 1).padStart(2, '0')}-${String(today.getDate()).padStart(2, '0')}`;

  function status(message) { $('progress').textContent = message; }
  function esc(value) {
    return String(value ?? '').replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
  }
  function csvEscape(value) { return '"' + String(value ?? '').replace(/"/g, '""') + '"'; }
  function localStorageGet(key, fallback = '') { try { return localStorage.getItem(key) ?? fallback; } catch { return fallback; } }
  function localStorageSet(key, value) { try { localStorage.setItem(key, value); } catch {} }

  function applySavedSettings() {
    $('ocrApiKey').value = localStorageGet('mingpai-ocrspace-key');
    $('ocrMode').value = localStorageGet('mingpai-ocr-mode', 'auto');
    $('ocrEngine').value = localStorageGet('mingpai-ocrspace-engine', '2');
    $('operatorName').value = localStorageGet('mingpai-operator-name');
    $('unitName').value = localStorageGet('mingpai-unit-name');
    $('dept').value = localStorageGet('mingpai-dept');
    const savedWorkdate = localStorageGet('mingpai-workdate', defaultToday);
    $('workdate').value = savedWorkdate === defaultToday ? savedWorkdate : defaultToday;
    localStorageSet('mingpai-workdate', $('workdate').value);
    $('syncSharedKey').value = localStorageGet('mingpai-feishu-sync-key', localStorageGet('mingpai-tencent-sync-key'));
    if ($('customDeviceNames')) $('customDeviceNames').value = localStorageGet('mingpai-classifier-device-names');
    if ($('customManufacturers')) $('customManufacturers').value = localStorageGet('mingpai-classifier-manufacturers');
    if ($('advancedSettings') && (!$('syncSharedKey').value.trim() || (!$('ocrApiKey').value.trim() && $('ocrMode').value !== 'paddle'))) {
      $('advancedSettings').open = true;
    }
  }
  function saveSettings(showMessage = true) {
    const key = $('ocrApiKey').value.trim();
    localStorageSet('mingpai-ocrspace-key', key);
    localStorageSet('mingpai-ocr-mode', $('ocrMode').value);
    localStorageSet('mingpai-ocrspace-engine', $('ocrEngine').value);
    if (showMessage) {
      const mode = $('ocrMode').value;
      status(mode === 'paddle'
        ? '设置已保存：仅使用 PaddleOCR.js + PP-OCRv6 本地识别。'
        : mode === 'space'
          ? (key ? '设置已保存：仅使用 OCR.space 云端识别。' : '设置已保存，但尚未填写 OCR.space API Key。')
          : (key ? '设置已保存：优先 OCR.space；检测到限额/服务异常时会切换本地 PaddleOCR。' : '设置已保存：未填写 API Key，自动模式会直接尝试本地 PaddleOCR。'));
    }
  }
  function updateMode(mode, persist = true) {
    $('ocrMode').value = mode;
    if (persist) localStorageSet('mingpai-ocr-mode', mode);
  }
  applySavedSettings();

  function getSyncConfig() {
    return {
      url: SYNC_SERVICE_URL,
      key: ($('syncSharedKey')?.value || localStorageGet('mingpai-feishu-sync-key', localStorageGet('mingpai-tencent-sync-key'))).trim()
    };
  }
  function wait(ms) { return new Promise(resolve => setTimeout(resolve, ms)); }
  async function callSyncService(path, payload = {}) {
    const config = getSyncConfig();
    if (!config.key) throw new Error('尚未填写共享访问密钥。');

    let lastNetworkError = null;
    for (let attempt = 0; attempt < SYNC_RETRY_DELAYS_MS.length; attempt++) {
      const delay = SYNC_RETRY_DELAYS_MS[attempt];
      if (delay) await wait(delay);

      let response;
      const controller = new AbortController();
      const requestTimeout = path === '/knowledge' ? 90000 : 30000;
      const abortTimer = setTimeout(() => controller.abort(), requestTimeout);
      try {
        response = await fetch(config.url + path, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json', 'X-Mingpai-Key': config.key },
          body: JSON.stringify(payload),
          signal: controller.signal
        });
      } catch (error) {
        if (error?.name === 'AbortError') lastNetworkError = new Error(`请求超过 ${Math.round(requestTimeout / 1000)} 秒未完成`);
        else lastNetworkError = error;
        if (attempt < SYNC_RETRY_DELAYS_MS.length - 1) continue;
        throw new Error(`无法连接同步服务，已自动重试 ${SYNC_RETRY_DELAYS_MS.length} 次：${lastNetworkError?.message || String(lastNetworkError)}`);
      } finally {
        clearTimeout(abortTimer);
      }
      const text = await response.text();
      let data;
      try { data = text ? JSON.parse(text) : {}; } catch { data = { error: text || `HTTP ${response.status}` }; }

      // HTTP 返回说明已经连接到同步服务；业务错误不盲目重复提交。
      if (!response.ok || data.ok === false) throw new Error(data.error || data.message || `同步服务请求失败（HTTP ${response.status}）`);
      return data;
    }

    throw new Error('无法连接同步服务：' + (lastNetworkError?.message || '未知网络错误'));
  }
  function updateKnowledgeStatus(message) {
    const el = $('knowledgeStatus');
    if (el) el.textContent = message;
  }
  async function metaGet(key) {
    if (!db || !db.objectStoreNames.contains(META_STORE)) return null;
    return new Promise((resolve, reject) => {
      const req = db.transaction(META_STORE, 'readonly').objectStore(META_STORE).get(key);
      req.onsuccess = () => resolve(req.result?.value ?? null);
      req.onerror = () => reject(req.error);
    });
  }
  async function metaPut(key, value) {
    if (!db || !db.objectStoreNames.contains(META_STORE)) return;
    return new Promise((resolve, reject) => {
      const req = db.transaction(META_STORE, 'readwrite').objectStore(META_STORE).put({ key, value });
      req.onsuccess = () => resolve();
      req.onerror = () => reject(req.error);
    });
  }
  function applySharedKnowledgePayload(data, sourceLabel = '') {
    const entries = Array.isArray(data?.entries) ? data.entries : [];
    sharedKnowledge = entries.map(item => ({
      ...item,
      _modelNorm: normalizeMatch(item.model),
      _makerNorm: normalizeMatch(item.manufacturer),
      _nameNorm: normalizeMatch(item.name)
    })).filter(item => item._modelNorm || item._makerNorm || item._nameNorm);
    sharedKnowledgeMeta = data || {};
    const liveText = Number(data?.liveFeishuRecords || 0) ? `，飞书现有 ${Number(data.liveFeishuRecords || 0)} 条记录参与更新` : '';
    const sourceText = sourceLabel ? `（${sourceLabel}）` : '';
    updateKnowledgeStatus(`共享知识库：已加载 ${sharedKnowledge.length} 条有效知识${liveText}${sourceText}`);
  }
  async function loadCachedKnowledge() {
    try {
      const cached = await metaGet(KNOWLEDGE_CACHE_KEY);
      if (!cached?.data?.entries?.length) return false;
      applySharedKnowledgePayload(cached.data, '本机缓存');
      return cached;
    } catch { return false; }
  }
  async function loadSharedKnowledge(force = false, silent = true) {
    const config = getSyncConfig();
    if (!config.key) {
      updateKnowledgeStatus(sharedKnowledge.length ? `共享知识库：已加载 ${sharedKnowledge.length} 条本机缓存，等待同步密钥后更新` : '共享知识库：等待填写共享访问密钥');
      return false;
    }
    try {
      const cached = await metaGet(KNOWLEDGE_CACHE_KEY);
      const cacheFresh = cached?.savedAt && (Date.now() - Number(cached.savedAt) < KNOWLEDGE_CACHE_MAX_AGE_MS);
      if (!force && cacheFresh && cached?.data?.entries?.length) {
        applySharedKnowledgePayload(cached.data, '本机缓存');
        return true;
      }
      if (!silent) status(force ? '正在从飞书重新聚合共享知识库……' : '正在后台更新共享知识库……');
      if (!sharedKnowledge.length) updateKnowledgeStatus('共享知识库：正在加载……');
      const data = await callSyncService('/knowledge', { force });
      applySharedKnowledgePayload(data, '已更新');
      await metaPut(KNOWLEDGE_CACHE_KEY, { savedAt: Date.now(), data });
      if (!silent) status(`共享知识库刷新完成：${sharedKnowledge.length} 条知识。${data.liveError ? '飞书实时增量暂未读取：' + data.liveError : '已合并飞书现有记录。'}`);
      return true;
    } catch (error) {
      updateKnowledgeStatus(sharedKnowledge.length ? `共享知识库：使用本机缓存 ${sharedKnowledge.length} 条（后台更新失败）` : '共享知识库：加载失败（仍可使用本机历史和内置规则）');
      if (!silent) status('共享知识库加载失败：' + (error?.message || String(error)));
      return false;
    }
  }
  function learnSharedRecordLocally(record) {
    if (!record || !record.model) return;
    const modelNorm = normalizeMatch(record.model);
    const makerNorm = normalizeMatch(record.manufacturer);
    const nameNorm = normalizeMatch(record.name);
    if (!modelNorm) return;
    const same = sharedKnowledge.find(item => item._modelNorm === modelNorm && item._makerNorm === makerNorm && item._nameNorm === nameNorm);
    if (same) { same.count = Number(same.count || 0) + 1; same.liveCount = Number(same.liveCount || 0) + 1; return; }
    sharedKnowledge.push({ name: record.name || '', manufacturer: record.manufacturer || '', model: record.model || '', count: 1, liveCount: 1, confidence: '中', _modelNorm: modelNorm, _makerNorm: makerNorm, _nameNorm: nameNorm });
  }

  async function syncRecordToFeishu(record, { silent = false } = {}) {
    if (!record || record.status !== 'confirmed') {
      if (!silent) status('请先确认记录，再同步到飞书。');
      return false;
    }
    if (syncingIds.has(record.id)) return false;
    const operator = String(record.operatorName || $('operatorName').value || '').trim();
    if (!operator) {
      if (!silent) alert('请先在页面顶部填写检定员姓名，然后再确认/同步记录。');
      return false;
    }
    record.operatorName = operator;
    const config = getSyncConfig();
    if (!config.key) {
      record.syncStatus = 'local-only';
      record.syncError = '尚未填写共享访问密钥；记录仍保存在本机。';
      await txPut(record); await refresh();
      if (!silent) status('记录已在本机确认，但尚未填写共享访问密钥。填写并保存密钥后，可点击“同步/重试飞书”。');
      return false;
    }
    syncingIds.add(record.id);
    record.syncStatus = 'syncing';
    record.syncError = '';
    await txPut(record); await refresh();
    try {
      const data = await callSyncService('/sync', { record: {
        id: record.id, unitName: record.unitName || record.batch || '', dept: record.dept || '', date: record.date || '', raw: record.raw || '',
        name: record.name || '', manufacturer: record.manufacturer || '', model: record.model || '',
        code: record.code || '', operatorName: record.operatorName || '', remark: record.remark || '',
        feishuRecordId: record.feishuRecordId || record.remoteRecordId || ''
      }});
      record.syncStatus = 'synced';
      record.syncError = '';
      record.feishuRecordId = data.recordId || record.feishuRecordId || record.remoteRecordId || '';
      // Keep the old property too so records created by earlier Cloudflare versions remain compatible.
      record.remoteRecordId = record.feishuRecordId;
      record.syncedAt = Date.now();
      learnSharedRecordLocally(record);
      await txPut(record); await refresh();
      status(`已确认并同步飞书：${record.name || '未填写设备名称'}（检定员：${record.operatorName}）。${data.action === 'updated' ? '已更新已有云端记录。' : data.action === 'recovered' ? '已找回先前已创建的云端记录并恢复同步。' : '已新增云端记录。'}`);
      return true;
    } catch (error) {
      record.syncStatus = 'error';
      record.syncError = error?.message || String(error);
      await txPut(record); await refresh();
      status(`本地记录已保留，但飞书同步失败：${record.syncError}
请检查同步设置或网络，然后点击该记录的“同步/重试飞书”。`);
      return false;
    } finally {
      syncingIds.delete(record.id);
    }
  }
  async function setupFeishuSync() {
    try {
      status('正在验证飞书同步服务、应用权限和多维表格 10 个字段……');
      const data = await callSyncService('/setup', {});
      status(data.message || '飞书多维表格连接验证成功，字段已就绪。现在确认记录后会自动同步。');
      alert(data.message || '飞书多维表格验证成功。');
    } catch (error) {
      status('飞书初始化失败：' + (error?.message || String(error)) + '\n请检查共享访问密钥、网络、飞书应用凭证，以及多维表格应用权限。');
    }
  }
  async function openDB() {
    return new Promise((resolve, reject) => {
      const request = indexedDB.open(DB_NAME, 2);
      request.onupgradeneeded = () => {
        const database = request.result;
        if (!database.objectStoreNames.contains(STORE)) database.createObjectStore(STORE, { keyPath: 'id' });
        if (!database.objectStoreNames.contains(META_STORE)) database.createObjectStore(META_STORE, { keyPath: 'key' });
      };
      request.onsuccess = () => resolve(request.result);
      request.onerror = () => reject(request.error);
    });
  }
  function txPut(record) {
    return new Promise((resolve, reject) => {
      const tx = db.transaction(STORE, 'readwrite');
      tx.objectStore(STORE).put(record);
      tx.oncomplete = () => resolve();
      tx.onerror = () => reject(tx.error);
    });
  }
  function txDelete(id) {
    return new Promise((resolve, reject) => {
      const tx = db.transaction(STORE, 'readwrite');
      tx.objectStore(STORE).delete(id);
      tx.oncomplete = () => resolve();
      tx.onerror = () => reject(tx.error);
    });
  }
  function txAll() {
    return new Promise((resolve, reject) => {
      const request = db.transaction(STORE, 'readonly').objectStore(STORE).getAll();
      request.onsuccess = () => resolve(request.result || []);
      request.onerror = () => reject(request.error);
    });
  }
  function normalizeRecord(record) {
    if (record.unitName == null) record.unitName = record.batch || '';
    if (record.remark == null) record.remark = '';
    if (record.operatorName == null) record.operatorName = '';
    if (record.classifyNote == null) record.classifyNote = '';
    return record;
  }
  async function refresh() {
    records = (await txAll()).map(normalizeRecord).sort((a, b) => b.createdAt - a.createdAt);
    render();
  }
  function getFiltered() {
    const filter = $('statusFilter').value;
    const query = $('searchBox').value.trim().toLowerCase();
    return records.filter(record =>
      (filter === 'all' || (filter === 'pending' ? record.status !== 'confirmed' : filter === 'confirmed' ? record.status === 'confirmed' : filter === 'sync-error' ? record.status === 'confirmed' && record.syncStatus === 'error' : true)) &&
      (!query || [record.unitName, record.name, record.manufacturer, record.model, record.code, record.raw, record.dept, record.operatorName, record.remark].join(' ').toLowerCase().includes(query))
    );
  }
  function render() {
    objectUrls.forEach(url => URL.revokeObjectURL(url));
    objectUrls = [];
    const total = records.length;
    const pending = records.filter(r => r.status !== 'confirmed').length;
    $('countAll').textContent = `总记录：${total}`;
    $('countPending').textContent = `待审核：${pending}`;
    $('countOk').textContent = `已确认：${total - pending}`;
    const unsynced = records.filter(r => r.status === 'confirmed' && r.syncStatus !== 'synced').length;
    if ($('countSyncPending')) $('countSyncPending').textContent = `待同步：${unsynced}`;
    if ($('networkPill')) { $('networkPill').textContent = navigator.onLine ? '网络：在线' : '网络：离线'; $('networkPill').className = 'pill mini-net ' + (navigator.onLine ? 'netok' : 'netbad'); }
    if ($('selectedCount')) $('selectedCount').textContent = `已选：${selectedIds.size}`;
    const list = getFiltered();
    const pages = Math.max(1, Math.ceil(list.length / PAGE_SIZE));
    page = Math.min(page, pages - 1);
    const subset = list.slice(page * PAGE_SIZE, (page + 1) * PAGE_SIZE);
    const pageLabel = `第 ${list.length ? page + 1 : 0} / ${list.length ? pages : 0} 页（筛选后 ${list.length} 条）`;
    $('pageText').textContent = pageLabel;
    if ($('pageTextTop')) $('pageTextTop').textContent = pageLabel;
    $('recordList').innerHTML = '';
    if (!subset.length) {
      $('recordList').innerHTML = '<p class="hint">当前没有记录。先拍照或从相册选择铭牌照片。</p>';
      $('prevBtn').disabled = $('nextBtn').disabled = true;
      if ($('prevBtnTop')) $('prevBtnTop').disabled = true;
      if ($('nextBtnTop')) $('nextBtnTop').disabled = true;
      return;
    }
    subset.forEach(record => {
      const card = document.createElement('article');
      card.className = 'card';
      const thumbUrl = record.thumb ? URL.createObjectURL(record.thumb) : '';
      if (thumbUrl) objectUrls.push(thumbUrl);
      card.innerHTML = `
        <div class="cardhead">
          <label class="selectbox" title="选择这条记录用于批量删除"><input type="checkbox" data-select-id="${record.id}" ${selectedIds.has(record.id) ? 'checked' : ''}><span>选择</span></label>
          ${thumbUrl ? `<img class="thumb" data-open-image="${record.id}" alt="点击查看铭牌照片" title="点击查看照片" src="${thumbUrl}">` : '<div class="thumb" style="display:grid;place-items:center;font-size:11px;color:#78849a">无照片</div>'}
          <div class="cardtitle"><strong>${esc(record.name || '未识别设备名称')}</strong><small>${esc(record.unitName || record.batch || '未设置单位')} · ${esc(record.dept || '未设置科室')} · ${esc(record.date || '')}<br>检定员：${esc(record.operatorName || '待填写')} · 飞书：${esc(syncStatusLabel(record))}</small></div>
          <span class="badge ${record.status === 'confirmed' ? 'ok' : ''}">${record.status === 'confirmed' ? '已确认' : '待审核'}</span>
        </div>
        ${record.error ? `<div class="errornote">${esc(record.error)}</div>` : ''}
        ${record.syncError ? `<div class="errornote">飞书同步失败：${esc(record.syncError)}</div>` : ''}
        ${record.classifyNote ? `<div class="smartnote">${esc(record.classifyNote)}</div>` : ''}
        <div class="grid">
          ${makeField(record, 'unitName', '单位名称', 'text')}${makeField(record, 'dept', '科室', 'text')}
          ${makeField(record, 'date', '检定日期', 'date')}${makeField(record, 'operatorName', '检定员', 'text')}
          ${makeField(record, 'name', '设备名称', 'text')}${makeField(record, 'manufacturer', '生产厂家', 'text')}
          ${makeField(record, 'model', '型号', 'text')}${makeField(record, 'code', '出厂编号', 'text')}
          <div class="full"><label>备注（可留空，由检定员手动填写）</label><textarea rows="2" data-id="${record.id}" data-field="remark">${esc(record.remark || '')}</textarea></div>
          <div class="full"><label>铭牌文本（可修正 OCR 原文）</label><textarea rows="6" data-id="${record.id}" data-field="raw">${esc(record.raw || '')}</textarea></div>
        </div>
        <div class="controls">
          <button class="btn ${record.status === 'confirmed' ? 'light' : 'secondary'}" data-action="toggle" data-id="${record.id}">${record.status === 'confirmed' ? '取消确认' : '确认记录'}</button>
          <button class="btn light" data-action="reparse" data-id="${record.id}">智能重分类</button>
          <button class="btn light" data-action="retry-space" data-id="${record.id}">OCR.space 重识别（选照片）</button>
          <button class="btn secondary" data-action="retry-paddle" data-id="${record.id}">Paddle 重识别（选照片）</button>
          ${record.status === 'confirmed' ? `<button class="btn secondary" data-action="sync" data-id="${record.id}">${record.syncStatus === 'synced' ? '重新同步云端记录' : '同步/重试飞书'}</button>` : ''}
          <button class="btn danger" data-action="delete" data-id="${record.id}">删除</button>
        </div>`;
      $('recordList').appendChild(card);
    });
    $('prevBtn').disabled = page <= 0;
    $('nextBtn').disabled = page >= pages - 1;
    if ($('prevBtnTop')) $('prevBtnTop').disabled = page <= 0;
    if ($('nextBtnTop')) $('nextBtnTop').disabled = page >= pages - 1;
  }
  function syncStatusLabel(record) {
    if (record.syncStatus === 'synced') return '已同步';
    if (record.syncStatus === 'syncing') return '同步中';
    if (record.syncStatus === 'error') return '失败待重试';
    if (record.syncStatus === 'pending') return '有修改待同步';
    if (record.syncStatus === 'local-only') return '仅本机保存';
    return record.status === 'confirmed' ? '尚未同步' : '待确认';
  }
  function makeField(record, field, label, type) {
    return `<div><label>${label}</label><input type="${type}" data-id="${record.id}" data-field="${field}" value="${esc(record[field] || '')}"></div>`;
  }

  const BUILTIN_DEVICE_NAMES = [
    '彩色多普勒超声诊断仪','彩色超声诊断仪','超声诊断仪','超声诊断系统','便携式超声诊断仪',
    '病人监护仪','多参数监护仪','心电监护仪','监护仪','数字心电图机','心电图机','心电图仪','除颤监护仪','除颤仪',
    '输液泵','注射泵','输注泵','呼吸机','麻醉机','麻醉工作站','高频电刀','电外科工作站',
    '全自动生化分析仪','生化分析仪','全自动血细胞分析仪','血细胞分析仪','血气分析仪','尿液分析仪',
    '凝血分析仪','免疫分析仪','化学发光免疫分析仪','酶标仪','洗板机','离心机','显微镜',
    '血液透析机','血液透析滤过机','血液净化设备','内窥镜','电子胃镜','电子肠镜','内窥镜系统',
    '医用冷藏箱','医用冰箱','医用低温保存箱','灭菌器','蒸汽灭菌器','婴儿培养箱','辐射保暖台',
    '呼吸湿化治疗仪','无创呼吸机','有创呼吸机','制氧机','吸引器','负压吸引器','雾化器',
    'X射线计算机体层摄影设备','计算机断层扫描系统','CT扫描仪','磁共振成像系统','磁共振成像设备',
    '数字化医用X射线摄影系统','医用X射线摄影系统','移动式C形臂X射线机','移动式X射线机',
    '手术无影灯','手术床','电动手术台','医用吊塔','体外除颤器','自动体外除颤器','心脏除颤器','医用诊断X射线辐射源（牙片机）','电子血压计',
    '医用数字摄影系统（DR）X射线辐射源','医用超声诊断仪（B超）超声源','医用诊断数字减影血管造影（DSA）系统X射线辐射源',
    '医用诊断全景牙科X射线辐射源','医用诊断X射线辐射源（C臂）','医用诊断X射线辐射源（胃肠机）','医用乳腺X射线辐射源',
    '医用诊断螺旋计算机断层摄影装置（CT）X射线辐射源','医用磁共振成像系统','数字脑电图仪','台式血压计','非接触式眼压计',
    '急救和转运呼吸机','麻醉机（呼吸部分）','单通道注射泵','双通道注射泵','浮标式氧气吸入器','肺功能仪','婴儿辐射保暖台',
    '超声骨密度仪','X射线骨密度仪','医用电子加速器辐射源'
  ];

  const BUILTIN_MANUFACTURER_ALIASES = [
    ['mindray','迈瑞'],['迈瑞','迈瑞'],['philips','飞利浦'],['飞利浦','飞利浦'],['siemens','西门子'],['西门子','西门子'],
    ['ge healthcare','GE医疗'],['general electric','GE医疗'],['ge medical','GE医疗'],['olympus','奥林巴斯'],['奥林巴斯','奥林巴斯'],
    ['dräger','德尔格'],['draeger','德尔格'],['德尔格','德尔格'],['fresenius','费森尤斯'],['费森尤斯','费森尤斯'],
    ['b. braun','贝朗'],['b braun','贝朗'],['贝朗','贝朗'],['roche','罗氏'],['罗氏','罗氏'],['abbott','雅培'],['雅培','雅培'],
    ['medtronic','美敦力'],['美敦力','美敦力'],['stryker','史赛克'],['史赛克','史赛克'],['fujifilm','富士'],['富士','富士'],
    ['canon medical','佳能医疗'],['toshiba medical','东芝医疗'],['biolight','宝莱特'],['宝莱特','宝莱特'],['edan','理邦'],['理邦','理邦'],
    ['comen','科曼'],['科曼','科曼'],['yuwell','鱼跃'],['鱼跃','鱼跃'],['united imaging','联影'],['联影','联影'],
    ['neusoft','东软'],['东软','东软'],['perlong','普朗'],['普朗','普朗'],['zoll','ZOLL Medical Corporation'],['omron','欧姆龙健康医疗株式会社'],['欧姆龙','欧姆龙健康医疗株式会社']
  ];

  function normalizeMatch(value) {
    return String(value || '').toLowerCase().replace(/[\s\u3000:：,，.。;；()（）\[\]【】_\-—/\\]+/g, '');
  }
  function cleanLine(value) {
    return String(value || '').trim().replace(/^[•·*#\-—_\s]+/, '').replace(/[\s]+/g, ' ').slice(0, 160);
  }
  function customDeviceNames() {
    const raw = $('customDeviceNames')?.value || localStorageGet('mingpai-classifier-device-names');
    return String(raw || '').split(/\r?\n/).map(cleanLine).filter(Boolean);
  }
  function customManufacturerAliases() {
    const raw = $('customManufacturers')?.value || localStorageGet('mingpai-classifier-manufacturers');
    return String(raw || '').split(/\r?\n/).map(cleanLine).filter(Boolean).map(line => {
      const parts = line.split(/\s*[=＝|｜\t]\s*/);
      return [parts[0] || '', parts.slice(1).join('=') || parts[0] || ''];
    }).filter(([key]) => key);
  }
  function historicalKnowledge() {
    return records.filter(r => r.status === 'confirmed' && (r.name || r.manufacturer || r.model)).slice(0, 800);
  }
  function scoreHistory(rawNorm) {
    let best = null;
    for (const item of historicalKnowledge()) {
      let score = 0;
      const model = normalizeMatch(item.model);
      const maker = normalizeMatch(item.manufacturer);
      const name = normalizeMatch(item.name);
      if (model && model.length >= 3 && rawNorm.includes(model)) score += 11;
      if (maker && maker.length >= 2 && rawNorm.includes(maker)) score += 6;
      if (name && name.length >= 3 && rawNorm.includes(name)) score += 5;
      if (!best || score > best.score) best = { score, item };
    }
    return best && best.score >= 8 ? best : null;
  }
  function scoreSharedKnowledge(rawNorm, hints = {}) {
    let best = null;
    const hintModel = normalizeMatch(hints.model);
    const hintMaker = normalizeMatch(hints.manufacturer);
    const hintName = normalizeMatch(hints.name);
    for (const item of sharedKnowledge) {
      const model = item._modelNorm || normalizeMatch(item.model);
      const maker = item._makerNorm || normalizeMatch(item.manufacturer);
      const name = item._nameNorm || normalizeMatch(item.name);
      let score = 0;
      const distinctiveModel = model && model.length >= 4 && ((/[a-z]/i.test(model) && /\d/.test(model)) || model.length >= 6);
      const modelHit = Boolean(model && ((hintModel && model === hintModel) || (!hintModel && distinctiveModel && rawNorm.includes(model))));
      const makerHit = Boolean(maker && ((hintMaker && (maker === hintMaker || hintMaker.includes(maker) || maker.includes(hintMaker))) || (!hintMaker && maker.length >= 3 && rawNorm.includes(maker))));
      const nameHit = Boolean(name && ((hintName && name === hintName) || (!hintName && name.length >= 3 && rawNorm.includes(name))));
      if (modelHit) score += hintModel && model === hintModel ? 18 : 14;
      if (makerHit) score += 7;
      if (nameHit) score += 5;
      if (!modelHit && !(makerHit && nameHit)) continue;
      if (item.confidence === '高') score += 4;
      else if (item.confidence === '中高') score += 2;
      else if (item.confidence === '中') score += 1;
      const count = Math.max(0, Number(item.count || 0));
      score += Math.min(4, Math.floor(Math.log10(count + 1) * 2));
      if (!best || score > best.score || (score === best.score && count > Number(best.item.count || 0))) best = { score, item, modelHit, makerHit, nameHit };
    }
    return best && best.score >= 14 ? best : null;
  }

  // 33 类固定标准设备名称。仅在铭牌别名或高置信“厂家+型号”历史证据明确时标准化；
  // 其他设备名称保持 OCR/铭牌原名称，不强制归入这 33 类。
  const STANDARD_DEVICE_RULES = [
    { name:'医用诊断全景牙科X射线辐射源', aliases:['医用诊断全景牙科X射线辐射源','全景牙科X射线机','口腔全景X射线机','数字全景X射线机','Panoramic X-Ray','Dental Panoramic X-Ray'] },
    { name:'医用诊断X射线辐射源（牙片机）', aliases:['医用诊断X射线辐射源（牙片机）','高频牙科X射线机','口内牙科X射线机','牙科X射线机','牙科X光机','Dental X-Ray','Intraoral X-Ray'] },
    { name:'医用诊断数字减影血管造影（DSA）系统X射线辐射源', aliases:['医用诊断数字减影血管造影（DSA）系统X射线辐射源','数字减影血管造影系统','血管造影X射线系统','血管造影系统','Digital Subtraction Angiography','Angiography System'], acronyms:['DSA'] },
    { name:'医用数字摄影系统（DR）X射线辐射源', aliases:['医用数字摄影系统（DR）X射线辐射源','数字化医用X射线摄影系统','数字X射线摄影系统','数字化X射线摄影系统','Digital Radiography','Digital X-Ray System'], acronyms:['DR'] },
    { name:'医用诊断X射线辐射源（C臂）', aliases:['医用诊断X射线辐射源（C臂）','移动式C形臂X射线机','C形臂X射线机','C臂机','Mobile C-Arm','C-Arm'] },
    { name:'医用诊断X射线辐射源（胃肠机）', aliases:['医用诊断X射线辐射源（胃肠机）','数字胃肠X射线机','胃肠X射线机','胃肠透视机','数字胃肠机','Fluoroscopy System','R/F System','Luminos Select'] },
    { name:'医用乳腺X射线辐射源', aliases:['医用乳腺X射线辐射源','数字乳腺X射线摄影系统','乳腺X射线机','乳腺机','Mammography System','Mammography Unit'] },
    { name:'医用诊断螺旋计算机断层摄影装置（CT）X射线辐射源', aliases:['医用诊断螺旋计算机断层摄影装置（CT）X射线辐射源','X射线计算机体层摄影设备','计算机断层扫描系统','CT扫描装置','CT扫描仪','螺旋CT','Computed Tomography','CT Scanner'], acronyms:['CT'] },
    { name:'医用磁共振成像系统', aliases:['医用磁共振成像系统','磁共振成像系统','磁共振扫描仪','Magnetic Resonance Imaging System','MR System'], acronyms:['MRI'] },
    { name:'医用超声诊断仪（B超）超声源', aliases:['医用超声诊断仪（B超）超声源','彩色超声诊断设备','彩色多普勒超声诊断仪','彩色多普勒超声诊断系统','彩色超声诊断仪','超声诊断系统','Diagnostic Ultrasound System','Ultrasound System','B超'] },
    { name:'心脏除颤器', aliases:['心脏除颤器','除颤监护仪','体外除颤监护仪','体外除颤器','除颤器','Defibrillator Monitor','Defibrillator','ZOLL M Series'] },
    { name:'多参数监护仪', aliases:['多参数监护仪','多参数病人监护仪','病人监护仪','床旁监护仪','Multiparameter Patient Monitor','Patient Monitor','Vital Signs Monitor'] },
    { name:'数字心电图机', aliases:['数字心电图机','数字式心电图机','心电图机','心电图仪','Electrocardiograph'], acronyms:['ECG','EKG'] },
    { name:'数字脑电图仪', aliases:['数字脑电图仪','数字脑电图机','脑电图机','脑电图仪','Electroencephalograph','EEG System'], acronyms:['EEG'] },
    { name:'台式血压计', aliases:['台式血压计','台式血压表','汞柱血压计','机械血压计','Sphygmomanometer'] },
    { name:'电子血压计', aliases:['电子血压计','电子血压监测仪','臂式电子血压计','数字血压计','Electronic Blood Pressure Monitor','Digital Blood Pressure Monitor'] },
    { name:'非接触式眼压计', aliases:['非接触式眼压计','非接触眼压计','电脑眼压计','气动眼压计','Non-Contact Tonometer'], acronyms:['NCT'] },
    { name:'急救和转运呼吸机', aliases:['急救和转运呼吸机','急救呼吸机','转运呼吸机','便携式呼吸机','Transport Ventilator','Emergency Ventilator','Portable Ventilator'] },
    { name:'无创呼吸机', aliases:['无创呼吸机','无创通气呼吸机','无创通气设备','Non-invasive Ventilator','Noninvasive Ventilator'], acronyms:['NIV'] },
    { name:'呼吸机', aliases:['呼吸机','医用呼吸机','治疗呼吸机','Medical Ventilator','Ventilator'] },
    { name:'麻醉机（呼吸部分）', aliases:['麻醉机（呼吸部分）','麻醉工作站','麻醉机','Anesthesia Workstation','Anaesthesia Workstation','Anesthesia Machine','Anaesthesia Machine','Anesthesia System'] },
    { name:'双通道注射泵', aliases:['双通道注射泵','双道注射泵','Dual-channel Syringe Pump','Double Syringe Pump'] },
    { name:'单通道注射泵', aliases:['单通道注射泵','单道注射泵','微量注射泵','Single-channel Syringe Pump','Syringe Pump'] },
    { name:'输液泵', aliases:['输液泵','容积式输液泵','静脉输液泵','Volumetric Infusion Pump','Infusion Pump'] },
    { name:'浮标式氧气吸入器', aliases:['浮标式氧气吸入器','浮标式氧气流量计','氧气吸入器','氧气流量计','氧气湿化器','Oxygen Flowmeter','Oxygen Inhaler'] },
    { name:'肺功能仪', aliases:['肺功能仪','肺功能检测仪','肺功能测试仪','肺功能测定仪','Pulmonary Function System','Spirometry System','Spirometer'], acronyms:['PFT'] },
    { name:'血液透析机', aliases:['血液透析机','血液透析设备','血液透析装置','透析机','Hemodialysis Machine','Dialysis Machine'] },
    { name:'婴儿培养箱', aliases:['婴儿培养箱','新生儿培养箱','婴儿保温箱','新生儿保温箱','Infant Incubator','Neonatal Incubator'] },
    { name:'婴儿辐射保暖台', aliases:['婴儿辐射保暖台','婴儿辐射保暖器','新生儿辐射保暖台','新生儿辐射保暖器','Infant Radiant Warmer','Radiant Warmer'] },
    { name:'高频电刀', aliases:['高频电刀','高频手术设备','高频电外科手术系统','电外科工作站','Electrosurgical Unit','Electrosurgical Generator'], acronyms:['ESU'] },
    { name:'超声骨密度仪', aliases:['超声骨密度仪','超声骨密度检测仪','超声骨密度测定仪','Ultrasound Bone Densitometer','Quantitative Ultrasound'], acronyms:['QUS'] },
    { name:'X射线骨密度仪', aliases:['X射线骨密度仪','X射线骨密度测定仪','双能X射线骨密度仪','双能X线骨密度测量仪','双能X线骨密度测定仪','NORLAND双能X线骨密度测量仪','Dual-energy X-ray Absorptiometry'], acronyms:['DXA','DEXA'] },
    { name:'医用电子加速器辐射源', aliases:['医用电子加速器辐射源','医用电子加速器','医用直线加速器','医用电子直线加速器','电子直线加速器','Medical Linear Accelerator','Linear Accelerator'], acronyms:['LINAC'] }
  ];
  const STANDARD_DEVICE_NAMES = new Set(STANDARD_DEVICE_RULES.map(x => x.name));
  const STANDARD_DEVICE_NAME_ALIASES = STANDARD_DEVICE_RULES.flatMap(rule => rule.aliases.map(alias => [alias, rule.name]));

  function hasStandaloneAcronym(raw, acronym) {
    const escaped = String(acronym).replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
    return new RegExp(`(?:^|[^A-Za-z0-9])${escaped}(?:[^A-Za-z0-9]|$)`, 'i').test(String(raw || ''));
  }

  function looksNoise(value) {
    const s = String(value || '').trim();
    return /^(?:220\s*v|110\s*v|50\s*hz|60\s*hz|\d+\s*(?:v|a|w|hz|kg|mm|cm)|yyyy|date|日期|地址|电话|联系电话|tel|邮编|网址|website)$/i.test(s) ||
      /(?:额定电压|额定频率|额定功率|电源要求|电源连接条件|执行标准|注册证|许可证|生产日期|出厂日期|有效期|使用期限|住所|生产地址|企业地址|联系方式|传真|邮编)/i.test(s);
  }
  function isFieldLabelLine(value) {
    const s = String(value || '').trim();
    return /^(?:产品名称|设备名称|仪器名称|商品名称|品名|规格型号|型号规格|型号[、及]\s*规格|产品型号|设备型号|型号|生产厂家|制造厂家|制造商|生产企业(?:名称)?|受托生产企业(?:名称)?|注册人[\/、]生产企业(?:名称)?|生产单位|制造单位|生产厂商|生产厂名称|备案人|出厂编号|出厂序列号|产品生产日期或序列号|产品序列号|序列号|设备编号|产品编号|产品序号|生产编号|机身码|无线传输背夹编号(?:、生产日期)?|sn|s\/n|serial(?:\s+no\.?|\s+number)?|model(?:\s+no\.?)?|type|ref)\s*[：:]?\s*$/i.test(s);
  }
  function cleanFieldValue(value, kind = '') {
    let s = cleanLine(value).replace(/^[：:：\-—\s]+/, '');
    if (kind === 'model') s = s.replace(/^[、,，\s]*(?:规格型号|型号规格|型号[、及]\s*规格|规格|型号)\s*[：:]?\s*/i, '');
    if (kind === 'manufacturer') s = s.replace(/^(?:(?:企业)?名称|生产厂名称|生产企业[\/、]注册人|注册人[\/、]生产企业)\s*[：:]?\s*/i, '');
    if (kind === 'code') s = s.replace(/^(?:sn|s\/n|serial(?:\s+no\.?)?|序列号|出厂编号|生产编号|产品编号|产品序号|设备编号|机身码|器号|无线传输背夹编号(?:、生产日期)?|编号)\s*[：:]?\s*/i, '');
    return s.trim().slice(0, 160);
  }
  function matchLabel(line, label) {
    const source = label instanceof RegExp ? label.source : label.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
    return String(line || '').match(new RegExp('(?:^|[\\s：:/、])(?:' + source + ')\\s*[：:]?\\s*(.*)$', 'i'));
  }
  function validFieldValue(value, kind) {
    const s = cleanFieldValue(value, kind);
    if (!s || looksNoise(s) || isFieldLabelLine(s)) return false;
    if (kind === 'model') {
      if (s.length > 60 || !/[A-Za-z0-9]/.test(s)) return false;
      if (/(?:生产|企业|厂家|名称|地址|住所|电话|注册|许可证|标准|日期|电源|频率|功率|序列|编号)/i.test(s)) return false;
    }
    if (kind === 'manufacturer') {
      if (s.length > 120 || /(?:经销商|代理商|联系方式|地址|住所|电话|邮编|其他内容详见|说明书|声明)/i.test(s)) return false;
    }
    if (kind === 'code') {
      if (s.length > 48 || s.length < 4 || /\s{2,}/.test(s)) return false;
      if (/^(?:19|20)\d{2}(?:[-/.年]\d{1,2})?(?:[-/.月]\d{1,2})?日?$/i.test(s)) return false;
      if (/^(?:\d+(?:\.\d+)?\s*(?:v|a|w|va|hz|kg|mah))$/i.test(s)) return false;
      if (/^(?:IPX\d+|CE\d*|MC|EC|REP|PA)$/i.test(s)) return false;
      if (/^(?:见包装或本体|见包装|见本体|详见说明书|无|不详)$/i.test(s)) return false;
    }
    return true;
  }
  function extractByPriority(lines, labels, kind, { searchRadius = 1, previous = false } = {}) {
    for (const label of labels) {
      for (let i = 0; i < lines.length; i++) {
        const match = matchLabel(lines[i], label);
        if (!match) continue;
        const inline = cleanFieldValue(match[1] || '', kind);
        if (validFieldValue(inline, kind)) return { value: inline.slice(0, 120), index: i, label: String(label) };
        for (let step = 1; step <= searchRadius; step++) {
          const next = cleanFieldValue(lines[i + step] || '', kind);
          if (!next) continue;
          if (isFieldLabelLine(next) || looksNoise(next)) continue;
          if (validFieldValue(next, kind)) return { value: next.slice(0, 120), index: i + step, label: String(label) };
        }
        if (previous) {
          const prev = cleanFieldValue(lines[i - 1] || '', kind);
          if (validFieldValue(prev, kind)) return { value: prev.slice(0, 120), index: i - 1, label: String(label), fromPrevious: true };
        }
      }
    }
    return null;
  }
  function extractLabeled(lines, labels) {
    return extractByPriority(lines, labels, '', { searchRadius: 1 });
  }
  function companyCandidateScore(value, originalLine = '') {
    const s = cleanFieldValue(value, 'manufacturer');
    if (!validFieldValue(s, 'manufacturer')) return -999;
    let score = 0;
    if (/(股份有限公司|有限责任公司|有限公司|股份公司)/.test(s)) score += 14;
    if (/(医疗器械|生物医疗|生物科技|医疗设备|medical|bio-medical|healthcare)/i.test(s)) score += 6;
    if (/(co\.?\s*,?\s*ltd|ltd\.?|gmbh|inc\.?|corp)/i.test(s)) score += 5;
    if (/^[\u4e00-\u9fff]/.test(s)) score += 3;
    if (/^(?:mindray|yuwell|philips|siemens|ge)$/i.test(s)) score -= 2;
    if (/(受托生产企业|生产企业|注册人[\/、]生产企业|制造商|生产厂家)/i.test(originalLine)) score += 5;
    if (/(备案人|注册人)(?![\/、]生产企业)/i.test(originalLine)) score += 1;
    if (/(售后服务|其他内容|说明书|声明|住所|地址|电话|邮编)/i.test(originalLine)) score -= 12;
    return score;
  }
  function extractManufacturerByPriority(lines, labels) {
    for (const label of labels) {
      for (let i = 0; i < lines.length; i++) {
        const match = matchLabel(lines[i], label);
        if (!match) continue;
        const candidates = [];
        const inline = cleanFieldValue(match[1] || '', 'manufacturer');
        if (validFieldValue(inline, 'manufacturer')) candidates.push({ value:inline, index:i, score:companyCandidateScore(inline, lines[i]) + 3 });
        for (let step = 1; step <= 6; step++) {
          const rawNext = lines[i + step] || '';
          if (!rawNext) continue;
          const next = cleanFieldValue(rawNext, 'manufacturer');
          if (!next || isFieldLabelLine(next) || looksNoise(next) || !validFieldValue(next, 'manufacturer')) continue;
          let score = companyCandidateScore(next, rawNext) - step * 0.35;
          // Legal company names are much safer than brand-only lines directly after a label.
          if (/(股份有限公司|有限责任公司|有限公司|股份公司|co\.?\s*,?\s*ltd|ltd\.?|gmbh)/i.test(next)) score += 4;
          candidates.push({ value:next, index:i + step, score });
        }
        candidates.sort((a,b) => b.score - a.score || a.index - b.index);
        if (candidates[0] && candidates[0].score >= 3) return { ...candidates[0], label:String(label) };
      }
    }
    return null;
  }
  function serialCandidateScore(value, line = '', distance = 0, explicitLabel = false) {
    const s = cleanFieldValue(value, 'code');
    const explicitShortNumeric = explicitLabel && /^\d{4,6}$/.test(s);
    if (!s || (!explicitShortNumeric && !validFieldValue(s, 'code'))) return -999;
    if (!/\d/.test(s)) return -999; // 纯字母公司/品牌名不能作为编号候选
    if (/^(?:IPX\d+|CE\d*|20|0123)$/i.test(s)) return -999;
    if (/^\d{1,3}$/.test(s)) return -999;
    if (/^\d{4,6}$/.test(s) && !explicitLabel) return -999;
    if (/^\d{5}-\d{4}$/.test(s)) return -999; // US ZIP code, not a serial number
    if (/^(?:19|20)\d{2}[-/.]\d{1,2}(?:[-/.]\d{1,2})?$/.test(s)) return -999;
    if (/^\d+(?:\.\d+)?s\s*\/\s*\d+(?:\.\d+)?s$/i.test(s)) return -999; // 工作制 10s/30s
    if (/^\d+(?:\.\d+)?(?:hz|v|a|w|va|mah|mmhg|kpa)$/i.test(s.replace(/\s+/g,''))) return -999;
    if (/(注册证|注册号|许可证|批准证书|准号|备案|国械|[苏浙闽粤]械|标准|电话|邮编|地址|住所|road|street|avenue|日期|date|电压|电源|频率|功率|输入功率|工作制|所属类型|型号|MC|PA)/i.test(line)) return -999;
    let score = 0;
    if (explicitLabel) score += 8;
    if (/^[A-Za-z0-9][A-Za-z0-9._+\-/]{3,32}$/.test(s)) score += 6;
    if (/[A-Za-z]/.test(s) && /\d/.test(s)) score += 7;
    if (/[-_/]/.test(s)) score += 4;
    if (/^\d{7,14}$/.test(s)) score += 6;
    if (s.length >= 8 && s.length <= 18) score += 3;
    if (/^(?:SN|S\/N|SERIAL)/i.test(line)) score += 3;
    score -= distance * 0.45;
    return score;
  }
  function serialFrequencyBonus(value, lines) {
    const key = normalizeMatch(value);
    if (!key || key.length < 5) return 0;
    let count = 0;
    for (const line of lines) if (normalizeMatch(line).includes(key)) count++;
    return count >= 2 ? 6 : 0;
  }
  function extractSerialByPriority(lines, labels) {
    let emptyLabelHit = null;
    for (const label of labels) {
      for (let i = 0; i < lines.length; i++) {
        const match = matchLabel(lines[i], label);
        if (!match) continue;
        if (!emptyLabelHit) emptyLabelHit = { value:'', index:i, label:String(label), empty:true };
        const candidates = [];
        const inline = cleanFieldValue(match[1] || '', 'code');
        if (validFieldValue(inline, 'code')) candidates.push({ value:inline, index:i, score:serialCandidateScore(inline, lines[i], 0, true) + 5 + serialFrequencyBonus(inline, lines) });
        // 一些铭牌把编号印在“生产批号（出厂编号）”标签的上一行。
        const prevRaw = lines[i - 1] || '';
        const prev = cleanFieldValue(prevRaw, 'code');
        const prevScore = serialCandidateScore(prev, prevRaw, 1, true) + serialFrequencyBonus(prev, lines);
        if (prevScore > -100) candidates.push({ value:prev, index:i - 1, score:prevScore + 3 });
        for (let step = 1; step <= 7; step++) {
          const rawNext = lines[i + step] || '';
          if (!rawNext) continue;
          const next = cleanFieldValue(rawNext, 'code');
          const score = serialCandidateScore(next, rawNext, step, true) + serialFrequencyBonus(next, lines);
          if (score > -100) candidates.push({ value:next, index:i + step, score });
        }
        candidates.sort((a,b) => b.score - a.score || a.index - b.index);
        if (candidates[0] && candidates[0].score >= 5) return { ...candidates[0], label:String(label) };
      }
    }
    return emptyLabelHit;
  }
  function fallbackSerialCandidate(lines, excluded = new Set()) {
    let best = null;
    for (let i=0; i<lines.length; i++) {
      if (excluded.has(i)) continue;
      const line = cleanLine(lines[i]);
      if (!line || looksNoise(line)) continue;
      const tokens = line.match(/[A-Za-z0-9][A-Za-z0-9._+\-/]{5,32}/g) || [];
      for (const token of tokens) {
        const score = serialCandidateScore(token, line, 0);
        if (score < 8) continue;
        if (!best || score > best.score || (score === best.score && token.length > best.value.length)) best = { value:token, index:i, score };
      }
    }
    return best;
  }
  function findManufacturerLine(lines, keyword) {
    const k = normalizeMatch(keyword);
    const companyRe = /(有限责任公司|有限公司|股份有限公司|股份公司|医疗|医用|科技|仪器|设备|medical|healthcare|co\.?\s*,?\s*ltd|ltd\.?|inc\.?|gmbh|corporation|corp\.?)/i;
    const matches = lines.filter(line => normalizeMatch(line).includes(k) && !looksNoise(line) && !/(?:经销商|代理商)/i.test(line));
    return matches.sort((a,b) => Number(companyRe.test(b)) - Number(companyRe.test(a)) || a.length - b.length)[0] || '';
  }
  function findBestCompanyLine(lines) {
    const companyRe = /(有限责任公司|有限公司|股份有限公司|股份公司|医疗器械|医疗科技|生物科技|medical|bio-medical|healthcare|co\.?\s*,?\s*ltd|ltd\.?|inc\.?|gmbh|corporation|corp\.?)/i;
    let best = null;
    for (let i = 0; i < lines.length; i++) {
      const line = cleanFieldValue(lines[i], 'manufacturer');
      if (!line || !companyRe.test(line) || looksNoise(line) || /(?:经销商|代理商|住所|地址|电话|邮编)/i.test(line)) continue;
      let score = 5;
      if (/(?:生产|制造|注册人)/i.test(lines[i])) score += 3;
      if (/(有限责任公司|有限公司|股份有限公司|gmbh|co\.?\s*,?\s*ltd|ltd\.?)/i.test(line)) score += 2;
      if (!best || score > best.score) best = { value: line.replace(/^(?:注册人[\/、]?|生产企业(?:[\/、]注册人)?|生产厂名称|制造商|生产单位)\s*[：:]?\s*/i, ''), index: i, score };
    }
    return best;
  }
  function bestDeviceName(rawNorm) {
    const names = [...customDeviceNames(), ...BUILTIN_DEVICE_NAMES].filter(Boolean).sort((a,b) => b.length - a.length);
    for (const name of names) if (rawNorm.includes(normalizeMatch(name))) return name;
    return '';
  }
  function applyStandardDeviceName(name, rawNorm, rawText = '') {
    const current = normalizeMatch(name);
    // 规则按“更具体类别优先”排列，例如急救/无创呼吸机先于通用呼吸机。
    for (const rule of STANDARD_DEVICE_RULES) {
      if (normalizeMatch(rule.name) === current) return rule.name;
      for (const alias of rule.aliases) {
        const aliasNorm = normalizeMatch(alias);
        if (!aliasNorm) continue;
        if ((current && current === aliasNorm) || (aliasNorm.length >= 3 && rawNorm.includes(aliasNorm))) return rule.name;
      }
      if ((rule.acronyms || []).some(a => hasStandaloneAcronym(rawText, a))) return rule.name;
    }
    return name;
  }

  function modelConfusableEquivalent(a, b) {
    const x = String(a || '').toUpperCase().replace(/[^A-Z0-9]/g, '');
    const y = String(b || '').toUpperCase().replace(/[^A-Z0-9]/g, '');
    if (!x || !y || x.length !== y.length || x === y) return false;
    const pairs = new Set(['O0','0O','I1','1I','L1','1L','S5','5S','B8','8B','Z2','2Z']);
    let diffs = 0;
    for (let i=0;i<x.length;i++) {
      if (x[i] === y[i]) continue;
      diffs++;
      if (diffs > 2 || !pairs.has(x[i] + y[i])) return false;
    }
    return diffs >= 1 && diffs <= 2;
  }
  function looksLikeModelAsName(value) {
    const s = String(value || '').trim();
    if (!s) return false;
    if (/^[A-Za-z][A-Za-z0-9 ._+\-/]{2,50}$/.test(s) && !/(monitor|ventilator|ultrasound|anesthesia|anaesthesia|defibrillator|pump|centrifuge)/i.test(s)) return true;
    return false;
  }
  function modelCandidateScore(value, originalLine = '', distance = 0, isPrevious = false) {
    const s = cleanFieldValue(value, 'model');
    if (!validFieldValue(s, 'model')) return -999;
    if (/^\d{1,4}$/.test(s)) return -999;
    let score = 0;
    if (/[A-Za-z]/.test(s) && /\d/.test(s)) score += 12;
    else if (/^[A-Za-z][A-Za-z0-9 ._+\-/]{2,40}$/.test(s)) score += 5;
    if (/[-_/]/.test(s)) score += 2;
    if (s.length >= 4 && s.length <= 24) score += 2;
    if (isPrevious) score += 1.5;
    if (/(?:生产|企业|厂家|名称|地址|住所|电话|注册|许可证|标准|日期|电源|频率|功率|序列|编号|SN|IPX|CE)/i.test(originalLine)) score -= 20;
    score -= distance * 0.3;
    return score;
  }
  function extractModelByPriority(lines, labels) {
    for (const label of labels) {
      for (let i=0; i<lines.length; i++) {
        const match = matchLabel(lines[i], label);
        if (!match) continue;
        const candidates = [];
        const inline = cleanFieldValue(match[1] || '', 'model');
        if (validFieldValue(inline, 'model')) candidates.push({value:inline,index:i,score:modelCandidateScore(inline,lines[i],0,false)+5});
        const prevRaw = lines[i-1] || '';
        const prev = cleanFieldValue(prevRaw, 'model');
        const prevScore = modelCandidateScore(prev, prevRaw, 1, true);
        if (prevScore > -100) candidates.push({value:prev,index:i-1,score:prevScore});
        for (let step=1; step<=2; step++) {
          const rawNext = lines[i+step] || '';
          const next = cleanFieldValue(rawNext, 'model');
          const score = modelCandidateScore(next, rawNext, step, false);
          if (score > -100) candidates.push({value:next,index:i+step,score});
        }
        candidates.sort((a,b)=>b.score-a.score || Math.abs(a.index-i)-Math.abs(b.index-i));
        if (candidates[0] && candidates[0].score >= 5) return {...candidates[0], label:String(label)};
      }
    }
    return null;
  }
  function heuristicModel(lines, excluded = new Set()) {
    let best = null;
    const contextRe = /(型号|规格型号|型号规格|model|type|ref\.?|catalog)/i;
    const badRe = /(serial|s\/n|sn\b|序列|编号|电压|电流|频率|功率|日期|date|lot|批号)/i;
    for (let i=0;i<lines.length;i++) {
      const line = cleanLine(lines[i]);
      if (!line || excluded.has(i) || looksNoise(line) || badRe.test(line)) continue;
      const tokens = line.match(/[A-Za-z0-9][A-Za-z0-9._+\-/]{2,35}/g) || [];
      for (const token of tokens) {
        if (!/[A-Za-z]/.test(token) || !/\d/.test(token)) continue;
        if (/^(?:20\d{2}|19\d{2})$/.test(token) || /^\d+(?:\.\d+)?(?:v|a|w|hz)$/i.test(token)) continue;
        let score = 4;
        if (contextRe.test(line)) score += 8;
        if (token.length >= 5 && token.length <= 20) score += 2;
        if (/[-_/]/.test(token)) score += 1;
        if (!best || score > best.score) best = { value: token, score, index:i };
      }
    }
    return best && best.score >= 6 ? best : null;
  }
  function extractInlineModel(raw) {
    const text = String(raw || '');
    const patterns = [
      /(?:型号|model(?:\s+no\.?)?)\s*[：:]\s*([A-Za-z0-9][A-Za-z0-9 ._+\-/]{2,40})/ig,
      /(?:规格型号|型号规格|型号[、及]\s*规格)\s*[：:]\s*([A-Za-z0-9][A-Za-z0-9 ._+\-/]{2,40})/ig
    ];
    for (const re of patterns) {
      for (const m of text.matchAll(re)) {
        const value = cleanFieldValue(m[1], 'model').trim();
        if (validFieldValue(value, 'model')) return value;
      }
    }
    return '';
  }
  function zollMSeriesRule(raw) {
    const text = String(raw || '');
    if (!/zoll/i.test(text) || !/m(?:\s*series|eries)/i.test(text)) return null;
    const codeMatch = text.match(/(?:^|\n)\s*([A-Z][A-Z0-9-]{7,20})\s*(?:\n|$)/m);
    return {
      name: '心脏除颤器',
      manufacturer: 'ZOLL Medical Corporation',
      model: 'M Series',
      code: codeMatch ? codeMatch[1].trim() : ''
    };
  }

  function knownModelDeviceRule(raw) {
    const text = String(raw || '');
    if (/\bLIFEPAK\s*20\b/i.test(text)) {
      return { name:'心脏除颤器', model:'LIFEPAK20', manufacturer:/Physio-Control/i.test(text) ? 'Physio-Control, Inc.' : '' };
    }
    if (/\bLuminos\s+Select\b/i.test(text) && /SIEMENS|西门子/i.test(text)) {
      return { name:'医用诊断X射线辐射源（胃肠机）', model:'Luminos Select', manufacturer:'' };
    }
    if (/\bAZURION\s+7\s+M20\b/i.test(text) && /PHILIPS/i.test(text)) {
      return { name:'医用诊断数字减影血管造影（DSA）系统X射线辐射源', model:'Azurion 7 M20', manufacturer:'' };
    }
    if (/\bBoaray\s*5000D\b/i.test(text) && /prunus|普博/i.test(text)) {
      return { name:'呼吸机', model:'Boaray 5000D', manufacturer:'' };
    }
    if (/NORLAND/i.test(text) && /双能X(?:线|射线)骨密度(?:测量|测定)仪/i.test(text)) {
      return { name:'X射线骨密度仪', model:'', manufacturer:'' };
    }
    return null;
  }

  function medexSerialRule(raw) {
    const text = String(raw || '');
    if (!/MedEx|麦迪克斯|MECG-300/i.test(text)) return '';
    const matches = [...text.matchAll(/(?:^|\n)\s*(C\d{9,14})\s*(?:\n|$)/gim)].map(m => m[1]);
    if (!matches.length) return '';
    const counts = new Map();
    for (const v of matches) counts.set(v, (counts.get(v) || 0) + 1);
    return [...counts.entries()].sort((a,b)=>b[1]-a[1] || b[0].length-a[0].length)[0][0];
  }
  function extractGs1Serial(raw) {
    const matches = [...String(raw || '').matchAll(/\(21\)\s*([A-Za-z0-9][A-Za-z0-9._+\-/]{3,40})/gi)];
    if (!matches.length) return null;
    const value = cleanFieldValue(matches[matches.length - 1][1], 'code');
    if (!value || value.length > 40 || !/[A-Za-z0-9]/.test(value)) return null;
    return { value, index: -1, label: '(21)' };
  }
  function extract(text) {
    const raw = String(text || '').replace(/\r/g, '\n');
    const lines = raw.split('\n').map(cleanLine).filter(Boolean);
    const rawNorm = normalizeMatch(raw);
    const notes = [];
    const used = new Set();

    const nameHit = extractByPriority(lines, ['设备名称','产品名称','仪器名称','商品名称','品名'], 'name', { searchRadius: 2 });
    const makerHit = extractManufacturerByPriority(lines, [
      '受托生产企业名称','受托生产企业','生产企业名称','生产企业/注册人','生产企业、注册人','生产厂名称','注册人/生产企业名称','注册人、生产企业名称',
      '注册人/生产企业/售后服务单位','注册人、生产企业、售后服务单位','注册人/生产企业','注册人、生产企业','生产厂家','制造厂家','制造商','生产单位','制造单位','生产厂商',
      'manufacturer','manufactured by','备案人'
    ]);
    const modelHit = extractModelByPriority(lines, ['规格型号','型号规格','型号、规格','型号及规格','产品型号','设备型号','型号','model no.','model no','model','type','ref']);
    const inlineModel = extractInlineModel(raw);
    let codeHit = extractSerialByPriority(lines, [
      '机身码','器号','无线传输背夹编号、生产日期','无线传输背夹编号','产品序号','生产批号（出厂编号）','生产批号(出厂编号)','生产编号','出厂编号','出厂序列号','产品生产日期或序列号','产品序列号','序列号','设备编号','产品编号',
      'serial number','serial no.','serial no','s/n','sn'
    ]);
    { const gs1 = extractGs1Serial(raw); if (gs1) codeHit = gs1; }

    let name = nameHit?.value || '';
    let manufacturer = makerHit?.value || '';
    let model = inlineModel || modelHit?.value || '';
    let code = codeHit?.value || '';
    [nameHit,makerHit,modelHit,codeHit].filter(Boolean).forEach(hit => { if (hit.index >= 0) used.add(hit.index); });
    if (nameHit || makerHit || modelHit || inlineModel || codeHit?.value) notes.push('铭牌标签');
    if (codeHit?.label === '(21)') notes.push('UDI(21)序列号');

    // 厂家明确文字应优先于历史知识库。若标签未抓到，再从公司名称行中补充。
    if (!manufacturer) {
      const company = findBestCompanyLine(lines);
      if (company) { manufacturer = company.value; used.add(company.index); notes.push('铭牌厂家行'); }
    }

    const zollRule = zollMSeriesRule(raw);
    if (zollRule) {
      name = zollRule.name;
      manufacturer = zollRule.manufacturer;
      model = zollRule.model;
      if (!code && zollRule.code) code = zollRule.code;
      notes.push('ZOLL M Series 专用规则');
    }

    const knownRule = knownModelDeviceRule(raw);
    if (knownRule) {
      if (knownRule.name) name = knownRule.name;
      if (knownRule.model) model = knownRule.model;
      if (knownRule.manufacturer && !manufacturer) manufacturer = knownRule.manufacturer;
      notes.push('已知型号设备映射');
    }
    const medexCode = medexSerialRule(raw);
    if (medexCode) { code = medexCode; notes.push('麦迪克斯编号规则'); }

    // 产品名称标签有时实际放的是系列/型号（如 Fabius Tiro）。若铭牌另有明确设备类别，优先设备类别。
    const dictionaryName = bestDeviceName(rawNorm);
    if (!name && dictionaryName) { name = dictionaryName; notes.push('设备名称词库'); }
    else if (name && dictionaryName && looksLikeModelAsName(name) && normalizeMatch(name) !== normalizeMatch(dictionaryName)) {
      name = dictionaryName;
      notes.push('设备名称纠偏');
    }
    const standardizedName = applyStandardDeviceName(name, rawNorm, raw);
    if (standardizedName && standardizedName !== name) { name = standardizedName; notes.push('33类标准设备名称映射'); }

    // 已验证型号字符混淆：高频电刀 POWER-420FX 常被 OCR 读成 POWER-42OFX。
    if (normalizeMatch(name) === normalizeMatch('高频电刀') && /^POWER[- ]?42OFX$/i.test(model)) {
      model = 'POWER-420FX';
      notes.push('型号O/0纠错');
    }

    // 共享知识库只补缺，不覆盖铭牌明确厂家/型号。名称仅在非常可靠时用于标准化。
    const shared = scoreSharedKnowledge(rawNorm, { model, manufacturer, name });
    if (shared) {
      if (!name && shared.item.name) name = shared.item.name;
      if (!manufacturer && shared.item.manufacturer) manufacturer = shared.item.manufacturer;
      if (!model && shared.item.model && rawNorm.includes(shared.item._modelNorm || normalizeMatch(shared.item.model))) model = shared.item.model;
      else if (model && shared.item.model && shared.modelHit && normalizeMatch(model) === normalizeMatch(shared.item.model) && model !== shared.item.model) { model = shared.item.model; notes.push('共享库型号标准化'); }
      else if (model && shared.item.model && shared.makerHit && shared.nameHit && ['高','中高'].includes(shared.item.confidence) && Number(shared.item.count || 0) >= 3 && modelConfusableEquivalent(model, shared.item.model)) {
        model = shared.item.model;
        notes.push('共享库型号字符纠错');
      }
      const sharedStandardName = STANDARD_DEVICE_NAMES.has(shared.item.name) ? shared.item.name : applyStandardDeviceName(shared.item.name || '', normalizeMatch(shared.item.name || ''), shared.item.name || '');
      const targetIsApprovedStandard = STANDARD_DEVICE_NAMES.has(sharedStandardName);
      const strongNameMap = shared.modelHit && shared.makerHit && ['高','中高'].includes(shared.item.confidence) && Number(shared.item.count || 0) >= 3;
      if (strongNameMap && targetIsApprovedStandard && sharedStandardName && normalizeMatch(sharedStandardName) !== normalizeMatch(name)) {
        name = sharedStandardName;
        notes.push('共享库33类标准名称映射');
      }
      notes.push(`共享知识库匹配(${shared.item.confidence || '历史'} / ${Number(shared.item.count || 0)}条)`);
    }

    const history = scoreHistory(rawNorm);
    if (history) {
      if (!name && history.item.name) name = history.item.name;
      if (!manufacturer && history.item.manufacturer) manufacturer = history.item.manufacturer;
      if (!model && history.item.model && normalizeMatch(raw).includes(normalizeMatch(history.item.model))) model = history.item.model;
      notes.push(`本机历史匹配(${history.score})`);
    }

    if (!manufacturer) {
      const aliases = [...customManufacturerAliases(), ...BUILTIN_MANUFACTURER_ALIASES];
      for (const [keyword, canonical] of aliases) {
        if (!keyword || !rawNorm.includes(normalizeMatch(keyword))) continue;
        const line = findManufacturerLine(lines, keyword);
        manufacturer = line ? cleanFieldValue(line, 'manufacturer') : canonical;
        if (customManufacturerAliases().some(([k]) => k === keyword) && canonical) manufacturer = canonical;
        notes.push('厂家词库');
        break;
      }
    }

    if (!name) {
      name = bestDeviceName(rawNorm);
      if (name) notes.push('设备名称词库');
    }

    if (!model) {
      const candidate = heuristicModel(lines, used);
      if (candidate) { model = candidate.value; notes.push('型号格式'); used.add(candidate.index); }
    }

    if (!code && !codeHit?.empty) {
      const serialFallback = fallbackSerialCandidate(lines, used);
      if (serialFallback) { code = serialFallback.value; notes.push('编号格式候选'); used.add(serialFallback.index); }
    }

    const confidenceParts = [name, manufacturer, model, code].filter(Boolean).length;
    return {
      name, manufacturer, model, code,
      classifyNote: notes.length ? `智能分类：${[...new Set(notes)].join(' + ')}；自动填出 ${confidenceParts}/4 个核心字段` : `智能分类：未找到可靠规则；请人工填写核心字段`,
      classifyCount: confidenceParts
    };
  }
  function newRecord() {
    return {
      id: crypto.randomUUID ? crypto.randomUUID() : Date.now() + '-' + Math.random().toString(36).slice(2),
      createdAt: Date.now(), unitName: $('unitName').value.trim(), dept: $('dept').value.trim(), date: $('workdate').value || '',
      operatorName: $('operatorName').value.trim(), remark: '', syncStatus: 'local-only', syncError: '', remoteRecordId: '',
      raw: '', name: '', manufacturer: '', model: '', code: '', classifyNote: '', status: 'pending', error: '已保存，准备识别……', thumb: null, sourceEngine: ''
    };
  }
  function applyTextResult(record, text, sourceEngine) {
    const raw = String(text || '').trim();
    if (!raw) throw new Error('OCR 完成但没有识别到文字。请换一个角度、靠近铭牌拍摄，或裁剪铭牌区域后重试。');
    record.raw = raw;
    const fields = extract(raw);
    record.name = fields.name;
    record.manufacturer = fields.manufacturer;
    record.model = fields.model;
    record.code = fields.code;
    record.classifyNote = fields.classifyNote || '';
    record.error = '';
    record.sourceEngine = sourceEngine;
    record.status = 'pending';
    if (record.feishuRecordId || record.remoteRecordId) record.syncStatus = 'pending';
  }

  class OcrSpaceError extends Error {
    constructor(message, { quota = false, requestFailure = false, emptyResult = false } = {}) {
      super(message);
      this.name = 'OcrSpaceError';
      this.quota = quota;
      this.requestFailure = requestFailure;
      this.emptyResult = emptyResult;
    }
  }
  function looksLikeQuota(message, httpStatus = 0) {
    if (httpStatus === 429) return true;
    return /quota|rate.?limit|too many requests|maximum number of requests|requests per day|daily limit|monthly limit|you have reached|exceeded.{0,30}limit|limit.{0,30}exceeded|500 requests|maximum request/i.test(String(message || ''));
  }
  function friendlyApiErrors(data) {
    const bits = [];
    if (data?.ErrorMessage) bits.push(Array.isArray(data.ErrorMessage) ? data.ErrorMessage.join('; ') : String(data.ErrorMessage));
    if (data?.ErrorDetails) bits.push(Array.isArray(data.ErrorDetails) ? data.ErrorDetails.join('; ') : String(data.ErrorDetails));
    for (const item of data?.ParsedResults || []) {
      if (item?.ErrorMessage) bits.push(String(item.ErrorMessage));
      if (item?.ErrorDetails) bits.push(String(item.ErrorDetails));
    }
    return [...new Set(bits.filter(Boolean))].join('；');
  }
  async function runOcrSpace(file, displayName) {
    const apiKey = $('ocrApiKey').value.trim() || localStorageGet('mingpai-ocrspace-key');
    if (!apiKey) throw new OcrSpaceError('尚未配置 OCR.space API Key。请在上方粘贴 Key 并点击“保存设置”，或选择 Paddle 本地模式。', { requestFailure: true });
    status(`正在压缩照片，准备上传 OCR.space：${displayName}\n免费 API 单张文件限制 1 MB。`);
    const uploadBlob = await prepareImage(file, 'cloud');
    if (uploadBlob.size > CLOUD_MAX_BYTES) throw new OcrSpaceError(`照片压缩后仍超过 1 MB（${(uploadBlob.size / 1024 / 1024).toFixed(2)} MB）。请裁剪铭牌区域后重新上传。`, { requestFailure: false });
    const form = new FormData();
    // OCR.space documents apikey in a multipart form body for its JavaScript example.
    form.append('apikey', apiKey);
    form.append('file', uploadBlob, safeJpegName(displayName));
    form.append('language', 'auto');
    form.append('OCREngine', $('ocrEngine').value || '2');
    form.append('isOverlayRequired', 'false');
    form.append('detectOrientation', 'true');
    form.append('scale', 'true');
    const controller = new AbortController();
    const timer = setTimeout(() => controller.abort(), CLOUD_TIMEOUT_MS);
    let response, data;
    try {
      status(`OCR.space 正在识别：${displayName}\n已上传压缩后的照片，请保持网页在前台。`);
      response = await fetch(OCR_SPACE_ENDPOINT, { method: 'POST', body: form, signal: controller.signal });
      const bodyText = await response.text();
      try { data = JSON.parse(bodyText); }
      catch { throw new OcrSpaceError(`OCR.space 返回了非 JSON 内容（HTTP ${response.status}）。可能是服务暂时不可用。`, { requestFailure: true, quota: looksLikeQuota(bodyText, response.status) }); }
    } catch (error) {
      if (error instanceof OcrSpaceError) throw error;
      const msg = error?.name === 'AbortError' ? `OCR.space 请求超过 ${Math.round(CLOUD_TIMEOUT_MS / 1000)} 秒，已停止等待。` : `OCR.space 网络请求失败：${error?.message || String(error)}。可能是网络、CORS 或服务暂时不可用。`;
      throw new OcrSpaceError(msg, { requestFailure: true, quota: looksLikeQuota(msg, response?.status || 0) });
    } finally {
      clearTimeout(timer);
    }
    const message = friendlyApiErrors(data) || `OCR.space 返回 HTTP ${response.status} / OCRExitCode ${data?.OCRExitCode ?? '未知'}`;
    if (!response.ok || data?.IsErroredOnProcessing) {
      throw new OcrSpaceError(message, {
        requestFailure: !response.ok || Boolean(data?.IsErroredOnProcessing) || /api.?key|invalid key|unauthori[sz]ed|authentication|not authorized|access denied/i.test(message),
        quota: looksLikeQuota(message, response.status)
      });
    }
    const parsedResults = Array.isArray(data?.ParsedResults) ? data.ParsedResults : [];
    const text = parsedResults
      .filter(result => result?.ParsedText && (result.FileParseExitCode == null || Number(result.FileParseExitCode) === 1 || Number(result.FileParseExitCode) === 2))
      .map(result => String(result.ParsedText).trim())
      .filter(Boolean)
      .join('\n');
    if (!text) {
      const noTextMessage = message || 'OCR.space 没有识别到文字。';
      throw new OcrSpaceError(noTextMessage, {
        quota: looksLikeQuota(noTextMessage, response.status),
        requestFailure: !response.ok || /api.?key|invalid key|unauthori[sz]ed|authentication|not authorized|access denied/i.test(noTextMessage),
        emptyResult: true
      });
    }
    return text;
  }
  function safeJpegName(name) {
    const base = String(name || 'mingpai').replace(/\.[^.]+$/, '').replace(/[^\w\u4e00-\u9fff-]+/g, '_').slice(0, 60) || 'mingpai';
    return base + '.jpg';
  }

  async function getPaddleOcr() {
    if (paddleOcr) return paddleOcr;
    if (paddleFailure) {
      // A previous inference/init failure must not poison later photos. Start a clean attempt.
      paddleFailure = '';
      paddlePromise = null;
    }
    if (paddlePromise) return paddlePromise;

    status('正在使用已验证过的 PaddleOCR 默认模型配置初始化本地备用引擎。首次需要联网下载模型，请保持网页在前台……');
    const createPromise = (async () => {
      const errors = [];
      // IMPORTANT: Match the standalone PaddleOCR page that was confirmed to work.
      // Do not pass custom model asset URLs, custom WASM paths, or worker:true here.
      // Those overrides were introduced in the dual-engine build and correlated with
      // the 180-second initialization hang. Let the pinned SDK resolve its own model
      // assets and ORT runtime using backend:auto, exactly as in the working build.
      for (const ocrVersion of ['PP-OCRv6', 'PP-OCRv5']) {
        try {
          status(`正在初始化 ${ocrVersion} 本地备用模型（使用 PaddleOCR.js 默认模型和运行时路径）……`);
          const instance = await PaddleOCR.create({
            lang: 'ch',
            ocrVersion,
            worker: false,
            ortOptions: { backend: 'auto' }
          });
          paddleOcr = instance;
          paddleOcrVersion = ocrVersion;
          status(`${ocrVersion} 本地备用模型加载完成。`);
          return instance;
        } catch (error) {
          const message = error?.message || String(error);
          errors.push(`${ocrVersion}: ${message}`);
          status(`${ocrVersion} 初始化失败，正在按已验证配置尝试兼容模型……`);
        }
      }
      throw new Error('PaddleOCR 模型初始化失败。' + errors.join('；'));
    })();

    let timeoutHandle;
    const timeoutPromise = new Promise((_, reject) => {
      timeoutHandle = setTimeout(() => reject(new Error(
        `PaddleOCR 默认模型初始化超过 ${Math.round(PADDLE_INIT_TIMEOUT_MS / 1000)} 秒。此版本不再使用自定义模型 TAR 地址或自定义 WASM 路径；请检查手机能否访问 PaddleOCR SDK 默认模型资源，并查看网络是否中断。`
      )), PADDLE_INIT_TIMEOUT_MS);
    });
    paddlePromise = Promise.race([createPromise, timeoutPromise]);
    try {
      return await paddlePromise;
    } catch (error) {
      paddleFailure = error?.message || String(error);
      paddlePromise = null;
      throw error;
    } finally {
      clearTimeout(timeoutHandle);
    }
  }
  async function runPaddle(file, displayName) {
    status(`准备 PaddleOCR 本地识别：${displayName}……`);
    const inputBlob = await prepareImage(file, 'local');
    const ocr = await getPaddleOcr();
    status(`PaddleOCR.js + ${paddleOcrVersion || 'PP-OCRv6'} 正在本地识别：${displayName}\n图片不会上传给 OCR.space。`);
    let result;
    try {
      result = await withTimeout(ocr.predict(inputBlob), PADDLE_IMAGE_TIMEOUT_MS, `PaddleOCR 单张识别超过 ${Math.round(PADDLE_IMAGE_TIMEOUT_MS / 1000)} 秒。建议裁剪铭牌区域，或检查手机性能。`);
    } catch (error) {
      const message = error?.message || String(error);
      // Any failed predict may leave ONNX/Paddle internal state unusable on mobile.
      // Dispose it immediately so the NEXT photo can recreate a fresh instance without reloading the page.
      try { await paddleOcr?.dispose?.(); } catch {}
      paddleOcr = null;
      paddlePromise = null;
      paddleFailure = '';
      paddleOcrVersion = '';
      throw new Error(message + '；Paddle 本地模型状态已自动重置，下一次识别会重新初始化，无需刷新网页。');
    }
    const first = Array.isArray(result) ? result[0] : result;
    const text = Array.isArray(first?.items) ? first.items.map(item => String(item?.text || '').trim()).filter(Boolean).join('\n') : '';
    if (!text.trim()) throw new Error('PaddleOCR 完成但没有识别到文字，请调整照片角度或裁剪铭牌区域后重试。');
    return text.trim();
  }
  function withTimeout(promise, milliseconds, message) {
    let timer;
    return Promise.race([promise, new Promise((_, reject) => { timer = setTimeout(() => reject(new Error(message)), milliseconds); })])
      .finally(() => clearTimeout(timer));
  }

  async function loadImageSource(file) {
    if ('createImageBitmap' in window) {
      try {
        const bitmap = await createImageBitmap(file);
        return { source: bitmap, width: bitmap.width, height: bitmap.height, close: () => bitmap.close() };
      } catch {}
    }
    return new Promise((resolve, reject) => {
      const url = URL.createObjectURL(file);
      const image = new Image();
      image.onload = () => {
        URL.revokeObjectURL(url);
        resolve({ source: image, width: image.naturalWidth, height: image.naturalHeight, close: () => {} });
      };
      image.onerror = () => { URL.revokeObjectURL(url); reject(new Error('无法读取图片。请换一张 JPG/PNG 照片。')); };
      image.src = url;
    });
  }
  function canvasBlob(canvas, quality) {
    return new Promise((resolve, reject) => canvas.toBlob(blob => blob ? resolve(blob) : reject(new Error('图片转换失败。')), 'image/jpeg', quality));
  }
  async function prepareImage(file, purpose) {
    const decoded = await loadImageSource(file);
    try {
      const width = decoded.width, height = decoded.height;
      if (!width || !height) throw new Error('图片尺寸无效。');
      let maxSide = purpose === 'cloud' ? 2400 : 2800;
      let quality = purpose === 'cloud' ? 0.9 : 0.92;
      let blob;
      for (let attempt = 0; attempt < (purpose === 'cloud' ? 8 : 1); attempt++) {
        let scale = Math.min(1, maxSide / Math.max(width, height));
        if (purpose === 'local' && Math.max(width, height) < 1400) scale = Math.min(1.35, 1400 / Math.max(width, height));
        const canvas = document.createElement('canvas');
        canvas.width = Math.max(1, Math.round(width * scale));
        canvas.height = Math.max(1, Math.round(height * scale));
        const context = canvas.getContext('2d');
        if (!context) throw new Error('此浏览器无法处理图片。');
        context.fillStyle = '#fff';
        context.fillRect(0, 0, canvas.width, canvas.height);
        context.imageSmoothingEnabled = true;
        context.imageSmoothingQuality = 'high';
        context.drawImage(decoded.source, 0, 0, canvas.width, canvas.height);
        blob = await canvasBlob(canvas, quality);
        if (purpose !== 'cloud' || blob.size <= CLOUD_MAX_BYTES) return blob;
        maxSide = Math.floor(maxSide * 0.88);
        quality = Math.max(0.72, quality - 0.035);
      }
      if (purpose === 'cloud' && blob?.size > CLOUD_MAX_BYTES) throw new Error('照片压缩后仍超过 OCR.space 的 1 MB 限制。请先裁剪铭牌区域后再上传。');
      return blob;
    } finally {
      decoded.close();
    }
  }
  function makeThumb(file) {
    return new Promise(resolve => {
      const image = new Image();
      const url = URL.createObjectURL(file);
      image.onload = () => {
        const max = 960;
        const scale = Math.min(1, max / Math.max(image.naturalWidth, image.naturalHeight));
        const canvas = document.createElement('canvas');
        canvas.width = Math.max(1, Math.round(image.naturalWidth * scale));
        canvas.height = Math.max(1, Math.round(image.naturalHeight * scale));
        const context = canvas.getContext('2d');
        context.fillStyle = '#fff'; context.fillRect(0, 0, canvas.width, canvas.height);
        context.drawImage(image, 0, 0, canvas.width, canvas.height);
        URL.revokeObjectURL(url);
        canvas.toBlob(blob => resolve(blob), 'image/jpeg', 0.72);
      };
      image.onerror = () => { URL.revokeObjectURL(url); resolve(null); };
      image.src = url;
    });
  }

  function openCropper(file) {
    return new Promise(resolve => {
      const modal = $('cropModal');
      const canvas = $('cropCanvas');
      const ctx = canvas.getContext('2d');
      const img = new Image();
      const url = URL.createObjectURL(file);
      let rect = null;
      let dragging = false;
      let start = null;
      let scaleX = 1, scaleY = 1;
      const cleanup = () => {
        URL.revokeObjectURL(url);
        modal.hidden = true;
        canvas.onpointerdown = canvas.onpointermove = canvas.onpointerup = canvas.onpointercancel = null;
      };
      const draw = () => {
        if (!img.naturalWidth) return;
        ctx.clearRect(0,0,canvas.width,canvas.height);
        ctx.drawImage(img,0,0,canvas.width,canvas.height);
        if (rect && rect.w > 3 && rect.h > 3) {
          ctx.save();
          ctx.fillStyle='rgba(0,0,0,.35)';
          ctx.fillRect(0,0,canvas.width,canvas.height);
          ctx.clearRect(rect.x,rect.y,rect.w,rect.h);
          ctx.drawImage(img, rect.x*scaleX, rect.y*scaleY, rect.w*scaleX, rect.h*scaleY, rect.x, rect.y, rect.w, rect.h);
          ctx.strokeStyle='#1769e0'; ctx.lineWidth=3; ctx.strokeRect(rect.x,rect.y,rect.w,rect.h);
          ctx.restore();
        }
      };
      const pos = e => {
        const b=canvas.getBoundingClientRect();
        return {x:Math.max(0,Math.min(canvas.width,e.clientX-b.left)),y:Math.max(0,Math.min(canvas.height,e.clientY-b.top))};
      };
      img.onload=()=>{
        const maxW=Math.min(window.innerWidth-36,900), maxH=Math.min(window.innerHeight*0.58,700);
        const k=Math.min(1,maxW/img.naturalWidth,maxH/img.naturalHeight);
        canvas.width=Math.max(1,Math.round(img.naturalWidth*k)); canvas.height=Math.max(1,Math.round(img.naturalHeight*k));
        scaleX=img.naturalWidth/canvas.width; scaleY=img.naturalHeight/canvas.height;
        rect=null; draw(); modal.hidden=false;
        canvas.onpointerdown=e=>{dragging=true; start=pos(e); rect={x:start.x,y:start.y,w:0,h:0}; canvas.setPointerCapture?.(e.pointerId); draw();};
        canvas.onpointermove=e=>{if(!dragging)return; const q=pos(e); rect={x:Math.min(start.x,q.x),y:Math.min(start.y,q.y),w:Math.abs(q.x-start.x),h:Math.abs(q.y-start.y)}; draw();};
        canvas.onpointerup=canvas.onpointercancel=e=>{dragging=false; draw();};
      };
      img.onerror=()=>{cleanup(); alert('无法打开照片进行裁剪，将使用原图。'); resolve(file);};
      $('cropUseOriginal').onclick=()=>{cleanup(); resolve(file);};
      $('cropCancel').onclick=()=>{cleanup(); resolve(null);};
      $('cropApply').onclick=async()=>{
        if(!rect || rect.w<20 || rect.h<20){alert('请在图片上拖动框选铭牌区域，或点击“直接识别原图”。');return;}
        const sx=Math.round(rect.x*scaleX), sy=Math.round(rect.y*scaleY), sw=Math.round(rect.w*scaleX), sh=Math.round(rect.h*scaleY);
        const out=document.createElement('canvas'); out.width=sw; out.height=sh;
        const octx=out.getContext('2d'); octx.fillStyle='#fff'; octx.fillRect(0,0,sw,sh); octx.drawImage(img,sx,sy,sw,sh,0,0,sw,sh);
        const blob=await canvasBlob(out,0.95);
        const name=(file.name||'camera.jpg').replace(/\.[^.]+$/,'')+'_crop.jpg';
        const cropped=new File([blob],name,{type:'image/jpeg',lastModified:Date.now()});
        cleanup(); resolve(cropped);
      };
      img.src=url;
    });
  }

  function setBusy(value) {
    busy = value;
    $('cameraBtn').disabled = value;
    $('galleryBtn').disabled = value;
    $('preloadPaddleBtn').disabled = value;
    $('saveOcrConfigBtn').disabled = value;
    $('ocrMode').disabled = value;
    $('ocrEngine').disabled = value;
    $('ocrApiKey').disabled = value;
  }
  async function recognizeFile(file, record, label, engineOverride = null) {
    activeImageName = label || file.name || '手机照片';
    const selectedMode = engineOverride || $('ocrMode').value;
    let cloudError = '';
    try {
      if (selectedMode === 'paddle') {
        const text = await runPaddle(file, activeImageName);
        applyTextResult(record, text, `PaddleOCR.js + ${paddleOcrVersion || 'PP-OCRv6'} 本地`);
        await txPut(record);
        return true;
      }
      if (selectedMode === 'space') {
        const text = await runOcrSpace(file, activeImageName);
        applyTextResult(record, text, `OCR.space Engine ${$('ocrEngine').value}`);
        await txPut(record);
        return true;
      }

      // Automatic mode: prefer OCR.space unless the cloud quota has already been detected.
      const apiKey = $('ocrApiKey').value.trim() || localStorageGet('mingpai-ocrspace-key');
      if (cloudQuotaReachedThisSession || $('ocrMode').value === 'paddle') {
        const text = await runPaddle(file, activeImageName);
        applyTextResult(record, text, `PaddleOCR.js + ${paddleOcrVersion || 'PP-OCRv6'} 本地（云端限额后切换）`);
        await txPut(record);
        return true;
      }
      if (!apiKey) {
        cloudError = '未配置 OCR.space API Key';
      } else {
        try {
          const text = await runOcrSpace(file, activeImageName);
          applyTextResult(record, text, `OCR.space Engine ${$('ocrEngine').value}`);
          await txPut(record);
          return true;
        } catch (error) {
          if (!(error instanceof OcrSpaceError)) throw error;
          cloudError = error.message;
          if (error.quota) {
            cloudQuotaReachedThisSession = true;
            updateMode('paddle', true);
            status(`检测到 OCR.space 的额度/限流错误：${cloudError}\n已自动把后续识别切换为 PaddleOCR.js + PP-OCRv6 本地备用模式，避免继续请求已受限的云端接口。正在处理当前照片……`);
          } else if (error.requestFailure) {
            // A network/HTTP problem is unlikely to be unique to one photo. Switch this session to local OCR
            // so a large batch will not repeatedly fail against the same cloud endpoint.
            updateMode('paddle', true);
            status(`OCR.space 请求失败：${cloudError}\n已切换到 PaddleOCR 本地备用模式，正在尝试识别当前照片……`);
          } else {
            status(`OCR.space 未识别到可用文字：${cloudError}\n正在尝试 PaddleOCR 本地备用模型……`);
          }
        }
      }
      if (!apiKey) status(`${cloudError}。自动模式将直接尝试 PaddleOCR 本地备用模型……`);
      try {
        const text = await runPaddle(file, activeImageName);
        applyTextResult(record, text, `PaddleOCR.js + ${paddleOcrVersion || 'PP-OCRv6'} 本地备用${cloudError ? '（云端未成功）' : ''}`);
        record.error = cloudError ? `云端未成功，已由本地备用识别。原因：${cloudError}` : '';
        await txPut(record);
        return true;
      } catch (localError) {
        throw new Error(`${cloudError ? `OCR.space 失败：${cloudError}\n` : ''}PaddleOCR 备用也未成功：${localError?.message || String(localError)}`);
      }
    } catch (error) {
      record.error = error?.message || String(error);
      record.status = 'pending';
      record.sourceEngine = selectedMode === 'paddle' ? 'PaddleOCR 本地（失败）' : '识别失败';
      await txPut(record);
      return false;
    }
  }
  async function handleFiles(fileList) {
    if (busy) { status('当前任务仍在处理，请等当前批次结束。'); return; }
    const files = Array.from(fileList || []).filter(file => file.type.startsWith('image/'));
    if (!files.length) return;
    if (!db) { status('本地记录正在初始化，请稍后重试。'); return; }
    setBusy(true);
    let failed = 0;
    try {
      for (let index = 0; index < files.length; index++) {
        const file = files[index];
        const record = newRecord();
        record.error = '已保存，准备识别……';
        await txPut(record);
        records.unshift(record);
        page = 0;
        status(`已保存待处理记录 ${index + 1}/${files.length}：${file.name || '手机照片'}\n开始生成照片预览。`);
        record.thumb = await makeThumb(file);
        await txPut(record);
        render();
        const success = await recognizeFile(file, record, `${index + 1}/${files.length} · ${file.name || '手机照片'}`);
        if (!success) failed++;
        await txPut(record);
        await refresh();
      }
      status(`本批完成：共 ${files.length} 张，已保存 ${files.length} 条记录；${failed} 张识别失败。失败记录仍在待审核列表，可选择“OCR.space 重识别”或“Paddle 重识别”再次尝试。`);
    } catch (error) {
      status('处理遇到问题：' + (error?.message || String(error)) + '\n已完成记录逐张保存，请在列表里检查。');
    } finally {
      activeImageName = '';
      setBusy(false);
      $('cameraInput').value = '';
      $('galleryInput').value = '';
    }
  }
  async function resetPaddleForManualRetry() {
    try { await paddleOcr?.dispose?.(); } catch {}
    paddleOcr = null;
    paddlePromise = null;
    paddleFailure = '';
    paddleOcrVersion = '';
  }
  async function retryRecognition(record, file, engineOverride = null) {
    if (busy) return;
    if (engineOverride === 'paddle' || paddleFailure) {
      await resetPaddleForManualRetry();
      if (engineOverride === 'paddle') status('正在重新初始化 PaddleOCR，本次会重新尝试加载模型……');
    }
    setBusy(true);
    record.error = '正在重新识别……';
    await txPut(record);
    await refresh();
    try {
      const success = await recognizeFile(file, record, file.name || '重新上传的照片', engineOverride);
      record.thumb = await makeThumb(file);
      await txPut(record);
      await refresh();
      status(success ? '重新识别完成，请核对字段后确认。' : '重新识别失败，请查看该条记录的错误原因。');
    } finally {
      activeImageName = '';
      setBusy(false);
      $('retryInput').value = '';
      retryRecordId = null;
      retryEngineOverride = null;
    }
  }

  $('saveOcrConfigBtn').addEventListener('click', () => saveSettings(true));
  $('operatorName').addEventListener('change', () => {
    localStorageSet('mingpai-operator-name', $('operatorName').value.trim());
    status('已保存当前浏览器的检定员姓名；新记录将自动带入该姓名。');
  });
  $('unitName').addEventListener('change', () => {
    localStorageSet('mingpai-unit-name', $('unitName').value.trim());
    status('已保存单位名称；后续新记录会自动带入。');
  });
  $('dept').addEventListener('change', () => {
    localStorageSet('mingpai-dept', $('dept').value.trim());
    status('已保存当前科室；后续新记录会自动继承。');
  });
  $('workdate').addEventListener('change', () => {
    localStorageSet('mingpai-workdate', $('workdate').value);
    status('已保存检定日期；后续新记录会自动带入。');
  });
  $('saveSyncConfigBtn').addEventListener('click', () => {
    const key = $('syncSharedKey').value.trim();
    localStorageSet('mingpai-feishu-sync-key', key);
    // 清理旧版本保存的网址，避免以后误用。SCF 地址已固定在程序中。
    try {
      localStorage.removeItem('mingpai-feishu-sync-url');
      localStorage.removeItem('mingpai-tencent-sync-url');
    } catch {}
    status(key ? '共享访问密钥已保存在当前浏览器。正在加载共享知识库……' : '尚未填写共享访问密钥。');
    if (key) loadSharedKnowledge(false, false);
  });
  $('setupTencentBtn').addEventListener('click', setupFeishuSync);
  $('refreshKnowledgeBtn')?.addEventListener('click', () => loadSharedKnowledge(true, false));
  $('syncAllBtn').addEventListener('click', async () => {
    const pendingSync = confirmedRecords().filter(record => record.syncStatus !== 'synced');
    if (!pendingSync.length) { status('没有需要同步的已确认记录。'); return; }
    if (!confirm(`即将依次同步 ${pendingSync.length} 条已确认记录到飞书多维表格，继续吗？`)) return;
    let success = 0, failed = 0;
    for (const record of pendingSync) {
      const ok = await syncRecordToFeishu(record, { silent: true });
      if (ok) success++; else failed++;
    }
    status(`批量同步完成：成功 ${success} 条，失败 ${failed} 条。失败记录会保留在本地，可逐条重试。`);
  });
  $('clearKeyBtn').addEventListener('click', () => {
    $('ocrApiKey').value = '';
    try { localStorage.removeItem('mingpai-ocrspace-key'); } catch {}
    status('已清除当前浏览器保存的 OCR.space API Key。若使用自动模式，将直接尝试本地 PaddleOCR。');
  });
  $('ocrMode').addEventListener('change', () => {
    localStorageSet('mingpai-ocr-mode', $('ocrMode').value);
    const mode = $('ocrMode').value;
    status(mode === 'auto' ? '已切换为自动模式：下一张照片优先 OCR.space，若云端限额/请求失败将切换到本地 PaddleOCR。' : mode === 'space' ? '已切换为仅 OCR.space 模式；云端失败时不会自动调用 Paddle。' : '已切换为仅 PaddleOCR.js 本地模式。首次需要联网下载 SDK 默认模型。');
  });
  $('ocrEngine').addEventListener('change', () => localStorageSet('mingpai-ocrspace-engine', $('ocrEngine').value));
  $('preloadPaddleBtn').addEventListener('click', async () => {
    if (busy) return;
    setBusy(true);
    try {
      await getPaddleOcr();
      status(`${paddleOcrVersion || 'PaddleOCR'} 备用模型已经初始化成功。本次打开网页期间可直接用于本地识别；请再上传一张测试照片验证推理。`);
    } catch (error) {
      status(`PaddleOCR 备用模型未能初始化：${error?.message || String(error)}\n可能是手机内存、模型下载地址或网络限制。刷新网页可清除本次错误状态后再试。`);
    } finally {
      setBusy(false);
    }
  });

  $('saveClassifierConfigBtn')?.addEventListener('click', () => {
    localStorageSet('mingpai-classifier-device-names', $('customDeviceNames')?.value || '');
    localStorageSet('mingpai-classifier-manufacturers', $('customManufacturers')?.value || '');
    status('字段分类词库已保存在当前浏览器。以后识别会自动使用；已确认的本机历史设备也会继续参与匹配。');
  });

  $('cameraBtn').addEventListener('click', () => $('cameraInput').click());
  $('galleryBtn').addEventListener('click', () => $('galleryInput').click());
  $('pasteQuickBtn')?.addEventListener('click', () => { const panel = $('quickPastePanel'); panel.hidden = !panel.hidden; if (!panel.hidden) $('pasteOcrText').focus(); });
  $('closePasteBtn')?.addEventListener('click', () => { $('quickPastePanel').hidden = true; });
  $('cameraInput').addEventListener('change', async event => {
    const file = event.target.files && event.target.files[0];
    if (!file) return;
    const chosen = await openCropper(file);
    $('cameraInput').value = '';
    if (chosen) await handleFiles([chosen]);
  });
  $('galleryInput').addEventListener('change', event => handleFiles(event.target.files));
  $('retryInput').addEventListener('change', async event => {
    const file = event.target.files && event.target.files[0];
    const record = records.find(item => item.id === retryRecordId);
    if (file && record) await retryRecognition(record, file, retryEngineOverride);
  });

  $('pasteOcrBtn').addEventListener('click', async () => {
    const raw = $('pasteOcrText').value.trim();
    if (!raw) { alert('请先粘贴 OCR 文字。'); return; }
    if (!db) { alert('本地记录正在初始化，请稍后重试。'); return; }
    const record = newRecord();
    applyTextResult(record, raw, '手动粘贴的 OCR 文字');
    record.thumb = null;
    await txPut(record);
    await refresh();
    $('pasteOcrText').value = '';
    status('已加入 1 条待审核记录。请检查字段，修正后点击“确认这条记录”。');
  });
  $('clearPasteBtn').addEventListener('click', () => $('pasteOcrText').value = '');
  $('clonePreviousBtn')?.addEventListener('click', async () => {
    if (!db) { alert('本地记录正在初始化，请稍后重试。'); return; }
    const previous = records[0];
    if (!previous) { alert('当前还没有上一条记录可复制。'); return; }
    const record = newRecord();
    for (const key of ['unitName','dept','date','operatorName','raw','name','manufacturer','model','code','remark']) record[key] = previous[key] || '';
    record.thumb = null;
    record.status = 'pending';
    record.syncStatus = 'local-only';
    record.syncError = '';
    record.remoteRecordId = '';
    record.feishuRecordId = '';
    record.classifyNote = '由上一条记录复制；请修改本条差异后再确认。';
    record.error = '';
    record.sourceEngine = '复制上一条记录';
    await txPut(record);
    await refresh();
    page = 0; render();
    status('已按上一条记录生成 1 条新的待审核记录，请修改设备差异后确认。');
  });


  $('recordList').addEventListener('change', async event => {
    const element = event.target;
    if (element.matches('input[data-select-id]')) {
      if (element.checked) selectedIds.add(element.dataset.selectId); else selectedIds.delete(element.dataset.selectId);
      if ($('selectedCount')) $('selectedCount').textContent = `已选：${selectedIds.size}`;
      return;
    }
    if (!element.dataset.id || !element.dataset.field) return;
    const record = records.find(item => item.id === element.dataset.id);
    if (!record) return;
    record[element.dataset.field] = element.value;
    if (element.dataset.field === 'operatorName') {
      record.operatorName = element.value.trim();
      $('operatorName').value = record.operatorName;
      localStorageSet('mingpai-operator-name', record.operatorName);
    }
    if (element.dataset.field === 'dept') {
      record.dept = element.value.trim();
      $('dept').value = record.dept;
      localStorageSet('mingpai-dept', record.dept);
    }
    if (element.dataset.field === 'unitName') {
      record.unitName = element.value.trim();
      $('unitName').value = record.unitName;
      localStorageSet('mingpai-unit-name', record.unitName);
    }
    if (element.dataset.field === 'date') {
      $('workdate').value = element.value;
      localStorageSet('mingpai-workdate', element.value);
    }
    if (['unitName', 'name', 'manufacturer', 'model', 'code', 'raw', 'dept', 'date', 'operatorName', 'remark'].includes(element.dataset.field) && record.status === 'confirmed') {
      record.status = 'pending';
      if (record.feishuRecordId || record.remoteRecordId) record.syncStatus = 'pending';
    }
    await txPut(record);
    await refresh();
  });
  $('recordList').addEventListener('click', async event => {
    const photo = event.target.closest('img[data-open-image]');
    if (photo) {
      const record = records.find(item => item.id === photo.dataset.openImage);
      if (record?.thumb) {
        const url = URL.createObjectURL(record.thumb);
        const opened = window.open(url, '_blank');
        if (!opened) alert('浏览器阻止了新窗口，请允许打开照片预览。');
        setTimeout(() => URL.revokeObjectURL(url), 60000);
      }
      return;
    }
    const button = event.target.closest('button[data-action]');
    if (!button) return;
    if (busy) { status('当前识别任务尚未完成，请稍候。'); return; }
    const record = records.find(item => item.id === button.dataset.id);
    if (!record) return;
    if (button.dataset.action === 'retry-space' || button.dataset.action === 'retry-paddle') {
      retryRecordId = record.id;
      retryEngineOverride = button.dataset.action === 'retry-paddle' ? 'paddle' : 'space';
      $('retryInput').value = '';
      $('retryInput').click();
      return;
    }
    if (button.dataset.action === 'toggle') {
      if (record.status === 'confirmed') {
        record.status = 'pending';
        if (record.feishuRecordId || record.remoteRecordId) record.syncStatus = 'pending';
        await txPut(record); await refresh();
        status('已取消本机的确认状态。注意：已写入飞书的云端记录不会因此自动删除。');
        return;
      }
      const operator = String(record.operatorName || $('operatorName').value || '').trim();
      if (!operator) { alert('请先在页面顶部填写检定员姓名。'); $('operatorName').focus(); return; }
      const unitName = String(record.unitName || $('unitName').value || '').trim();
      if (!unitName) { alert('请先填写单位名称。'); $('unitName').focus(); return; }
      record.operatorName = operator;
      record.unitName = unitName;
      record.status = 'confirmed';
      if (record.feishuRecordId || record.remoteRecordId) record.syncStatus = 'pending';
      await txPut(record); await refresh();
      await syncRecordToFeishu(record);
      return;
    } else if (button.dataset.action === 'sync') {
      await syncRecordToFeishu(record);
      return;
    } else if (button.dataset.action === 'delete') {
      if (!confirm('确定删除这条本地记录吗？')) return;
      await txDelete(record.id);
    } else if (button.dataset.action === 'reparse') {
      const fields = extract(record.raw);
      record.name = fields.name;
      record.manufacturer = fields.manufacturer;
      record.model = fields.model;
      record.code = fields.code;
      record.classifyNote = fields.classifyNote || '';
      record.status = 'pending';
      await txPut(record);
    }
    await refresh();
  });

  $('statusFilter').addEventListener('change', () => { page = 0; render(); });
  $('searchBox').addEventListener('input', () => { page = 0; render(); });
  const goPrev = () => { page = Math.max(0, page - 1); render(); window.scrollTo({ top: $('recordList').offsetTop - 130, behavior: 'smooth' }); };
  const goNext = () => { page++; render(); window.scrollTo({ top: $('recordList').offsetTop - 130, behavior: 'smooth' }); };
  $('prevBtn').addEventListener('click', goPrev);
  $('nextBtn').addEventListener('click', goNext);
  $('prevBtnTop')?.addEventListener('click', goPrev);
  $('nextBtnTop')?.addEventListener('click', goNext);

  function confirmedRecords() { return records.filter(record => record.status === 'confirmed').sort((a, b) => a.createdAt - b.createdAt); }
  const columnOrder = ['unitName', 'dept', 'date', 'operatorName', 'raw', 'name', 'manufacturer', 'model', 'code', 'remark'];
  function tsvValue(value) { return String(value ?? '').replace(/\r?\n/g, ' ').replace(/\t/g, ' '); }
  $('copyBtn').addEventListener('click', async () => {
    const rows = confirmedRecords();
    if (!rows.length) { alert('没有已确认的记录。请先审核并确认记录。'); return; }
    const text = rows.map(record => columnOrder.map(key => tsvValue(record[key])).join('\t')).join('\n');
    try {
      await navigator.clipboard.writeText(text);
      alert(`已复制 ${rows.length} 条已确认记录。列顺序与飞书多维表格一致。`);
    } catch {
      const opened = window.open('', '_blank');
      if (opened) {
        opened.document.write('<textarea style="width:98%;height:90vh;font-size:14px"></textarea>');
        opened.document.querySelector('textarea').value = text;
        opened.document.title = '复制已确认数据';
      }
      alert('浏览器未允许自动复制，已尝试打开可手动全选复制的页面。');
    }
  });
  function downloadCsvRows(rows, filename) {
    if (!rows.length) { alert('没有符合条件的已确认记录。'); return; }
    const headers = ['单位名称', '科室', '检定日期', '检定员', '铭牌文本', '设备名称', '生产厂家', '型号', '出厂编号', '备注'];
    const csv = '\ufeff' + [headers, ...rows.map(record => columnOrder.map(key => record[key] || ''))].map(row => row.map(csvEscape).join(',')).join('\r\n');
    download(new Blob([csv], { type: 'text/csv;charset=utf-8' }), filename);
  }
  function downloadAllConfirmedCsv() {
    downloadCsvRows(confirmedRecords(), '设备铭牌已确认数据_全部.csv');
  }
  function downloadTodayConfirmedCsv() {
    const date = $('workdate').value || defaultToday;
    const rows = confirmedRecords().filter(r => r.date === date);
    downloadCsvRows(rows, `设备铭牌已确认数据_${date}.csv`);
  }
  $('csvTopBtn')?.addEventListener('click', downloadAllConfirmedCsv);
  $('selectPageBtn')?.addEventListener('click', () => {
    const list = getFiltered();
    const subset = list.slice(page * PAGE_SIZE, (page + 1) * PAGE_SIZE);
    subset.forEach(r => selectedIds.add(r.id));
    if ($('selectedCount')) $('selectedCount').textContent = `已选：${selectedIds.size}`;
    render();
  });
  $('clearSelectionBtn')?.addEventListener('click', () => { selectedIds.clear(); if ($('selectedCount')) $('selectedCount').textContent = '已选：0'; render(); });
  $('deleteSelectedBtn')?.addEventListener('click', async () => {
    const ids = [...selectedIds].filter(id => records.some(r => r.id === id));
    if (!ids.length) { alert('请先勾选要删除的本地记录。'); return; }
    const unsynced = ids.map(id => records.find(r => r.id === id)).filter(r => r && r.status === 'confirmed' && r.syncStatus !== 'synced').length;
    const warning = unsynced ? `
其中 ${unsynced} 条尚未成功同步飞书，请谨慎。` : '';
    if (!confirm(`确定从当前浏览器批量删除 ${ids.length} 条记录吗？${warning}
此操作不会删除飞书中的云端记录。`)) return;
    for (const id of ids) await txDelete(id);
    selectedIds.clear(); if ($('selectedCount')) $('selectedCount').textContent = '已选：0';
    await refresh();
    status(`已从本机删除 ${ids.length} 条记录；飞书云端记录未删除。`);
  });
  $('deleteSyncedBtn')?.addEventListener('click', async () => {
    const targets = records.filter(r => r.status === 'confirmed' && r.syncStatus === 'synced');
    const protectedCount = records.length - targets.length;
    if (!targets.length) { alert('当前没有“已确认且已同步”的本地记录可清理。'); return; }
    if (!confirm(`将从当前浏览器删除 ${targets.length} 条“已确认且已同步”记录。
${protectedCount ? `另有 ${protectedCount} 条待审核/待同步记录会保留。
` : ''}飞书中的云端数据不会删除。继续吗？`)) return;
    for (const r of targets) await txDelete(r.id);
    selectedIds.clear(); await refresh();
    status(`已清理 ${targets.length} 条已确认且已同步的本地记录；飞书云端数据保留。`);
  });

  $('jsonBtn').addEventListener('click', () => {
    const backup = { app: 'mingpai-dual-ocr-feishu-v2', exportedAt: new Date().toISOString(), note: '字段备份不含原始照片缩略图；照片缩略图只保存在当前手机浏览器。', records: records.map(({ thumb, ...record }) => record) };
    download(new Blob([JSON.stringify(backup, null, 2)], { type: 'application/json;charset=utf-8' }), '设备铭牌字段备份.json');
  });
  $('restoreBtn').addEventListener('click', () => $('restoreInput').click());
  $('restoreInput').addEventListener('change', async event => {
    const file = event.target.files && event.target.files[0];
    if (!file) return;
    try {
      const backup = JSON.parse(await file.text());
      if (!Array.isArray(backup.records)) throw new Error('备份文件格式不正确');
      if (!confirm(`备份中有 ${backup.records.length} 条记录。选择“确定”后会合并到本地，重复 ID 会覆盖。继续吗？`)) return;
      for (const record of backup.records) {
        if (!record.id) record.id = 'restore-' + Date.now() + '-' + Math.random().toString(36).slice(2);
        normalizeRecord(record);
        await txPut({ ...record, thumb: null });
      }
      await refresh();
      alert('恢复完成。');
    } catch (error) {
      alert('恢复失败：' + (error?.message || String(error)));
    } finally {
      $('restoreInput').value = '';
    }
  });
  function download(blob, filename) {
    const url = URL.createObjectURL(blob);
    const anchor = document.createElement('a');
    anchor.href = url;
    anchor.download = filename;
    document.body.appendChild(anchor);
    anchor.click();
    anchor.remove();
    setTimeout(() => URL.revokeObjectURL(url), 1500);
  }

  async function retryUnsyncedAfterOnline() {
    if (autoRetryRunning || !navigator.onLine) return;
    const pendingSync = records.filter(r => r.status === 'confirmed' && r.syncStatus !== 'synced');
    if (!pendingSync.length) return;
    autoRetryRunning = true;
    try {
      status(`网络已恢复，正在自动补传 ${pendingSync.length} 条待同步记录……`);
      for (const record of pendingSync) await syncRecordToFeishu(record, { silent: true });
      await refresh();
      status('网络已恢复，待同步记录自动补传完成。');
    } finally { autoRetryRunning = false; }
  }
  window.addEventListener('online', () => { render(); setTimeout(retryUnsyncedAfterOnline, 800); });
  window.addEventListener('offline', () => { render(); status('当前网络已断开。拍照、审核和本机保存仍可继续；恢复网络后会自动尝试补传飞书。'); });

  openDB().then(async database => {
    db = database;
    await refresh();
    const cached = await loadCachedKnowledge();
    // 有近 6 小时缓存时立即工作，不重复下载大知识库；过期则后台更新。
    const cacheFresh = cached?.savedAt && (Date.now() - Number(cached.savedAt) < KNOWLEDGE_CACHE_MAX_AGE_MS);
    if (!cacheFresh) loadSharedKnowledge(false, true);
    const mode = $('ocrMode').value;
    status(mode === 'paddle'
      ? '已就绪：PaddleOCR PP-OCRv6 本地识别 + 智能字段分类。'
      : mode === 'space'
        ? '已就绪：OCR.space 云端识别 + 智能字段分类。'
        : '已就绪：双引擎自动识别 + 智能字段分类。拍照后请核对核心字段。');
  }).catch(error => status('本地数据库初始化失败：' + (error?.message || String(error)) + '。请换用最新版 Chrome/Safari，并确保网站使用 HTTPS。'));
})();
