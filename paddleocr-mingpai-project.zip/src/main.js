import { createWorker } from 'tesseract.js';

(() => {
 'use strict';
 const DB_NAME='mingpai-free-v1', STORE='records', PAGE_SIZE=10;
 const BASE = import.meta.env.BASE_URL;
 let db, records=[], page=0, worker=null, workerPromise=null, busy=false, objectUrls=[], activeImageName='', initError='';
 let retryRecordId = null;
 const $ = id => document.getElementById(id);
 const today = new Date();
 $('workdate').value = `${today.getFullYear()}-${String(today.getMonth()+1).padStart(2,'0')}-${String(today.getDate()).padStart(2,'0')}`;
 function status(msg){ $('progress').textContent=msg; }
 function openDB(){return new Promise((resolve,reject)=>{const req=indexedDB.open(DB_NAME,1);req.onupgradeneeded=()=>{const d=req.result;if(!d.objectStoreNames.contains(STORE))d.createObjectStore(STORE,{keyPath:'id'});};req.onsuccess=()=>resolve(req.result);req.onerror=()=>reject(req.error);});}
 function txPut(rec){return new Promise((resolve,reject)=>{const t=db.transaction(STORE,'readwrite');t.objectStore(STORE).put(rec);t.oncomplete=()=>resolve();t.onerror=()=>reject(t.error);});}
 function txDelete(id){return new Promise((resolve,reject)=>{const t=db.transaction(STORE,'readwrite');t.objectStore(STORE).delete(id);t.oncomplete=()=>resolve();t.onerror=()=>reject(t.error);});}
 function txAll(){return new Promise((resolve,reject)=>{const r=db.transaction(STORE,'readonly').objectStore(STORE).getAll();r.onsuccess=()=>resolve(r.result||[]);r.onerror=()=>reject(r.error);});}
 async function refresh(){records=(await txAll()).sort((a,b)=>b.createdAt-a.createdAt);render();}
 function esc(s){return String(s??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));}
 function short(s,n=44){s=String(s||'');return s.length>n?s.slice(0,n)+'…':s;}
 function csvEscape(v){return '"'+String(v??'').replace(/"/g,'""')+'"';}
 function getFiltered(){const f=$('statusFilter').value, q=$('searchBox').value.trim().toLowerCase();return records.filter(r=>(f==='all'||(f==='pending'?r.status!=='confirmed':r.status==='confirmed'))&&(!q||[r.name,r.manufacturer,r.model,r.code,r.raw,r.dept].join(' ').toLowerCase().includes(q)));}
 function render(){objectUrls.forEach(u=>URL.revokeObjectURL(u));objectUrls=[];const all=records.length,pending=records.filter(r=>r.status!=='confirmed').length,ok=all-pending;$('countAll').textContent='总记录：'+all;$('countPending').textContent='待审核：'+pending;$('countOk').textContent='已确认：'+ok;const list=getFiltered();const pages=Math.max(1,Math.ceil(list.length/PAGE_SIZE));page=Math.min(page,pages-1);const subset=list.slice(page*PAGE_SIZE,(page+1)*PAGE_SIZE);$('pageText').textContent=`第 ${list.length? page+1:0} / ${list.length?pages:0} 页（筛选后 ${list.length} 条）`;$('recordList').innerHTML='';if(!subset.length){$('recordList').innerHTML='<p class="hint">当前没有记录。先拍照或从相册选择铭牌照片。</p>';return;}
 subset.forEach(rec=>{const card=document.createElement('article');card.className='card';const img=rec.thumb?URL.createObjectURL(rec.thumb):'';if(img)objectUrls.push(img);card.innerHTML=`<div class="cardhead">${img?`<img class="thumb" data-open-image="${rec.id}" alt="点击查看铭牌照片" title="点击查看照片" src="${img}">`:'<div class="thumb" style="display:grid;place-items:center;font-size:11px;color:#78849a">无照片</div>'}<div class="cardtitle"><strong>${esc(rec.name||'未识别设备名称')}</strong><small>${esc(rec.batch||'未设置批次')} · ${esc(rec.createdAt?new Date(rec.createdAt).toLocaleString(): '')}</small></div><span class="badge ${rec.status==='confirmed'?'ok':''}">${rec.status==='confirmed'?'已确认':'待审核'}</span></div>
 ${rec.error?`<div class="errornote">${esc(rec.error)}</div>`:''}
 <div class="grid">
 ${makeField(rec,'dept','科室','text')}${makeField(rec,'date','日期','date')}
 ${makeField(rec,'name','设备名称','text')}${makeField(rec,'manufacturer','生产厂家','text')}
 ${makeField(rec,'model','型号','text')}${makeField(rec,'code','编号（出厂编号/SN）','text')}
 <div class="full"><label>铭牌文本（可修正 OCR 原文）</label><textarea data-id="${rec.id}" data-field="raw">${esc(rec.raw||'')}</textarea></div>
 </div><div class="controls"><button class="btn ${rec.status==='confirmed'?'light':'secondary'}" data-action="toggle" data-id="${rec.id}">${rec.status==='confirmed'?'取消确认':'确认这条记录'}</button><button class="btn light" data-action="reparse" data-id="${rec.id}">从原文重新提取字段</button><button class="btn light" data-action="retry" data-id="${rec.id}">重新识别（选择照片）</button><button class="btn danger" data-action="delete" data-id="${rec.id}">删除</button></div>`; $('recordList').appendChild(card);});
 $('prevBtn').disabled=page<=0;$('nextBtn').disabled=page>=pages-1;}
 function makeField(rec,field,label,type){return `<div><label>${label}</label><input type="${type}" data-id="${rec.id}" data-field="${field}" value="${esc(rec[field]||'')}"></div>`;}
 function valueOf(rec,field){return rec[field]||'';}
 function extract(text){const lines=String(text||'').replace(/\r/g,'\n').split('\n').map(x=>x.trim().replace(/[|｜]/g,'I')).filter(Boolean);function find(labels){for(let i=0;i<lines.length;i++){let line=lines[i];for(const lab of labels){const re=new RegExp('(?:^|[\\s：:]|^)'+lab.replace(/[.*+?^${}()|[\]\\]/g,'\\$&')+'\\s*[：:]?\\s*(.*)$','i');const m=line.match(re);if(m){let val=(m[1]||'').trim().replace(/^[：:：\-—\s]+/,'').trim();if(val && !labels.some(x=>new RegExp('^'+x+'$','i').test(val)))return val.slice(0,120);if(i+1<lines.length && lines[i+1].length<100 && !/^(额定|电压|功率|地址|电话|网址)/.test(lines[i+1]))return lines[i+1].slice(0,120);}}}return '';}
 // Prioritize explicit serial labels before generic number labels.
 const name=find(['设备名称','产品名称','仪器名称','名称']);
 const manufacturer=find(['生产厂家','制造厂家','制造商','生产企业','制造单位','生产单位','生产厂商']);
 const model=find(['规格型号','产品型号','设备型号','型号','规格']);
 const code=find(['出厂编号','出厂序列号','序列号','序列 编号','设备编号','S\\/?N','Serial\\s*No\\.?','SN','编号']);
 return {name,manufacturer,model,code};}
 const OCR_INIT_TIMEOUT_MS = 180000;
 const OCR_IMAGE_TIMEOUT_MS = 90000;
 function withTimeout(promise, ms, message) {
   let timer;
   return Promise.race([
     promise,
     new Promise((_, reject) => { timer = setTimeout(() => reject(new Error(message)), ms); })
   ]).finally(() => clearTimeout(timer));
 }
 function localizeOcrStatus(m) {
   if (!m || !m.status) return;
   const pct = typeof m.progress === 'number' ? ` ${Math.round(m.progress * 100)}%` : '';
   const labels = {
     'loading tesseract core':'加载本地 OCR 运行时',
     'initializing tesseract':'初始化 OCR 引擎',
     'loading language traineddata':'加载中英文模型',
     'initializing api':'初始化识别接口',
     'recognizing text':'识别铭牌文字'
   };
   const label = labels[m.status] || m.status;
   const prefix = activeImageName ? `当前照片：${activeImageName}\n` : '';
   status(`${prefix}${label}${pct}\n首次加载可能需要一些时间；模型将缓存到此浏览器。`);
 }
 async function getWorker() {
   if (worker) return worker;
   if (workerPromise) return workerPromise;
   if (initError) throw new Error(initError);
   status('准备本地 OCR：从本站加载 Worker、运行时和中英文模型。首次需联网，请保持页面在前台。');
   let timedOut = false;
   let timeoutId;
   const creation = createWorker('chi_sim+eng', 1, {
     workerPath: `${BASE}tesseract/worker.min.js`,
     corePath: `${BASE}tesseract/core`,
     langPath: `${BASE}tessdata`,
     cachePath: 'mingpai-tessdata-v7-local',
     cacheMethod: 'write',
     gzip: true,
     workerBlobURL: false,
     logger: localizeOcrStatus,
     errorHandler: err => { console.error('Tesseract worker error:', err); }
   }).then(async w => {
     if (timedOut) { try { await w.terminate(); } catch {} throw new Error('OCR 初始化超过 180 秒，请检查网络后重试。'); }
     worker = w;
     return w;
   });
   const timeout = new Promise((_, reject) => {
     timeoutId = setTimeout(() => { timedOut = true; reject(new Error('OCR 初始化超过 180 秒。请确认网络可访问本网页的模型文件，然后刷新重试。')); }, OCR_INIT_TIMEOUT_MS);
   });
   workerPromise = Promise.race([creation, timeout]);
   try {
     return await workerPromise;
   } catch (e) {
     workerPromise = null;
     worker = null;
     initError = e && e.message ? e.message : String(e);
     throw e;
   } finally {
     clearTimeout(timeoutId);
   }
 }
 async function resetWorker() {
   const old = worker;
   worker = null; workerPromise = null; initError = '';
   if (old) { try { await old.terminate(); } catch {} }
 }
 function loadImage(file) {
   return new Promise((resolve, reject) => {
     const url = URL.createObjectURL(file);
     const img = new Image();
     img.onload = () => { URL.revokeObjectURL(url); resolve(img); };
     img.onerror = () => { URL.revokeObjectURL(url); reject(new Error('图片无法打开，请换一张照片。')); };
     img.src = url;
   });
 }
 async function prepareForOcr(file) {
   let bitmap = null, img = null;
   try { if ('createImageBitmap' in window) bitmap = await createImageBitmap(file); } catch {}
   if (!bitmap) img = await loadImage(file);
   const source = bitmap || img;
   const w = bitmap ? bitmap.width : img.naturalWidth;
   const h = bitmap ? bitmap.height : img.naturalHeight;
   if (!w || !h) { if (bitmap) bitmap.close(); throw new Error('图片尺寸读取失败。'); }
   const longest = Math.max(w, h);
   let scale = 1;
   if (longest > 3200) scale = 3200 / longest;
   else if (longest < 1400) scale = Math.min(1.5, 1400 / longest);
   const canvas = document.createElement('canvas');
   canvas.width = Math.max(1, Math.round(w * scale));
   canvas.height = Math.max(1, Math.round(h * scale));
   const ctx = canvas.getContext('2d', { willReadFrequently: false });
   if (!ctx) { if (bitmap) bitmap.close(); throw new Error('当前浏览器无法处理图片。'); }
   ctx.fillStyle = '#fff'; ctx.fillRect(0, 0, canvas.width, canvas.height);
   ctx.imageSmoothingEnabled = true; ctx.imageSmoothingQuality = 'high';
   ctx.drawImage(source, 0, 0, canvas.width, canvas.height);
   if (bitmap) bitmap.close();
   return await new Promise((resolve, reject) => canvas.toBlob(blob => blob ? resolve(blob) : reject(new Error('图片预处理失败。')), 'image/jpeg', 0.92));
 }
 function makeThumb(file) { return new Promise(resolve => { const img=new Image(); const url=URL.createObjectURL(file); img.onload=()=>{const max=960,scale=Math.min(1,max/Math.max(img.naturalWidth,img.naturalHeight));const c=document.createElement('canvas');c.width=Math.max(1,Math.round(img.naturalWidth*scale));c.height=Math.max(1,Math.round(img.naturalHeight*scale));const ctx=c.getContext('2d');ctx.fillStyle='#fff';ctx.fillRect(0,0,c.width,c.height);ctx.drawImage(img,0,0,c.width,c.height);URL.revokeObjectURL(url);c.toBlob(b=>resolve(b),'image/jpeg',0.72);};img.onerror=()=>{URL.revokeObjectURL(url);resolve(null);};img.src=url;}); }
 async function recognizeFile(file, rec, label) {
   activeImageName = label || file.name || '手机照片';
   try {
     status(`正在预处理照片：${activeImageName}……`);
     const input = await prepareForOcr(file);
     const w = await getWorker();
     status(`正在识别：${activeImageName}\n请保持网页在前台。`);
     const result = await withTimeout(w.recognize(input), OCR_IMAGE_TIMEOUT_MS, '单张识别超过 90 秒，已停止等待。可缩小铭牌区域后重新上传。');
     const text = String(result?.data?.text || '').trim();
     rec.raw = text;
     const fields = extract(text);
     rec.name = fields.name; rec.manufacturer = fields.manufacturer; rec.model = fields.model; rec.code = fields.code;
     rec.error = text ? '' : '识别完成但没有提取到文字。建议裁剪铭牌区域、保证文字清晰后点击重新识别。';
     rec.status = 'pending';
     await txPut(rec);
     return Boolean(text);
   } catch (e) {
     const message = e && e.message ? e.message : String(e);
     rec.error = message;
     rec.status = 'pending';
     // A recognizer timeout/runtime failure may leave the worker unusable. Reset so Retry creates a fresh one.
     if (/超过 90 秒|worker|wasm|memory|memory access/i.test(message)) await resetWorker();
     await txPut(rec);
     return false;
   }
 }
 async function handleFiles(fileList) {
   if (busy) { status('当前任务仍在处理，请等当前批次结束。'); return; }
   const files = Array.from(fileList || []).filter(f => f.type.startsWith('image/'));
   if (!files.length) return;
   if (!db) { status('本地数据库正在初始化，请稍后重试。'); return; }
   busy = true; $('cameraBtn').disabled = $('galleryBtn').disabled = true;
   let done = 0, failed = 0;
   try {
     for (const file of files) {
       done++;
       const rec = {
         id: (crypto.randomUUID ? crypto.randomUUID() : Date.now()+'-'+Math.random().toString(36).slice(2)),
         createdAt: Date.now(), dept: $('dept').value.trim(), date: $('workdate').value || '', batch: $('batch').value.trim(),
         raw: '', name: '', manufacturer: '', model: '', code: '', status: 'pending', error: '已保存，准备识别……', thumb: null
       };
       // Save a pending record before the OCR work, so a slow/failing recognition does not lose the entry.
       await txPut(rec); records.unshift(rec); page = 0;
       status(`已保存待处理记录 ${done}/${files.length}：${file.name || '手机照片'}\n正在生成预览并加载 OCR。`);
       rec.thumb = await makeThumb(file);
       await txPut(rec); render();
       const okay = await recognizeFile(file, rec, `${done}/${files.length} · ${file.name || '手机照片'}`);
       if (!okay) failed++;
       await txPut(rec); await refresh();
     }
     status(`本批完成：共 ${files.length} 张，已保存 ${files.length} 条记录；${failed} 张识别失败或未识别到文字。失败记录仍在待审核列表，可点击“重新识别（选择照片）”。`);
   } catch (e) {
     status('处理遇到问题：' + (e && e.message ? e.message : String(e)) + '\n已完成记录已逐张保存，请在列表里检查。');
   } finally {
     activeImageName = ''; busy = false; $('cameraBtn').disabled = $('galleryBtn').disabled = false; $('cameraInput').value = ''; $('galleryInput').value = '';
   }
 }
 async function retryRecognition(rec, file) {
   if (busy) return;
   if (initError) await resetWorker();
   busy = true; $('cameraBtn').disabled = $('galleryBtn').disabled = true;
   rec.error = '正在重新识别……'; await txPut(rec); await refresh();
   try {
     const okay = await recognizeFile(file, rec, file.name || '重新上传的照片');
     rec.thumb = await makeThumb(file); await txPut(rec); await refresh();
     status(okay ? '重新识别完成，请审核字段后确认记录。' : '重新识别仍未成功。请查看该记录的错误原因。');
   } finally {
     activeImageName = ''; busy = false; $('cameraBtn').disabled = $('galleryBtn').disabled = false; $('retryInput').value = ''; retryRecordId = null;
   }
 }
 $('cameraBtn').addEventListener('click',()=>$('cameraInput').click());$('galleryBtn').addEventListener('click',()=>$('galleryInput').click());$('cameraInput').addEventListener('change',e=>handleFiles(e.target.files));$('galleryInput').addEventListener('change',e=>handleFiles(e.target.files));
 $('retryInput').addEventListener('change',async e=>{const file=e.target.files&&e.target.files[0];const rec=records.find(r=>r.id===retryRecordId);if(file&&rec)await retryRecognition(rec,file);});
 $('pasteOcrBtn').addEventListener('click',async()=>{
   const raw=$('pasteOcrText').value.trim();
   if(!raw){alert('请先粘贴手机相册或微信提取的文字。');return;}
   if(!db){alert('本地记录正在初始化，请稍后重试。');return;}
   const fields=extract(raw);
   const rec={id:(crypto.randomUUID?crypto.randomUUID():Date.now()+'-'+Math.random().toString(36).slice(2)),createdAt:Date.now(),dept:$('dept').value.trim(),date:$('workdate').value||'',batch:$('batch').value.trim(),raw,name:fields.name,manufacturer:fields.manufacturer,model:fields.model,code:fields.code,status:'pending',thumb:null};
   await txPut(rec);records.push(rec);records.sort((a,b)=>b.createdAt-a.createdAt);page=0;render();$('pasteOcrText').value='';status('已加入 1 条待审核记录。请检查各字段，修正后点击“确认这条记录”。');
 });
 $('clearPasteBtn').addEventListener('click',()=>$('pasteOcrText').value='');
 $('recordList').addEventListener('change',async e=>{const el=e.target;if(!el.dataset.id||!el.dataset.field)return;const rec=records.find(r=>r.id===el.dataset.id);if(!rec)return;rec[el.dataset.field]=el.value;if(['name','manufacturer','model','code','raw'].includes(el.dataset.field)&&rec.status==='confirmed')rec.status='pending';await txPut(rec);await refresh();});
 $('recordList').addEventListener('click',async e=>{const photo=e.target.closest('img[data-open-image]');if(photo){const r=records.find(x=>x.id===photo.dataset.openImage);if(r&&r.thumb){const u=URL.createObjectURL(r.thumb);const w=window.open(u,'_blank');if(!w)alert('浏览器阻止了新窗口，请允许打开照片预览。');setTimeout(()=>URL.revokeObjectURL(u),60000);}return;}const b=e.target.closest('button[data-action]');if(!b)return;if(busy){status('当前识别任务尚未完成，请稍候。');return;}const rec=records.find(r=>r.id===b.dataset.id);if(!rec)return;if(b.dataset.action==='retry'){retryRecordId=rec.id;$('retryInput').value='';$('retryInput').click();return;}if(b.dataset.action==='toggle'){rec.status=rec.status==='confirmed'?'pending':'confirmed';await txPut(rec);}else if(b.dataset.action==='delete'){if(!confirm('确定删除这条本地记录吗？'))return;await txDelete(rec.id);}else if(b.dataset.action==='reparse'){const f=extract(rec.raw);rec.name=f.name;rec.manufacturer=f.manufacturer;rec.model=f.model;rec.code=f.code;rec.status='pending';await txPut(rec);}await refresh();});
 $('statusFilter').addEventListener('change',()=>{page=0;render();});$('searchBox').addEventListener('input',()=>{page=0;render();});$('prevBtn').addEventListener('click',()=>{page=Math.max(0,page-1);render();});$('nextBtn').addEventListener('click',()=>{page++;render();});
 function confirmed(){return records.filter(r=>r.status==='confirmed').sort((a,b)=>a.createdAt-b.createdAt);}
 const colOrder=['dept','date','raw','name','manufacturer','model','code'];
 function tsvQuote(v){return String(v??'').replace(/\r?\n/g,' ' ).replace(/\t/g,' ');}
 $('copyBtn').addEventListener('click',async()=>{const rows=confirmed();if(!rows.length){alert('没有已确认的记录。请先审核并确认记录。');return;}const text=rows.map(r=>colOrder.map(k=>tsvQuote(r[k])).join('\t')).join('\n');try{await navigator.clipboard.writeText(text);alert(`已复制 ${rows.length} 条已确认记录。打开腾讯文档智能表格，在第一条空白行的“科室”单元格点一下并粘贴。请先用 2～3 条测试确认各列对齐。`);}catch(e){const win=window.open('','_blank');win.document.write('<textarea style="width:98%;height:90vh;font-size:14px"></textarea>');win.document.querySelector('textarea').value=text;win.document.title='复制已确认数据';alert('浏览器未允许自动复制，已尝试打开可手动全选复制的页面。');}});
 $('csvBtn').addEventListener('click',()=>{const rows=confirmed();if(!rows.length){alert('没有已确认的记录。');return;}const headers=['科室','日期','铭牌文本','设备名称','生产厂家','型号','编号'];const csv='\ufeff'+[headers,...rows.map(r=>colOrder.map(k=>r[k]||''))].map(row=>row.map(csvEscape).join(',')).join('\r\n');download(new Blob([csv],{type:'text/csv;charset=utf-8'}),'设备铭牌已确认数据.csv');});
 $('jsonBtn').addEventListener('click',()=>{const backup={app:'mingpai-free-v1',exportedAt:new Date().toISOString(),note:'字段备份不含原始照片缩略图；照片缩略图只保存在原手机浏览器。',records:records.map(({thumb,...r})=>r)};download(new Blob([JSON.stringify(backup,null,2)],{type:'application/json;charset=utf-8'}),'设备铭牌字段备份.json');});
 $('restoreBtn').addEventListener('click',()=>$('restoreInput').click());$('restoreInput').addEventListener('change',async e=>{const f=e.target.files&&e.target.files[0];if(!f)return;try{const obj=JSON.parse(await f.text());if(!Array.isArray(obj.records))throw new Error('备份文件格式不正确');if(!confirm(`备份中有 ${obj.records.length} 条记录。选择“确定”后会合并到本地，重复 ID 会覆盖。继续吗？`))return;for(const r of obj.records){if(!r.id)r.id='restore-'+Date.now()+'-'+Math.random().toString(36).slice(2);await txPut({...r,thumb:null});}await refresh();alert('恢复完成。');}catch(err){alert('恢复失败：'+err.message);}finally{$('restoreInput').value='';}});
 function download(blob,name){const url=URL.createObjectURL(blob);const a=document.createElement('a');a.href=url;a.download=name;document.body.appendChild(a);a.click();a.remove();setTimeout(()=>URL.revokeObjectURL(url),1500);}
 openDB().then(async d=>{db=d;await refresh();}).catch(e=>status('本地数据库初始化失败：'+e.message+'。请换用最新版 Chrome/Safari，并确保网站使用 HTTPS。'));
})();
