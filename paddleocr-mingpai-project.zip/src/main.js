'use strict';

const DB_NAME='mingpai-free-v1', STORE='records', PAGE_SIZE=10;
 let db, records=[], page=0, worker=null, busy=false, objectUrls=[];
 const $ = id => document.getElementById(id);
 const today = new Date();
 $('workdate').value = `${today.getFullYear()}-${String(today.getMonth()+1).padStart(2,'0')}-${String(today.getDate()).padStart(2,'0')}`;
 function status(msg){ $('progress').textContent=msg; }
 function openDB(){return new Promise((resolve,reject)=>{const req=indexedDB.open(DB_NAME,1);req.onupgradeneeded=()=>{const d=req.result;if(!d.objectStoreNames.contains(STORE))d.createObjectStore(STORE,{keyPath:'id'});};req.onsuccess=()=>resolve(req.result);req.onerror=()=>reject(req.error);});}
 function txPut(rec){return new Promise((resolve,reject)=>{const t=db.transaction(STORE,'readwrite');t.objectStore(STORE).put(rec);t.oncomplete=()=>resolve();t.onerror=()=>reject(t.error);});}
 function txDelete(id){return new Promise((resolve,reject)=>{const t=db.transaction(STORE,'readwrite');t.objectStore(STORE).delete(id);t.oncomplete=()=>resolve();t.onerror=()=>reject(t.error);});}
 function txAll(){return new Promise((resolve,reject)=>{const r=db.transaction(STORE,'readonly').objectStore(STORE).getAll();r.onsuccess=()=>resolve(r.result||[]);r.onerror=()=>reject(r.error);});}
 async function refresh(){records=(await txAll()).sort((a,b)=>b.createdAt-a.createdAt);render();}
 function esc(s){return String(s??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));}
 function short(s,n=44){s=String(s||'');return s.length>n?s.slice(0,n)+'…':s;}
 function csvEscape(v){return '"'+String(v??'').replace(/"/g,'""')+'"';}
 function getFiltered(){const f=$('statusFilter').value, q=$('searchBox').value.trim().toLowerCase();return records.filter(r=>(f==='all'||(f==='pending'?r.status!=='confirmed':r.status==='confirmed'))&&(!q||[r.name,r.manufacturer,r.model,r.code,r.raw,r.dept].join(' ').toLowerCase().includes(q)));}
 function render(){objectUrls.forEach(u=>URL.revokeObjectURL(u));objectUrls=[];const all=records.length,pending=records.filter(r=>r.status!=='confirmed').length,ok=all-pending;$('countAll').textContent='总记录：'+all;$('countPending').textContent='待审核：'+pending;$('countOk').textContent='已确认：'+ok;const list=getFiltered();const pages=Math.max(1,Math.ceil(list.length/PAGE_SIZE));page=Math.min(page,pages-1);const subset=list.slice(page*PAGE_SIZE,(page+1)*PAGE_SIZE);$('pageText').textContent=`第 ${list.length? page+1:0} / ${list.length?pages:0} 页（筛选后 ${list.length} 条）`;$('recordList').innerHTML='';if(!subset.length){$('recordList').innerHTML='<p class="hint">当前没有记录。先拍照或从相册选择铭牌照片。</p>';return;}
 subset.forEach(rec=>{const card=document.createElement('article');card.className='card';const img=rec.thumb?URL.createObjectURL(rec.thumb):'';if(img)objectUrls.push(img);card.innerHTML=`<div class="cardhead">${img?`<img class="thumb" data-open-image="${rec.id}" alt="点击查看铭牌照片" title="点击查看照片" src="${img}">`:'<div class="thumb" style="display:grid;place-items:center;font-size:11px;color:#78849a">无照片</div>'}<div class="cardtitle"><strong>${esc(rec.name||'未识别设备名称')}</strong><small>${esc(rec.batch||'未设置批次')} · ${esc(rec.createdAt?new Date(rec.createdAt).toLocaleString(): '')}</small></div><span class="badge ${rec.status==='confirmed'?'ok':''}">${rec.status==='confirmed'?'已确认':'待审核'}</span></div>
 ${rec.ocrError?`<div style="margin:8px 0;padding:8px;border-radius:8px;background:#fff4e5;color:#8a4b08;font-size:13px">OCR 提示：${esc(rec.ocrError)}</div>`:''}
 <div class="grid">
 ${makeField(rec,'dept','科室','text')}${makeField(rec,'date','日期','date')}
 ${makeField(rec,'name','设备名称','text')}${makeField(rec,'manufacturer','生产厂家','text')}
 ${makeField(rec,'model','型号','text')}${makeField(rec,'code','编号（出厂编号/SN）','text')}
 <div class="full"><label>铭牌文本（可修正 OCR 原文）</label><textarea data-id="${rec.id}" data-field="raw">${esc(rec.raw||'')}</textarea></div>
 </div><div class="controls"><button class="btn ${rec.status==='confirmed'?'light':'secondary'}" data-action="toggle" data-id="${rec.id}">${rec.status==='confirmed'?'取消确认':'确认这条记录'}</button><button class="btn light" data-action="reparse" data-id="${rec.id}">从原文重新提取字段</button><button class="btn danger" data-action="delete" data-id="${rec.id}">删除</button></div>`; $('recordList').appendChild(card);});
 $('prevBtn').disabled=page<=0;$('nextBtn').disabled=page>=pages-1;}
 function makeField(rec,field,label,type){return `<div><label>${label}</label><input type="${type}" data-id="${rec.id}" data-field="${field}" value="${esc(rec[field]||'')}"></div>`;}
 function valueOf(rec,field){return rec[field]||'';}
 function extract(text){const lines=String(text||'').replace(/\r/g,'\n').split('\n').map(x=>x.trim().replace(/[|｜]/g,'I')).filter(Boolean);function find(labels){for(let i=0;i<lines.length;i++){let line=lines[i];for(const lab of labels){const re=new RegExp('(?:^|[\\s：:]|^)'+lab.replace(/[.*+?^${}()|[\]\\]/g,'\\$&')+'\\s*[：:]?\\s*(.*)$','i');const m=line.match(re);if(m){let val=(m[1]||'').trim().replace(/^[：:：\-—\s]+/,'').trim();if(val && !labels.some(x=>new RegExp('^'+x+'$','i').test(val)))return val.slice(0,120);if(i+1<lines.length && lines[i+1].length<100 && !/^(额定|电压|功率|地址|电话|网址)/.test(lines[i+1]))return lines[i+1].slice(0,120);}}}return '';}
 // Prioritize explicit serial labels before generic number labels.
 const name=find(['设备名称','产品名称','仪器名称','Device Name','Product Name','Instrument Name','Equipment Name','名称']);
 const manufacturer=find(['生产厂家','制造厂家','制造商','生产企业','制造单位','生产单位','生产厂商','Manufacturer Name','Manufacturer','Manufactured by','Made by']);
 const model=find(['规格型号','产品型号','设备型号','Model Number','Model No.','Model','Type','型号','规格']);
 const code=find(['出厂编号','出厂序列号','序列号','序列 编号','设备编号','Serial Number','Serial No.','Serial No','S/N','SN','编号']);
 return {name,manufacturer,model,code};}
 const OCR_KEY_STORAGE='ocrspace-free-api-key';
 const OCR_ENGINE_STORAGE='ocrspace-engine';
 function getSavedOcrKey(){try{return localStorage.getItem(OCR_KEY_STORAGE)||'';}catch(_){return '';}}
 function saveOcrConfig(){
   const key=$('ocrApiKey').value.trim();
   const engine=$('ocrEngine').value==='3'?'3':'2';
   if(!key){alert('请先填写 OCR.space API Key。');return;}
   try{localStorage.setItem(OCR_KEY_STORAGE,key);localStorage.setItem(OCR_ENGINE_STORAGE,engine);status('识别设置已保存在本机浏览器。当前引擎：Engine '+engine+'。');}
   catch(_){status('浏览器不允许保存设置。请检查隐私模式或浏览器站点存储权限。');}
 }
 $('ocrApiKey').value=getSavedOcrKey();
 try{$('ocrEngine').value=localStorage.getItem(OCR_ENGINE_STORAGE)||'2';}catch(_){}
 $('saveOcrConfigBtn').addEventListener('click',saveOcrConfig);
 function canvasBlob(canvas,quality){return new Promise((resolve,reject)=>canvas.toBlob(b=>b?resolve(b):reject(new Error('图片压缩失败。')),'image/jpeg',quality));}
 async function prepareApiImage(file,maxBytes=950000){
   // OCR.space free tier accepts uploads up to 1 MB. Resize/compress locally before upload.
   return new Promise((resolve,reject)=>{
     const image=new Image();const url=URL.createObjectURL(file);
     image.onload=async()=>{
       try{
         let scale=Math.min(1,2300/Math.max(image.naturalWidth,image.naturalHeight));
         let finalBlob=null;
         for(let attempt=0;attempt<12;attempt++){
           const w=Math.max(1,Math.round(image.naturalWidth*scale));
           const h=Math.max(1,Math.round(image.naturalHeight*scale));
           const canvas=document.createElement('canvas');canvas.width=w;canvas.height=h;
           const ctx=canvas.getContext('2d',{alpha:false});if(!ctx)throw new Error('无法创建照片压缩画布。');
           ctx.fillStyle='#fff';ctx.fillRect(0,0,w,h);ctx.drawImage(image,0,0,w,h);
           for(const q of [0.9,0.84,0.78,0.72]){
             const blob=await canvasBlob(canvas,q);finalBlob=blob;
             if(blob.size<=maxBytes){URL.revokeObjectURL(url);resolve(blob);return;}
           }
           scale*=0.84;
           if(scale<0.35)break;
         }
         URL.revokeObjectURL(url);
         if(finalBlob&&finalBlob.size<=maxBytes)resolve(finalBlob);
         else reject(new Error('图片压缩后仍超过 1 MB。请先裁剪到铭牌区域再上传。'));
       }catch(err){URL.revokeObjectURL(url);reject(err);}
     };
     image.onerror=()=>{URL.revokeObjectURL(url);reject(new Error('浏览器无法读取该图片格式，请改用 JPG/PNG。'));};
     image.src=url;
   });
 }
 async function recognizeWithOcrSpace(file,apiKey,engine){
   const blob=await prepareApiImage(file);
   const form=new FormData();
   const base=(file.name||'mingpai').replace(/\.[^.]+$/,'').replace(/[\\/:*?"<>|]/g,'_');
   form.append('file',blob,base+'.jpg');
   form.append('apikey',apiKey); // sent in the multipart body; API docs support this for browser AJAX examples
   form.append('OCREngine',String(engine));
   form.append('language','auto');
   form.append('detectOrientation','true');
   form.append('isOverlayRequired','false');
   const controller=new AbortController();
   const timer=setTimeout(()=>controller.abort(),90000);
   let response,data;
   try{
     response=await fetch('https://api.ocr.space/parse/image',{method:'POST',body:form,signal:controller.signal});
     if(!response.ok)throw new Error('OCR 服务 HTTP '+response.status+'。请稍后重试。');
     data=await response.json();
   }catch(err){
     if(err&&err.name==='AbortError')throw new Error('OCR.space 请求超过 90 秒。请检查网络后单张重试。');
     if(err instanceof TypeError)throw new Error('无法连接 OCR.space。请检查网络、浏览器跨域连接或 API Key。');
     throw err;
   }finally{clearTimeout(timer);}
   if(data&&data.IsErroredOnProcessing){
     const detail=[data.ErrorMessage,data.ErrorDetails].flat().filter(Boolean).join(' ');
     throw new Error(detail||'OCR 服务处理失败。');
   }
   const list=Array.isArray(data?.ParsedResults)?data.ParsedResults:[];
   const text=list.map(x=>String(x.ParsedText||'').trim()).filter(Boolean).join('\n');
   if(!text){const detail=list.map(x=>x.ErrorMessage||x.ErrorDetails).flat().filter(Boolean).join(' ');throw new Error(detail||'没有识别到文字，请调整拍摄角度或裁剪铭牌区域。');}
   return text;
 }
 function makeThumb(file){return new Promise((resolve)=>{const img=new Image();const url=URL.createObjectURL(file);img.onload=()=>{const max=960,scale=Math.min(1,max/Math.max(img.naturalWidth,img.naturalHeight));const c=document.createElement('canvas');c.width=Math.max(1,Math.round(img.naturalWidth*scale));c.height=Math.max(1,Math.round(img.naturalHeight*scale));c.getContext('2d').drawImage(img,0,0,c.width,c.height);URL.revokeObjectURL(url);c.toBlob(b=>resolve(b),'image/jpeg',0.62);};img.onerror=()=>{URL.revokeObjectURL(url);resolve(null);};img.src=url;});}
 async function handleFiles(fileList){
   if(busy)return;
   const files=Array.from(fileList||[]).filter(f=>f.type.startsWith('image/'));
   if(!files.length)return;
   const apiKey=$('ocrApiKey').value.trim()||getSavedOcrKey();
   if(!apiKey){alert('请先申请 OCR.space 免费 API Key，并填入上方后点击“保存识别设置”。');return;}
   const engine=$('ocrEngine').value==='3'?'3':'2';
   busy=true;$('cameraBtn').disabled=$('galleryBtn').disabled=true;
   let done=0,failed=0;
   try{
     for(let i=0;i<files.length;i++){
       const file=files[i];done=i+1;
       let text='',ocrError='';
       try{
         status(`正在压缩第 ${done}/${files.length} 张：${file.name||'手机照片'}……`);
         status(`正在通过 OCR.space Engine ${engine} 识别第 ${done}/${files.length} 张：${file.name||'手机照片'}。图片将上传到云端识别，最长等待 90 秒。`);
         text=await recognizeWithOcrSpace(file,apiKey,engine);
       }catch(error){ocrError=error&&error.message?error.message:String(error);failed++;}
       const fields=extract(text);
       const rec={
         id:(crypto.randomUUID?crypto.randomUUID():Date.now()+'-'+Math.random().toString(36).slice(2)),
         createdAt:Date.now(),dept:$('dept').value.trim(),date:$('workdate').value||'',batch:$('batch').value.trim(),
         raw:text,name:fields.name,manufacturer:fields.manufacturer,model:fields.model,code:fields.code,
         status:'pending',ocrError,thumb:await makeThumb(file)
       };
       await txPut(rec);records.push(rec);render();
     }
     records.sort((a,b)=>b.createdAt-a.createdAt);page=0;render();
     status(`处理完成：共 ${files.length} 张，识别异常 ${failed} 张。请检查待审核记录；失败记录已保留，可重新拍照或人工补录。注意免费额度上限为每 IP 每天 500 次。`);
   }catch(error){status('处理失败：'+(error&&error.message?error.message:String(error)));}
   finally{busy=false;$('cameraBtn').disabled=$('galleryBtn').disabled=false;$('cameraInput').value='';$('galleryInput').value='';}
 }
 $('cameraBtn').addEventListener('click',()=>$('cameraInput').click());$('galleryBtn').addEventListener('click',()=>$('galleryInput').click());$('cameraInput').addEventListener('change',e=>handleFiles(e.target.files));$('galleryInput').addEventListener('change',e=>handleFiles(e.target.files));
 $('pasteOcrBtn').addEventListener('click',async()=>{
   const raw=$('pasteOcrText').value.trim();
   if(!raw){alert('请先粘贴手机相册或微信提取的文字。');return;}
   if(!db){alert('本地记录正在初始化，请稍后重试。');return;}
   const fields=extract(raw);
   const rec={id:(crypto.randomUUID?crypto.randomUUID():Date.now()+'-'+Math.random().toString(36).slice(2)),createdAt:Date.now(),dept:$('dept').value.trim(),date:$('workdate').value||'',batch:$('batch').value.trim(),raw,name:fields.name,manufacturer:fields.manufacturer,model:fields.model,code:fields.code,status:'pending',thumb:null};
   await txPut(rec);records.push(rec);records.sort((a,b)=>b.createdAt-a.createdAt);page=0;render();$('pasteOcrText').value='';status('已加入 1 条待审核记录。请检查各字段，修正后点击“确认这条记录”。');
 });
 $('clearPasteBtn').addEventListener('click',()=>$('pasteOcrText').value='');
 $('recordList').addEventListener('change',async e=>{const el=e.target;if(!el.dataset.id||!el.dataset.field)return;const rec=records.find(r=>r.id===el.dataset.id);if(!rec)return;rec[el.dataset.field]=el.value;if(['name','manufacturer','model','code','raw'].includes(el.dataset.field)&&rec.status==='confirmed')rec.status='pending';await txPut(rec);await refresh();});
 $('recordList').addEventListener('click',async e=>{const photo=e.target.closest('img[data-open-image]');if(photo){const r=records.find(x=>x.id===photo.dataset.openImage);if(r&&r.thumb){const u=URL.createObjectURL(r.thumb);const w=window.open(u,'_blank');if(!w)alert('浏览器阻止了新窗口，请允许打开照片预览。');setTimeout(()=>URL.revokeObjectURL(u),60000);}return;}const b=e.target.closest('button[data-action]');if(!b)return;const rec=records.find(r=>r.id===b.dataset.id);if(!rec)return;if(b.dataset.action==='toggle'){rec.status=rec.status==='confirmed'?'pending':'confirmed';await txPut(rec);}else if(b.dataset.action==='delete'){if(!confirm('确定删除这条本地记录吗？'))return;await txDelete(rec.id);}else if(b.dataset.action==='reparse'){const f=extract(rec.raw);rec.name=f.name;rec.manufacturer=f.manufacturer;rec.model=f.model;rec.code=f.code;rec.status='pending';await txPut(rec);}await refresh();});
 $('statusFilter').addEventListener('change',()=>{page=0;render();});$('searchBox').addEventListener('input',()=>{page=0;render();});$('prevBtn').addEventListener('click',()=>{page=Math.max(0,page-1);render();});$('nextBtn').addEventListener('click',()=>{page++;render();});
 function confirmed(){return records.filter(r=>r.status==='confirmed').sort((a,b)=>a.createdAt-b.createdAt);}
 const colOrder=['dept','date','raw','name','manufacturer','model','code'];
 function tsvQuote(v){return String(v??'').replace(/\r?\n/g,' ' ).replace(/\t/g,' ');}
 $('copyBtn').addEventListener('click',async()=>{const rows=confirmed();if(!rows.length){alert('没有已确认的记录。请先审核并确认记录。');return;}const text=rows.map(r=>colOrder.map(k=>tsvQuote(r[k])).join('\t')).join('\n');try{await navigator.clipboard.writeText(text);alert(`已复制 ${rows.length} 条已确认记录。打开腾讯文档智能表格，在第一条空白行的“科室”单元格点一下并粘贴。请先用 2～3 条测试确认各列对齐。`);}catch(e){const win=window.open('','_blank');win.document.write('<textarea style="width:98%;height:90vh;font-size:14px"></textarea>');win.document.querySelector('textarea').value=text;win.document.title='复制已确认数据';alert('浏览器未允许自动复制，已尝试打开可手动全选复制的页面。');}});
 $('csvBtn').addEventListener('click',()=>{const rows=confirmed();if(!rows.length){alert('没有已确认的记录。');return;}const headers=['科室','日期','铭牌文本','设备名称','生产厂家','型号','编号'];const csv='\ufeff'+[headers,...rows.map(r=>colOrder.map(k=>r[k]||''))].map(row=>row.map(csvEscape).join(',')).join('\r\n');download(new Blob([csv],{type:'text/csv;charset=utf-8'}),'设备铭牌已确认数据.csv');});
 $('jsonBtn').addEventListener('click',()=>{const backup={app:'mingpai-free-v1',exportedAt:new Date().toISOString(),note:'字段备份不含原始照片缩略图；照片缩略图只保存在原手机浏览器。',records:records.map(({thumb,...r})=>r)};download(new Blob([JSON.stringify(backup,null,2)],{type:'application/json;charset=utf-8'}),'设备铭牌字段备份.json');});
 $('restoreBtn').addEventListener('click',()=>$('restoreInput').click());$('restoreInput').addEventListener('change',async e=>{const f=e.target.files&&e.target.files[0];if(!f)return;try{const obj=JSON.parse(await f.text());if(!Array.isArray(obj.records))throw new Error('备份文件格式不正确');if(!confirm(`备份中有 ${obj.records.length} 条记录。选择“确定”后会合并到本地，重复 ID 会覆盖。继续吗？`))return;for(const r of obj.records){if(!r.id)r.id='restore-'+Date.now()+'-'+Math.random().toString(36).slice(2);await txPut({...r,thumb:null});}await refresh();alert('恢复完成。');}catch(err){alert('恢复失败：'+err.message);}finally{$('restoreInput').value='';}});
 function download(blob,name){const url=URL.createObjectURL(blob);const a=document.createElement('a');a.href=url;a.download=name;document.body.appendChild(a);a.click();a.remove();setTimeout(()=>URL.revokeObjectURL(url),1500);}
 openDB().then(async d=>{db=d;await refresh();}).catch(e=>status('本地数据库初始化失败：'+e.message+'。请换用最新版 Chrome/Safari，并确保网站使用 HTTPS。'));
