import { PaddleOCR } from '@paddleocr/paddleocr-js';

'use strict';

const DB_NAME='mingpai-free-v1', STORE='records', PAGE_SIZE=10;
 let db, records=[], page=0, worker=null, busy=false, objectUrls=[];
 const $ = id => document.getElementById(id);
 const today = new Date();
 $('workdate').value = `${today.getFullYear()}-${String(today.getMonth()+1).padStart(2,'0')}-${String(today.getDate()).padStart(2,'0')}`;
 function status(msg){ $('progress').textContent=msg; }
 function openDB(){return new Promise((resolve,reject)=>{const req=indexedDB.open(DB_NAME,1);req.onupgradeneeded=()=>{const d=req.result;if(!d.objectStoreNames.contains(STORE))d.createObjectStore(STORE,{keyPath:'id'});};req.onsuccess=()=>resolve(req.result);req.onerror=()=>reject(req.error);});}
 function txPut(rec){return new Promise((resolve,reject)=>{const t=db.transaction(STORE,'readwrite');t.objectStore(STORE).put(rec);t.oncomplete=()=>resolve();t.onerror=()=>reject(t.error);});}
 function txDelete(id){return new Promise((resolve,reject)=>{const t=db.transaction(STORE,'readwrite');t.objectStore(STORE).delete(id);t.oncomplete=()=>resolve();t.onerror=()=>reject(t.error);});}
 function txAll(){return new Promise((resolve,reject)=>{const r=db.transaction(STORE,'readonly').objectStore(STORE).getAll();r.onsuccess=()=>resolve(r.result||[]);r.onerror=()=>reject(r.error);});}
 async function refresh(){records=(await txAll()).sort((a,b)=>b.createdAt-a.createdAt);render();}
 function esc(s){return String(s??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));}
 function short(s,n=44){s=String(s||'');return s.length>n?s.slice(0,n)+'…':s;}
 function csvEscape(v){return '"'+String(v??'').replace(/"/g,'""')+'"';}
 function getFiltered(){const f=$('statusFilter').value, q=$('searchBox').value.trim().toLowerCase();return records.filter(r=>(f==='all'||(f==='pending'?r.status!=='confirmed':r.status==='confirmed'))&&(!q||[r.name,r.manufacturer,r.model,r.code,r.raw,r.dept].join(' ').toLowerCase().includes(q)));}
 function render(){objectUrls.forEach(u=>URL.revokeObjectURL(u));objectUrls=[];const all=records.length,pending=records.filter(r=>r.status!=='confirmed').length,ok=all-pending;$('countAll').textContent='总记录：'+all;$('countPending').textContent='待审核：'+pending;$('countOk').textContent='已确认：'+ok;const list=getFiltered();const pages=Math.max(1,Math.ceil(list.length/PAGE_SIZE));page=Math.min(page,pages-1);const subset=list.slice(page*PAGE_SIZE,(page+1)*PAGE_SIZE);$('pageText').textContent=`第 ${list.length? page+1:0} / ${list.length?pages:0} 页（筛选后 ${list.length} 条）`;$('recordList').innerHTML='';if(!subset.length){$('recordList').innerHTML='<p class="hint">当前没有记录。先拍照或从相册选择铭牌照片。</p>';return;}
 subset.forEach(rec=>{const card=document.createElement('article');card.className='card';const img=rec.thumb?URL.createObjectURL(rec.thumb):'';if(img)objectUrls.push(img);card.innerHTML=`<div class="cardhead">${img?`<img class="thumb" data-open-image="${rec.id}" alt="点击查看铭牌照片" title="点击查看照片" src="${img}">`:'<div class="thumb" style="display:grid;place-items:center;font-size:11px;color:#78849a">无照片</div>'}<div class="cardtitle"><strong>${esc(rec.name||'未识别设备名称')}</strong><small>${esc(rec.batch||'未设置批次')} · ${esc(rec.createdAt?new Date(rec.createdAt).toLocaleString(): '')}</small></div><span class="badge ${rec.status==='confirmed'?'ok':''}">${rec.status==='confirmed'?'已确认':'待审核'}</span></div>
 ${rec.ocrError?`<div style="margin:8px 0;padding:8px;border-radius:8px;background:#fff4e5;color:#8a4b08;font-size:13px">OCR 提示：${esc(rec.ocrError)}</div>`:''}
 <div class="grid">
 ${makeField(rec,'dept','科室','text')}${makeField(rec,'date','日期','date')}
 ${makeField(rec,'name','设备名称','text')}${makeField(rec,'manufacturer','生产厂家','text')}
 ${makeField(rec,'model','型号','text')}${makeField(rec,'code','编号（出厂编号/SN）','text')}
 <div class="full"><label>铭牌文本（可修正 OCR 原文）</label><textarea data-id="${rec.id}" data-field="raw">${esc(rec.raw||'')}</textarea></div>
 </div><div class="controls"><button class="btn ${rec.status==='confirmed'?'light':'secondary'}" data-action="toggle" data-id="${rec.id}">${rec.status==='confirmed'?'取消确认':'确认这条记录'}</button><button class="btn light" data-action="reparse" data-id="${rec.id}">从原文重新提取字段</button><button class="btn danger" data-action="delete" data-id="${rec.id}">删除</button></div>`; $('recordList').appendChild(card);});
 $('prevBtn').disabled=page<=0;$('nextBtn').disabled=page>=pages-1;}
 function makeField(rec,field,label,type){return `<div><label>${label}</label><input type="${type}" data-id="${rec.id}" data-field="${field}" value="${esc(rec[field]||'')}"></div>`;}
 function valueOf(rec,field){return rec[field]||'';}
 function extract(text){const lines=String(text||'').replace(/\r/g,'\n').split('\n').map(x=>x.trim().replace(/[|｜]/g,'I')).filter(Boolean);function find(labels){for(let i=0;i<lines.length;i++){let line=lines[i];for(const lab of labels){const re=new RegExp('(?:^|[\\s：:]|^)'+lab.replace(/[.*+?^${}()|[\]\\]/g,'\\$&')+'\\s*[：:]?\\s*(.*)$','i');const m=line.match(re);if(m){let val=(m[1]||'').trim().replace(/^[：:：\-—\s]+/,'').trim();if(val && !labels.some(x=>new RegExp('^'+x+'$','i').test(val)))return val.slice(0,120);if(i+1<lines.length && lines[i+1].length<100 && !/^(额定|电压|功率|地址|电话|网址)/.test(lines[i+1]))return lines[i+1].slice(0,120);}}}return '';}
 // Prioritize explicit serial labels before generic number labels.
 const name=find(['设备名称','产品名称','仪器名称','Device Name','Product Name','Instrument Name','Equipment Name','名称']);
 const manufacturer=find(['生产厂家','制造厂家','制造商','生产企业','制造单位','生产单位','生产厂商','Manufacturer Name','Manufacturer','Manufactured by','Made by']);
 const model=find(['规格型号','产品型号','设备型号','Model Number','Model No.','Model','Type','型号','规格']);
 const code=find(['出厂编号','出厂序列号','序列号','序列 编号','设备编号','Serial Number','Serial No.','Serial No','S/N','SN','编号']);
 return {name,manufacturer,model,code};}
 async function getWorker(){
   if(worker)return worker;
   status('正在加载 PP-OCRv5 mobile 中英文识别模型。首次使用需要联网下载，请保持网页在前台。');
   // Use the official browser Worker mode so OCR inference does not block the page UI.
   // PP-OCRv5 mobile is intentionally chosen for lower memory/compute demand on phones.
   try {
     worker=await PaddleOCR.create({
       textDetectionModelName:'PP-OCRv5_mobile_det',
       textRecognitionModelName:'PP-OCRv5_mobile_rec',
       textDetectionBatchSize:1,
       textRecognitionBatchSize:4,
       worker:true,
       ortOptions:{backend:'wasm',numThreads:1,simd:true}
     });
     status('PP-OCRv5 mobile 模型加载完成，开始识别。');
     return worker;
   } catch(error) {
     worker=null;
     const message=error&&error.message?error.message:String(error);
     throw new Error('PP-OCRv5 mobile 初始化失败：'+message+'。请确认网络可以访问模型与运行时资源，然后刷新网页重试。');
   }
 }
 function withTimeout(promise, ms, message){
   let timer;
   return Promise.race([
     promise,
     new Promise((_,reject)=>{timer=setTimeout(()=>reject(new Error(message)),ms);})
   ]).finally(()=>clearTimeout(timer));
 }
 async function disposeWorker(){
   const old=worker;
   worker=null;
   if(old&&typeof old.dispose==='function'){
     try { await Promise.race([old.dispose(),new Promise(resolve=>setTimeout(resolve,1500))]); } catch(_) {}
   }
 }
 function prepareOCRImage(file,maxSide=2000){
   // Normalize phone photos (including orientation handling performed by the browser) to a
   // reasonably sized JPEG before transferring them to the OCR worker.
   return new Promise((resolve,reject)=>{
     const image=new Image();
     const url=URL.createObjectURL(file);
     image.onload=()=>{
       try{
         const scale=Math.min(1,maxSide/Math.max(image.naturalWidth,image.naturalHeight));
         const width=Math.max(1,Math.round(image.naturalWidth*scale));
         const height=Math.max(1,Math.round(image.naturalHeight*scale));
         const canvas=document.createElement('canvas');
         canvas.width=width; canvas.height=height;
         const ctx=canvas.getContext('2d',{alpha:false});
         if(!ctx) throw new Error('无法准备照片画布');
         ctx.fillStyle='#fff';ctx.fillRect(0,0,width,height);
         ctx.drawImage(image,0,0,width,height);
         URL.revokeObjectURL(url);
         canvas.toBlob(blob=>blob?resolve(blob):reject(new Error('照片压缩失败，请换一张 JPG/PNG 照片再试。')),'image/jpeg',0.92);
       }catch(error){URL.revokeObjectURL(url);reject(error);}
     };
     image.onerror=()=>{URL.revokeObjectURL(url);reject(new Error('浏览器无法读取该图片格式。请将照片转换为 JPG/PNG 后再试。'));};
     image.src=url;
   });
 }
 function makeThumb(file){return new Promise((resolve)=>{const img=new Image();const url=URL.createObjectURL(file);img.onload=()=>{const max=960,scale=Math.min(1,max/Math.max(img.naturalWidth,img.naturalHeight));const c=document.createElement('canvas');c.width=Math.max(1,Math.round(img.naturalWidth*scale));c.height=Math.max(1,Math.round(img.naturalHeight*scale));c.getContext('2d').drawImage(img,0,0,c.width,c.height);URL.revokeObjectURL(url);c.toBlob(b=>resolve(b),'image/jpeg',0.62);};img.onerror=()=>{URL.revokeObjectURL(url);resolve(null);};img.src=url;});}
 async function handleFiles(fileList){
   if(busy)return;
   const files=Array.from(fileList||[]).filter(f=>f.type.startsWith('image/'));
   if(!files.length)return;
   busy=true;$('cameraBtn').disabled=$('galleryBtn').disabled=true;
   let done=0, failed=0, stopBatch=false;
   try{
     const ocr=await getWorker();
     for(let i=0;i<files.length;i++){
       const file=files[i]; done=i+1;
       let text='',ocrError='';
       try{
         status(`正在优化第 ${done}/${files.length} 张：${file.name||'手机照片'}……`);
         const ocrImage=await prepareOCRImage(file,2000);
         status(`正在识别第 ${done}/${files.length} 张：${file.name||'手机照片'}
OCR 在后台运行，网页仍可响应。单张最长等待 90 秒。`);
         const results=await withTimeout(
           ocr.predict(ocrImage,{textDetLimitSideLen:960,textDetLimitType:'max'}),
           90000,
           '单张 OCR 超过 90 秒仍未返回。请尝试裁剪铭牌区域、换稳定网络，或刷新后只上传这一张照片。'
         );
         const result=results&&results[0];
         text=(result&&Array.isArray(result.items)?result.items.map(item=>String(item.text||'').trim()).filter(Boolean).join('\n'):'');
         if(!text)ocrError='未识别到文字，请检查照片是否清晰、铭牌是否过小或有反光。';
       }catch(error){
         ocrError=error&&error.message?error.message:String(error);
         failed++;
         status(`第 ${done}/${files.length} 张识别未完成：${ocrError}`);
         if(ocrError.includes('超过 90 秒')){
           stopBatch=true;
         }
       }
       const fields=extract(text);
       const rec={
         id:(crypto.randomUUID?crypto.randomUUID():Date.now()+'-'+Math.random().toString(36).slice(2)),
         createdAt:Date.now(),dept:$('dept').value.trim(),date:$('workdate').value||'',batch:$('batch').value.trim(),
         raw:text,name:fields.name,manufacturer:fields.manufacturer,model:fields.model,code:fields.code,
         status:'pending',ocrError,thumb:await makeThumb(file)
       };
       await txPut(rec);records.push(rec);
       if(stopBatch){
         await disposeWorker();
         break;
       }
     }
     records.sort((a,b)=>b.createdAt-a.createdAt);page=0;render();
     if(stopBatch)status(`已保存 ${done} 张中的当前记录，但 OCR 超时，已停止本批剩余照片。请刷新网页后先单张测试。`);
     else status(`处理完成：共 ${files.length} 张，识别异常 ${failed} 张。请检查待审核记录；识别失败的记录已保留，可人工补录。`);
   }catch(error){
     status('处理失败：'+(error&&error.message?error.message:String(error)));
   }finally{
     busy=false;$('cameraBtn').disabled=$('galleryBtn').disabled=false;$('cameraInput').value='';$('galleryInput').value='';
   }
 }
 $('cameraBtn').addEventListener('click',()=>$('cameraInput').click());$('galleryBtn').addEventListener('click',()=>$('galleryInput').click());$('cameraInput').addEventListener('change',e=>handleFiles(e.target.files));$('galleryInput').addEventListener('change',e=>handleFiles(e.target.files));
 $('pasteOcrBtn').addEventListener('click',async()=>{
   const raw=$('pasteOcrText').value.trim();
   if(!raw){alert('请先粘贴手机相册或微信提取的文字。');return;}
   if(!db){alert('本地记录正在初始化，请稍后重试。');return;}
   const fields=extract(raw);
   const rec={id:(crypto.randomUUID?crypto.randomUUID():Date.now()+'-'+Math.random().toString(36).slice(2)),createdAt:Date.now(),dept:$('dept').value.trim(),date:$('workdate').value||'',batch:$('batch').value.trim(),raw,name:fields.name,manufacturer:fields.manufacturer,model:fields.model,code:fields.code,status:'pending',thumb:null};
   await txPut(rec);records.push(rec);records.sort((a,b)=>b.createdAt-a.createdAt);page=0;render();$('pasteOcrText').value='';status('已加入 1 条待审核记录。请检查各字段，修正后点击“确认这条记录”。');
 });
 $('clearPasteBtn').addEventListener('click',()=>$('pasteOcrText').value='');
 $('recordList').addEventListener('change',async e=>{const el=e.target;if(!el.dataset.id||!el.dataset.field)return;const rec=records.find(r=>r.id===el.dataset.id);if(!rec)return;rec[el.dataset.field]=el.value;if(['name','manufacturer','model','code','raw'].includes(el.dataset.field)&&rec.status==='confirmed')rec.status='pending';await txPut(rec);await refresh();});
 $('recordList').addEventListener('click',async e=>{const photo=e.target.closest('img[data-open-image]');if(photo){const r=records.find(x=>x.id===photo.dataset.openImage);if(r&&r.thumb){const u=URL.createObjectURL(r.thumb);const w=window.open(u,'_blank');if(!w)alert('浏览器阻止了新窗口，请允许打开照片预览。');setTimeout(()=>URL.revokeObjectURL(u),60000);}return;}const b=e.target.closest('button[data-action]');if(!b)return;const rec=records.find(r=>r.id===b.dataset.id);if(!rec)return;if(b.dataset.action==='toggle'){rec.status=rec.status==='confirmed'?'pending':'confirmed';await txPut(rec);}else if(b.dataset.action==='delete'){if(!confirm('确定删除这条本地记录吗？'))return;await txDelete(rec.id);}else if(b.dataset.action==='reparse'){const f=extract(rec.raw);rec.name=f.name;rec.manufacturer=f.manufacturer;rec.model=f.model;rec.code=f.code;rec.status='pending';await txPut(rec);}await refresh();});
 $('statusFilter').addEventListener('change',()=>{page=0;render();});$('searchBox').addEventListener('input',()=>{page=0;render();});$('prevBtn').addEventListener('click',()=>{page=Math.max(0,page-1);render();});$('nextBtn').addEventListener('click',()=>{page++;render();});
 function confirmed(){return records.filter(r=>r.status==='confirmed').sort((a,b)=>a.createdAt-b.createdAt);}
 const colOrder=['dept','date','raw','name','manufacturer','model','code'];
 function tsvQuote(v){return String(v??'').replace(/\r?\n/g,' ' ).replace(/\t/g,' ');}
 $('copyBtn').addEventListener('click',async()=>{const rows=confirmed();if(!rows.length){alert('没有已确认的记录。请先审核并确认记录。');return;}const text=rows.map(r=>colOrder.map(k=>tsvQuote(r[k])).join('\t')).join('\n');try{await navigator.clipboard.writeText(text);alert(`已复制 ${rows.length} 条已确认记录。打开腾讯文档智能表格，在第一条空白行的“科室”单元格点一下并粘贴。请先用 2～3 条测试确认各列对齐。`);}catch(e){const win=window.open('','_blank');win.document.write('<textarea style="width:98%;height:90vh;font-size:14px"></textarea>');win.document.querySelector('textarea').value=text;win.document.title='复制已确认数据';alert('浏览器未允许自动复制，已尝试打开可手动全选复制的页面。');}});
 $('csvBtn').addEventListener('click',()=>{const rows=confirmed();if(!rows.length){alert('没有已确认的记录。');return;}const headers=['科室','日期','铭牌文本','设备名称','生产厂家','型号','编号'];const csv='\ufeff'+[headers,...rows.map(r=>colOrder.map(k=>r[k]||''))].map(row=>row.map(csvEscape).join(',')).join('\r\n');download(new Blob([csv],{type:'text/csv;charset=utf-8'}),'设备铭牌已确认数据.csv');});
 $('jsonBtn').addEventListener('click',()=>{const backup={app:'mingpai-free-v1',exportedAt:new Date().toISOString(),note:'字段备份不含原始照片缩略图；照片缩略图只保存在原手机浏览器。',records:records.map(({thumb,...r})=>r)};download(new Blob([JSON.stringify(backup,null,2)],{type:'application/json;charset=utf-8'}),'设备铭牌字段备份.json');});
 $('restoreBtn').addEventListener('click',()=>$('restoreInput').click());$('restoreInput').addEventListener('change',async e=>{const f=e.target.files&&e.target.files[0];if(!f)return;try{const obj=JSON.parse(await f.text());if(!Array.isArray(obj.records))throw new Error('备份文件格式不正确');if(!confirm(`备份中有 ${obj.records.length} 条记录。选择“确定”后会合并到本地，重复 ID 会覆盖。继续吗？`))return;for(const r of obj.records){if(!r.id)r.id='restore-'+Date.now()+'-'+Math.random().toString(36).slice(2);await txPut({...r,thumb:null});}await refresh();alert('恢复完成。');}catch(err){alert('恢复失败：'+err.message);}finally{$('restoreInput').value='';}});
 function download(blob,name){const url=URL.createObjectURL(blob);const a=document.createElement('a');a.href=url;a.download=name;document.body.appendChild(a);a.click();a.remove();setTimeout(()=>URL.revokeObjectURL(url),1500);}
 openDB().then(async d=>{db=d;await refresh();}).catch(e=>status('本地数据库初始化失败：'+e.message+'。请换用最新版 Chrome/Safari，并确保网站使用 HTTPS。'));
